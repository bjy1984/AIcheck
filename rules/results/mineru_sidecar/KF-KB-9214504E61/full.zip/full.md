TSG

特种设备安全技术规范

TSG Z8001–2019

# 特种设备无损检测人员考核规则

# Examination Rules for Nondestructive Testing Inspectors of Special Equipment

国家市场监督管理总局颁布

2019年5月27日

## 目录

第一章 总则 …… (1)
第二章 工作职责 …… (2)
第三章 取证 …… (3)
第四章 换证 …… (4)
第五章 考试机构 …… (5)
第六章 无损检测人员管理 …… (6)
第七章 附则 …… (7)

附件 A 特种设备检测人员资格申请表 …… (8)
附件 B 特种设备检验检测人员证(样式) …… (9)
附件 C 特种设备无损检测人员考试大纲 …… (10)

相关规章和规范历次制(修)订情况 …… (33)

# 特种设备无损检测人员考核规则

## 第一章 总 则

第一条 为了规范特种设备无损检测人员的考核工作，根据《中华人民共和国特种设备安全法》《特种设备安全监察条例》，制定本规则。

第二条 特种设备无损检测人员是指从事《特种设备目录》适用范围内特种设备无损检测工作的人员。

无损检测人员应当按照本规则的要求，取得相应的《特种设备检验检测人员证(无损检测人员)》(以下简称《检测人员证》)，方可从事相应的无损检测工作。

第三条 本规则规定的无损检测方法，包括射线检测、超声检测、磁粉检测、渗透检测、声发射检测、涡流检测、漏磁检测。无损检测人员级别，分为Ⅰ级(初级)、Ⅱ级(中级)和Ⅲ级(高级)。

无损检测方法、项目、代号和级别的划分见表1。

表 1 无损检测方法、项目、代号和级别

<table><tr><td>方法</td><td>项目</td><td>代号</td><td>级别</td></tr><tr><td rowspan="2">射线检测</td><td>射线胶片照相检测</td><td>RT</td><td>I、II、III</td></tr><tr><td>射线数字成像检测</td><td>RT(D)</td><td>II</td></tr><tr><td rowspan="4">超声检测(注1)</td><td>脉冲反射法超声检测</td><td>UT</td><td>I、II、III</td></tr><tr><td>脉冲反射法超声检测(自动)</td><td>UT(AUTO)</td><td>II</td></tr><tr><td>衍射时差法超声检测</td><td>TOFD</td><td>II</td></tr><tr><td>相控阵超声检测</td><td>PA</td><td>II</td></tr><tr><td>磁粉检测</td><td>磁粉检测</td><td>MT</td><td>I、II、III</td></tr><tr><td>渗透检测</td><td>渗透检测</td><td>PT</td><td>I、II、III</td></tr><tr><td>声发射检测</td><td>声发射检测</td><td>AE</td><td>II、III</td></tr><tr><td rowspan="2">涡流检测(注1)</td><td>涡流检测</td><td>ECT</td><td>II、III</td></tr><tr><td>涡流检测(自动)</td><td>ECT(AUTO)</td><td>II</td></tr><tr><td>漏磁检测</td><td>漏磁检测(自动)</td><td>MFL(AUTO)</td><td>II</td></tr></table>

注 1：脉冲反射法超声检测项目覆盖脉冲反射法超声检测(自动)项目，涡流检测项目覆盖涡流检测(自动)项目。

第四条 申请射线胶片照相检测(RT)、脉冲反射法超声检测(UT)、磁粉检测(MT)、渗透检测(PT)项目Ⅰ级和Ⅱ级《检测人员证》的人员，应当向省级市场监督管理部门(以下简称省级发证机关)提出申请，经考试合格，由省级发证机关批准颁发《检测人员证》。

申请前款以外的其他无损检测项目和级别的人员，应当向国家市场监督管理总局(以下简称国家级发证机关)提出申请，经考试合格，由国家级发证机关批准颁发《检测人员证》。

第五条 《检测人员证》有效期为 5 年。有效期满需要继续从事无损检测工作的，应当按照本规则的规定办理换证。

## 第二章 工作职责

## 第六条 I级无损检测人员：

(一) 正确调整和使用无损检测仪器；

(二)按照无损检测操作指导书进行无损检测操作；

(三)记录无损检测数据，整理无损检测资料；

(四)了解和执行有关安全防护规则。

## 第七条 Ⅱ级无损检测人员：

(一)从事或者监督Ⅰ级无损检测人员的工作；

(二)按照工艺文件要求调试和校准无损检测仪器，实施无损检测操作；

(三)根据无损检测工艺规程编制针对具体工件的无损检测操作指导书；

(四)编制和审核无损检测工艺规程(限持Ⅱ级资格4年以上的人员);

(五)按照规范、标准规定，评定检测结果，编制或者审核无损检测报告；

(六)对Ⅰ级无损检测人员进行技能培训和工作指导。

## 第八条 Ⅲ级无损检测人员：

(一)从事或者监督Ⅰ级和Ⅱ级无损检测人员的工作；

(二)负责无损检测工程的技术管理、无损检测装备性能和人员技能评价；

(三)编制和审核无损检测工艺规程；

(四)确定用于特定对象的特殊无损检测方法、技术和工艺规程；

(五)对无损检测结果进行分析、评定或者解释；

(六)对Ⅰ级和Ⅱ级无损检测人员进行技能培训和工作指导。

未设置Ⅲ级项目的，Ⅲ级无损检测人员的工作由Ⅱ级无损检测人员承担。

## 第三章 取证

第九条 取证程序包括申请、受理、考试与发证。

第十条 无损检测人员的申请条件：

(一)年龄 18 周岁以上且不超过 60 周岁，具有完全民事行为能力；

(二)学历、无损检测经历等资历满足申请项目和级别的要求(见表2);

(三)申请射线检测、磁粉检测、渗透检测、漏磁检测的，单眼或者双眼裸视力或者矫正视力达到 GB 11533—2011《标准对数视力表》的 5.0 级以上，申请超声检测、声发射检测、涡流检测的，单眼或者双眼裸视力或者矫正视力达到 GB 11533—2011《标准对数视力表》的 4.8 级以上。申请磁粉检测、渗透检测的，不得有色盲；

(四)具备相应的特种设备无损检测知识和技能。

持有有关行业或者专业组织颁发的Ⅱ级、Ⅲ级无损检测资格证书，并且满足表2所列学历要求的申请人，在满足相应级别的学历和实践经历要求的情况下，可以申请相应项目和级别的特种设备无损检测人员资格，并且免除理论知识考试闭卷科目的考试。

表 2 特种设备无损检测人员申请资历条件(注 2)

<table><tr><td colspan="7">学历与无损检测经历(持证年限)</td></tr><tr><td>无损检测方法(项目)</td><td>级别</td><td>理工类本科及以上</td><td>理工类大专</td><td>非理工类本科及以上</td><td>非理工类大专,工学类中专、职高、技校</td><td>其他中专、职高、技校,初、高中</td></tr><tr><td>RT、UT、MT、PT、AE、ECT</td><td>III</td><td>持II级3年</td><td>持II级4年</td><td colspan="2">持II级6年</td><td>(注3)</td></tr><tr><td>RT、UT、MT、PT</td><td rowspan="4">II</td><td colspan="2">直接申请</td><td>持I级6个月</td><td>持I级1年</td><td>持I级3年</td></tr><tr><td>TOFD、PA</td><td colspan="5">持UT-II级2年,或者持UT-III级可直接申请</td></tr><tr><td>RT(D)</td><td colspan="5">持RT-II级2年,或者持RT-III级可直接申请</td></tr><tr><td>AE、ECT、UT(AUTO)、ECT(AUTO)、MFL(AUTO)</td><td colspan="5">直接申请</td></tr><tr><td>RT、UT、MT、PT</td><td>I</td><td colspan="5">直接申请</td></tr></table>

注 2：申请Ⅱ级、Ⅲ级资格时，所持相应要求的证书应当在有效期内。  
注3：其他中专、职高、技校，初、高中学历人员不能申请Ⅲ级无损检测人员资格取证。

第十一条 申请人应当向发证机关提交以下申请资料并对所提交资料的合法性、真实性、有效性负责：

(一)《特种设备检测人员资格申请表》(以下简称《申请表》，内容见附件 A, 1 份);

(二)视力证明(1份)。

第十二条 发证机关在收到申请后 5 个工作日内，应当作出是否受理的决定，需要申请人补充材料的，应当一次性告知申请人需要补正的内容。

予以受理的，发证机关应当在申请网站上告知申请人受理结果。申请人持受理结果到发证机关委托的考试机构报名，并按时参加考试。自受理之日起，申请人应当在2年内参加全部科目的考试并合格，方可获得《检测人员证》。

不予以受理的，发证机关应当告知申请人不予受理结果，并说明原因。

发证机关应当在申请网站上公告其委托的考试机构地址及其联系方式。

第十三条 射线胶片照相检测、脉冲反射法超声检测、磁粉检测、渗透检测的无损检测人员考试按照本规则附件 C 规定的考试大纲进行。其他项目无损检测人员的考试大纲由发证机关确认。

第十四条 无损检测人员的考试方式，包括理论知识考试(闭卷、开卷)和实际操作技能考试。理论知识考试采用国家统一题库。

第十五条 各科考试评分采用百分制，理论知识考试和实际操作技能考试均为70分合格。考试成绩未达到合格标准的科目允许在原考试机构补考1次；自受理之日起2年内未通过全部科目的，应当重新申请。

第十六条 发证机关应当在收到申请人的考试成绩后 20 个工作日内完成审批发证工作，并将《检测人员证》相关信息上传到“全国特种设备公示信息查询平台”向社会公示。

第十七条 以欺骗、贿赂等不正当手段取得《检测人员证》被发证机关撤销的，申请人在3年内不得再次申请。

## 第四章 换证

第十八条 持证人证书有效期届满，需要继续从事持证项目和级别的无损检测工作，并且未违反、未涉及本规则第三十四条(六)、(七)、(八)所规定的情况，应当在证书有效期届满的6个月以前、18个月以内，向发证机关提出换证申请。

换证申请时，申请人年龄应当不超过 65 周岁，并且视力满足本规则第十条第(三)项的规定。

第十九条 换证包括免考换证和考试换证两种方式。Ⅱ级、Ⅲ级无损检测人员满足下列要求的可以申请免考换证，I级无损检测人员满足下列(二)、(三)项要求可以申请免考换证：

(一)上次为考试换(取)证的；

(二)申请换证的相应项目和级别的证书在有效期内，并且未中断执业6个月以上；

(三)执业期间未发生过无损检测违规行为和责任事故。

第二十条 不满足免考换证条件的，应当申请考试换证。考试换证采用实际操作技能考试的方式。

第二十一条 考试换证不合格的，允许 1 年内在原考试机构补考 1 次。

第二十二条 换证申请时，申请人应当向发证机关提交以下资料：

(一)《申请表》(1份);

(二)视力证明(1份)。

第二十三条 已持有Ⅱ级以上《检测人员证》的人员，原《检测人员证》失效不超过1年的，可以直接申请原项目和级别的考试换证；原《检测人员证》失效1年以上不超过5年的，应当申请原项目和原级别以下(含原级别)的取证。

第二十四条 证书失效期间，禁止从事相关无损检测工作。

## 第五章 考试机构

第二十五条 发证机关委托考试机构进行考试,并且对考试机构的考试工作进行监督管理。考试机构应当符合以下基本要求：

(一)具备独立法人资质；

(二)不得从事特种设备生产、维护保养、经销和检验检测活动；

(三)具有满足与所承担的考试项目相适应的资源条件，考试前在考场使用信息化手段进行人证比对，留存考试影像资料；

(四)具有健全的考试管理、实际操作设备及试件管理、考评人员管理、保密管理、档案管理、财务管理、应急预案等各项规章制度及人证比对等计算机管理系统；制定有效的考场纪律规定及考评人员守则，并且有效实施。

第二十六条 考试机构不得发布与考试相关的培训信息,不得推荐或者指定与考试相关的培训机构，不得参与与考试相关的培训与辅导活动。

第二十七条 考试机构应当在考试前对申请人的身份证明原件、学历证明原件进行核查，发现申请人隐瞒有关情况或者提供虚假材料申请的，取消考试资格，并且报发证机关。

第二十八条 考试机构应当在考试结束后的 20 个工作日内公布考试合格人员名单，并将考试结果报送发证机关。申请人向考试机构查询成绩的，考试机构应当告知。

第二十九条 考试机构应当在每年 2 月底前在网上公布本年度考试计划，以及相关报名方式、报名截止日期、考试时间和考试项目等。每个项目和级别每年至少组织一次考试。

第三十条 考试机构公布的考试地点应相对固定，一般不设置在培训机构。考试机构按照公布的考试项目、考试时间组织考试。考试工作应当严格执行保密、监考等各项规章制度，确保考试工作公开、公正、公平、规范。

第三十一条 考试机构应当将考试试卷或者答题卡和机考记录、成绩汇总表、考场记录等资料(电子或者纸质)存档，保存时间不少于8年。

第三十二条 申请人如果对考试结果有异议，可以在考试成绩发布之日起的 1 个月以内向考试机构提出复核要求，考试机构应当在收到复核申请 20 个工作日以内予以答复；对考试机构答复结果有异议的，可以书面向发证机关提出申诉。

## 第六章 无损检测人员管理

第三十三条 对考试作弊的申请人，根据情节轻重，由考试机构给予取消考试资格、考试成绩无效的处理，并将处理结果报告发证机关，发证机关记入无损检测人员档案。

第三十四条 无损检测人员应当遵守如下执业要求：

(一)按照《中华人民共和国特种设备安全法》的有关规定，无损检测人员取得《检测人员证》后，应当承诺只在一个机构执业，变更执业机构的，应当办理变更注册手续；

(二)遵守法律、行政法规的规定，严格执行安全技术规范和管理制度，从事无损检测工作；

(三)客观、公正、真实地出具检测报告，并且对检测结果和鉴定结论负责；

(四)在无损检测中发现存在严重事故隐患时，立即告知相关单位，并及时向特种设备安全监管部门报告；

(五)在执业过程中，应当保守国家、行业、受聘单位及服务对象的商业、技术秘密，主动回避可能与本人发生利害关系的业务；

(六)坚持独立、客观、公正原则，拒绝签发虚假的检测报告；

(七)正确保管和使用本人的《检测人员证》，不得涂改、倒卖、出租、出借或者以其他形式转让；

(八)不得同时在两个或者两个以上单位执业。

第三十五条 无损检测人员提供虚假材料及承诺、不履行岗位职责、违反操作规程和有关安全规章制度的，发证机关依照《中华人民共和国特种设备安全法》《特《种设备安全监察条例》等法律法规处理并记入无损检测人员档案。

## 第七章 附 则

第三十六条 《检测人员证》样式见附件 B。《检测人员证》可加印二维码，也可采用电子证书形式颁发。

第三十七条 本规则所称的 “以上” “以下” “以内” “届满”，包括本数；所称的 “不超过”，不包括本数。

第三十八条 本规则由国家市场监督管理总局负责解释。

第三十九条 本规则自2019年6月1日起施行，2013年1月16日国家质检总局颁布的《特种设备无损检测人员考核规则》(TSG Z8001—2013)同时废止，相关文件和规定与本规则不一致的，以本规则为准。

附件 A

特种设备检测人员资格申请表

申请编号：

档案号：

申请日期：

<table><tr><td colspan="2">申请类别</td><td>☐取证考试</td><td>☐免试换证☐考试换证</td><td colspan="2">☐取证补考☐换证补考</td><td rowspan="4">(近期、1寸、免冠、正面、白底彩色照片)</td></tr><tr><td colspan="2">申请人姓名</td><td></td><td>性别</td><td colspan="2"></td></tr><tr><td colspan="2">身份证件类型</td><td></td><td>证件编号</td><td colspan="2"></td></tr><tr><td colspan="2">学历</td><td></td><td>专业</td><td colspan="2"></td></tr><tr><td colspan="2">技术职称</td><td></td><td>工作年限</td><td>年</td><td>移动电话</td><td></td></tr><tr><td colspan="2">电子邮箱</td><td colspan="3"></td><td>邮政编码</td><td></td></tr><tr><td colspan="2">通信地址</td><td colspan="5">省市区(县)街道(乡)小区(村、路、巷)楼号</td></tr><tr><td colspan="7">申请项目与级别</td></tr><tr><td colspan="6">项目</td><td>级别</td></tr><tr><td colspan="6">☐RT ☐RT(D) ☐UT ☐UT(AUTO) ☐TOFD ☐PA☐MT ☐PT ☐AE ☐ECT ☐ECT(AUTO) ☐MFL(AUTO)</td><td>☐III ☐II ☐I</td></tr><tr><td colspan="7">已持证项目与级别</td></tr><tr><td>序号</td><td>代号</td><td>级别</td><td colspan="3">初次取证日期</td><td>证书有效期</td></tr><tr><td>1</td><td></td><td></td><td colspan="3"></td><td></td></tr><tr><td>2</td><td></td><td></td><td colspan="3"></td><td></td></tr><tr><td>3</td><td></td><td></td><td colspan="3"></td><td></td></tr><tr><td>4</td><td></td><td></td><td colspan="3"></td><td></td></tr><tr><td>5</td><td></td><td></td><td colspan="3"></td><td></td></tr><tr><td rowspan="4">自我承诺</td><td colspan="6">是否未中断执业6个月以上(含6个月,仅在换证时填写)</td></tr><tr><td colspan="6">☐未中断 ☐中断</td></tr><tr><td colspan="6">执业期间是否未发生过无损检测违规行为和责任事故(仅在换证时填写)</td></tr><tr><td colspan="6">☐未发生过 ☐发生过</td></tr><tr><td colspan="7">申请人声明</td></tr><tr><td colspan="7">本人声明以上填写信息及所提交的资料均合法、真实、有效,并承诺对填写的内容负责。申请人(签字): 申请日期:</td></tr></table>

注：  
1. 申请人在网上申请的，填报申请表后打印签字并扫描上传。  
2. 受理机关应当通过人员执业注册系统，对申请人是否中断执业 6 个月以上 (含 6 个月) 进行核查。

附件 B

# 特种设备检验检测人员证(样式)

# 中华人民共和国 特种设备检验检测人员证 (无损检测人员)

黑体 二号

姓名： 宋体 三号

证书编号：

初次取证日期: 年 月

宋体 三号

经考核，批准项目和级别如下：

楷体 小三号

<table><tr><td>项目</td><td>级别</td><td>代号</td><td>备注</td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr></table>

发证机关:

宋体 小三号

发证日期: 年 月 日

宋体 小三号

有效期: 年 月至 年 月

附件 C

# 特种设备无损检测人员考试大纲

(符号说明：●—掌握；■—理解；▲—了解；“—”—不要求)

表 C-1 无损检测基本知识

<table><tr><td rowspan="2">内容及知识点</td><td colspan="3">各级要求</td></tr><tr><td>III</td><td>II</td><td>I</td></tr><tr><td>C1.1 材料基本知识</td><td></td><td></td><td></td></tr><tr><td>C1.1.1 材料力学基本知识</td><td></td><td></td><td></td></tr><tr><td>(1)应力和应力集中的概念</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)特种设备受压元件、受力结构件应力特点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)力学性能指标定义</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)抗拉强度、屈服强度的意义,拉伸曲线的解释</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(5)屈强比的概念</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)钢材的冷脆性</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(7)钢材的热脆性</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(8)氢对钢的性能的影响,氢脆发生条件,氢致损伤的种类</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(9)应力腐蚀发生条件,常见应力腐蚀种类,应力腐蚀敏感性影响因素</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C1.1.2 金属材料及热处理基本知识</td><td></td><td></td><td></td></tr><tr><td>(1)晶体和晶界的概念,金属常见晶体结构种类</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)铁碳合金的基本相结构及其特性</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)钢热处理的一般过程</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)钢中碳和合金元素对C曲线的影响</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(5)钢常见金相组织和性能</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)特种设备常用的热处理种类、工艺条件及其应用</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(7)消除应力退火处理的目的和方法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C1.1.3 特种设备常用的材料</td><td></td><td></td><td></td></tr><tr><td>(1)特种设备用材料的基本要求</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)低碳钢、低合金钢的定义</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)低碳钢中碳和杂质元素对钢的性能的影响</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)低合金钢中合金元素对钢的性能的影响</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(5)低温用钢种类、特点和基本性能</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)影响低温钢低温韧性的因素</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(7)低合金耐热钢种类、特点、高温下钢材性能的劣化现象</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(8)奥氏体不锈钢种类、特点、腐蚀破坏形式</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C1.2 焊接基本知识</td><td></td><td></td><td></td></tr><tr><td>C1.2.1 特种设备常用的焊接方法</td><td></td><td></td><td></td></tr><tr><td>特种设备常用焊接方法的种类、特点和适用范围</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C1.2.2 焊接接头</td><td></td><td></td><td></td></tr><tr><td>(1)常见的焊接接头形式、分类及特点</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)焊接接头组成</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)焊接接头薄弱部位</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C1.2.3 焊接应力与变形</td><td></td><td></td><td></td></tr><tr><td>(1)焊接应力与变形的不利影响</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)焊接变形与应力的关系,影响焊接变形与应力的因素</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C1.2.4 特种设备常用钢材的焊接</td><td></td><td></td><td></td></tr><tr><td>(1)钢材焊接性的含义</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)焊接性试验的主要作用</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)焊接工艺评定的作用及其过程</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)焊前预热和后热的作用</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(5)焊接线能量的变化对低合金结构钢、低温钢、奥氏体不锈钢焊接接头性能的影响</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)奥氏体不锈钢的焊接性,防止热裂纹和晶间腐蚀倾向的措施</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C1.3 无损检测基本知识</td><td></td><td></td><td></td></tr><tr><td>C1.3.1 无损检测概论</td><td></td><td></td><td></td></tr><tr><td>(1)无损检测定义,无损检测技术进展的三个阶段</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)无损检测的目的,无损检测的应用特点</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C1.3.2 焊接缺陷种类及产生原因</td><td></td><td></td><td></td></tr><tr><td>(1)外观缺陷种类、形成原因及危害</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)气孔缺陷种类、形成原因、危害及防止措施</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(3)夹渣种类、形成原因、危害及防止措施</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(4)裂纹种类、形态、发生部位、形成原因、危害及防止措施</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(5)未焊透种类、形成原因、危害及防止措施</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(6)未熔合种类、形成原因、危害及防止措施</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C1.3.3 其他试件中缺陷种类及产生原因</td><td></td><td></td><td></td></tr><tr><td>(1)铸件中缺陷种类及产生原因</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>(2)锻件中缺陷种类及产生原因</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>(3)使用件中缺陷种类及产生原因</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C1.4 特种设备法律法规知识</td><td>●</td><td>●</td><td>■</td></tr></table>

表 C-2 射线胶片照相检测

<table><tr><td rowspan="2">内容及知识点</td><td colspan="3">各级要求</td></tr><tr><td>III</td><td>II</td><td>I</td></tr><tr><td>C2.1 射线基本知识</td><td></td><td></td><td></td></tr><tr><td>C2.1.1 原子与原子结构</td><td></td><td></td><td></td></tr><tr><td>(1)元素和原子</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)核外电子运动规律</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)原子核结构</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C2.1.2 射线的种类和性质</td><td></td><td></td><td></td></tr><tr><td>(1)X射线的产生及其特点</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)γ射线的产生及其特点</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)工业检测常用放射性同位素的特性</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.1.3 射线与物质的相互作用</td><td></td><td></td><td></td></tr><tr><td>(1)光电效应、康普顿效应、电子对效应和锐利效应</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)各种相互作用发生的相对几率</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)窄束、单色射线的强度衰减规律</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)宽束、多色射线的强度衰减规律</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(5)连续X射线吸收(衰减)系数测试和吸收(衰减)曲线</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(6)截面与吸收系数</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.1.4 射线照相法的原理与特点</td><td></td><td></td><td></td></tr><tr><td>(1)射线照相法的原理</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)射线照相法的特点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C2.2 无损检测仪器及器材</td><td></td><td></td><td></td></tr><tr><td>C2.2.1 无损检测仪器</td><td></td><td></td><td></td></tr><tr><td>C2.2.1.1 X射线机</td><td></td><td></td><td></td></tr><tr><td>(1)X射线机的种类和特点</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)X射线管</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)高压发生电路</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)X射线机的基本结构</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(5)X射线机的主要技术条件</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)X射线机的使用和维护</td><td>■</td><td>●</td><td>▲</td></tr><tr><td>C2.2.1.2 γ射线机</td><td></td><td></td><td></td></tr><tr><td>(1)γ射线源的主要特性参数</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(2)γ射线检测设备的特点</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>(3)γ射线检测设备的分类与结构</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>(4)γ射线探伤机的操作</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(5)γ射线探伤机的维护和故障排除</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>C2.2.2 无损检测器材</td><td></td><td></td><td></td></tr><tr><td>C2.2.2.1 射线照相胶片</td><td></td><td></td><td></td></tr><tr><td>(1)射线照相胶片的构造与特点</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)感光原理及潜影的形成</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(3)底片黑度</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)射线胶片的特性</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(5)卤化银粒度对胶片性能的影响</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(6)胶片的光谱感光度</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(7)工业射线胶片系统的分类</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(8)胶片的使用与保管</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(9)颗粒度测量</td><td>●</td><td>—</td><td>—</td></tr><tr><td>C2.2.2.2 射线照相辅助设备器材</td><td></td><td></td><td></td></tr><tr><td>(1)黑度计(光密度计)</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(2)增感屏</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(3)像质计</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(4)其他照相辅助设备器材</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>C2.3 照相质量控制</td><td></td><td></td><td></td></tr><tr><td>C2.3.1 射线照相灵敏度的影响因素</td><td></td><td></td><td></td></tr><tr><td>(1)概述</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)射线照相对比度</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)射线照相清晰度</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)射线照相颗粒度</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(5)射线照相裂纹检出研究</td><td>●</td><td>—</td><td>—</td></tr><tr><td>(6)信噪比</td><td>●</td><td>—</td><td>—</td></tr><tr><td>C2.3.2 射线照相的缺陷检出研究</td><td></td><td></td><td></td></tr><tr><td>(1)最小可见对比度 $\Delta D_{\min}$ </td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)射线底片黑度与相灵敏度</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(3)缺陷检出试验</td><td>■</td><td>—</td><td>—</td></tr><tr><td>(4)几何因素对小缺陷检出的影响</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(5)不同缺陷的灵敏度关系公式</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C2.4 射线检测工艺</td><td></td><td></td><td></td></tr><tr><td>C2.4.1 透照工艺条件的选择</td><td></td><td></td><td></td></tr><tr><td>(1)射线源和能量的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)焦距的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)曝光量的选择和修正</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C2.4.2 透照方式的选择和一次透照长度的计算</td><td></td><td></td><td></td></tr><tr><td>(1)透照方式的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)一次透照长度的计算</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.4.3 曝光曲线的制作及应用</td><td></td><td></td><td></td></tr><tr><td>(1)曝光曲线的构成和使用条件</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)曝光曲线的制作</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(3)曝光曲线的使用</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C2.4.4 散射线的控制</td><td></td><td></td><td></td></tr><tr><td>(1)散射线的来源和分类</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)散射比的影响因素</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)散射线的控制措施</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.4.5 焊缝透照工艺</td><td></td><td></td><td></td></tr><tr><td>(1)焊缝透照工艺的分类和一般内容</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)焊缝透照专用工艺卡示例</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)焊缝透照工艺编制和审核</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)焊缝透照的基本操作</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)大厚度比工件、管座角焊缝、管子-管板角焊缝、小径管等特殊焊缝的透照工艺</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.5 暗室处理</td><td></td><td></td><td></td></tr><tr><td>C2.5.1 暗室基本知识</td><td></td><td></td><td></td></tr><tr><td>(1)暗室布置知识</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)暗室设备器材使用知识</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(3)配液注意事项</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(4)胶片处理程序和操作要点</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(5)胶片处理的药液配方</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)控制使用单位的胶片处理条件的方法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C2.5.2 暗室处理技术</td><td></td><td></td><td></td></tr><tr><td>(1)显影</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)停影</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(3)定影</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(4)水洗和干燥</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C2.5.3 自动洗片机特点和使用注意事项</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>C2.6 评片</td><td></td><td></td><td></td></tr><tr><td>C2.6.1 评片工作的基本要求</td><td></td><td></td><td></td></tr><tr><td>(1)底片的质量要求</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)设备环境条件要求</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)人员条件要求</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)与评片基本要求相关的知识</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>C2.6.2 评片基本知识</td><td></td><td></td><td></td></tr><tr><td>(1)观片的基本操作</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)投影的基本概念</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)焊接的基本知识</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)焊接缺陷的危害性及分类</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>C2.6.3 底片影像分析</td><td></td><td></td><td></td></tr><tr><td>(1)焊接缺陷影像</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)常见伪缺陷影像及识别方法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)表面几何影像的识别</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)底片影像分析要点</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.6.4 焊接接头的质量等级评定</td><td></td><td></td><td></td></tr><tr><td>(1)焊接接头质量分级规定</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)射线照相检验的记录与报告</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C2.7 安全防护</td><td></td><td></td><td></td></tr><tr><td>C2.7.1 辐射防护的定义、单位与标准</td><td></td><td></td><td></td></tr><tr><td>(1)描述电离辐射的常用辐射量和单位</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)描述辐射防护的常用辐射量和单位</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C2.7.2 剂量测定方法和仪器</td><td></td><td></td><td></td></tr><tr><td>(1)辐射监测内容和分类</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(2)剂量测定仪器的工作原理</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(3)剂量仪器的选择及其校准</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)场所辐射监测仪器</td><td>●</td><td>■</td><td>■</td></tr><tr><td>(5)个人剂量监测仪器</td><td>●</td><td>■</td><td>■</td></tr><tr><td>C2.7.3 辐射防护的原则、标准和辐射损伤机理</td><td></td><td></td><td></td></tr><tr><td>(1)辐射防护的目的和基本原则</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)剂量限值规定</td><td>●</td><td>●</td><td>●</td></tr><tr><td>(3)辐射损伤的机理</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>C2.7.4 辐射防护的基本方法和防护计算</td><td></td><td></td><td></td></tr><tr><td>(1)辐射防护的基本方法</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)照射量的计算</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)防护计算</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)屏蔽防护常用材料</td><td>■</td><td>▲</td><td>▲</td></tr><tr><td>C2.7.5 辐射防护安全管理</td><td></td><td></td><td></td></tr><tr><td>(1)辐射防护法规与标准</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)辐射防护管理责任部门</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(3)射线装置申请许可制度</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)辐射防护培训</td><td>●</td><td>■</td><td>■</td></tr><tr><td>(5)辐射工作人员证书与健康的管理</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(6)辐射事故管理人员管理的主要内容</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C2.8 其他射线方法</td><td></td><td></td><td></td></tr><tr><td>C2.8.1 高能射线照相</td><td></td><td></td><td></td></tr><tr><td>(1)电子回旋加速器和电子直线加速器</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(2)高能射线照相的特点</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(3)高能射线照相的几个技术数据</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(4)电子直线加速器的结构、原理及操作</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(5)高能射线的辐射防护</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>C2.8.2 射线实时成像检测技术</td><td></td><td></td><td></td></tr><tr><td>(1)射线实时成像检测系统的进展</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)射线实时成像检测系统的图像特点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)射线实时成像检测技术的工艺要点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)图像增强器射线实时成像系统的优点和局限性</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C2.8.3 计算机射线照相技术</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C2.8.4 X射线层析照相技术(X-CT)</td><td></td><td></td><td></td></tr><tr><td>X射线层析照相技术的特点</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C2.9 射线检测工作管理</td><td></td><td></td><td></td></tr><tr><td>C2.9.1 射线检测质量管理</td><td></td><td></td><td></td></tr><tr><td>(1)射线检测人员的管理</td><td>●</td><td>▲</td><td>—</td></tr><tr><td>(2)射线检测设备和器材的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)射线检测工艺的管理</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)射线检测环境的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.9.2 射线检测报告、底片及原始记录控制和档案管理</td><td></td><td></td><td></td></tr><tr><td>(1)射线检测报告的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)射线检测记录的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)射线检测底片的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)射线检测档案的管理</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C2.10 射线检测标准</td><td>●</td><td>■</td><td>▲</td></tr></table>

表 C-3 脉冲反射法超声检测

<table><tr><td rowspan="2">内容及知识点</td><td colspan="3">各级要求</td></tr><tr><td>III</td><td>II</td><td>I</td></tr><tr><td>C3.1 声波基础知识</td><td></td><td></td><td></td></tr><tr><td>C3.1.1 机械振动与机械波</td><td></td><td></td><td></td></tr><tr><td>(1)机械振动、谐振动、阻尼振动、受迫振动</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(2)机械波的产生与传播,波动方程</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)波长、周期、频率和波速</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(4)波的分类,次声波、声波、超声波,超声波的应用</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C3.1.2 波的类型</td><td></td><td></td><td></td></tr><tr><td>(1)纵波、横波、表面波</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)平面波、柱面波、球面波、波前、波线、波阵面</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)连续波、脉冲波</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.1.3 波的迭加、干涉和衍射</td><td></td><td></td><td></td></tr><tr><td>(1)迭加原理、波的干涉</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)惠更斯原理、波的衍射(绕射)</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.1.4 超声波的传波速度</td><td></td><td></td><td></td></tr><tr><td>(1)无限大固体介质中的纵波、横波与表面波声速</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)声速与温度、应力及介质材质均匀性的关系</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)兰姆波的相速度和群速度</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C3.1.5 超声场的特征值</td><td></td><td></td><td></td></tr><tr><td>(1)声压、声阻抗、声强</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)分贝与奈培</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.1.6 超声波垂直入射到界面时的反射和透射</td><td></td><td></td><td></td></tr><tr><td>(1)单一平界面的反射率与透射率</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)薄层界面的反射率与透射率</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)声压往复透过率</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.1.7 超声波倾斜入射到界面时的反射和折射</td><td></td><td></td><td></td></tr><tr><td>(1)波型转换与反射、折射定律</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)声压反射率</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)声压往复透射率</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)端角反射</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.1.8 超声波的聚焦与发散</td><td></td><td></td><td></td></tr><tr><td>(1)声压距离公式</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)球面波在平界面上的反射与折射</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)平面波在曲界面上的反射与折射</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)球面波在曲界面上的反射与折射C3.1.9 超声波的衰减</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(1)衰减的原因</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)衰减方程与衰减系数</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)衰减系数的测定</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.2 超声检测工作原理</td><td></td><td></td><td></td></tr><tr><td>C3.2.1 纵波发射声场</td><td></td><td></td><td></td></tr><tr><td>(1)圆盘波源辐射的纵波声场</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)矩形波源辐射的纵波声场</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)纵波声场近场区在两种介质中的分布</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.2.2 横波发射声场</td><td></td><td></td><td></td></tr><tr><td>(1)假想横波波源</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)横波声场的结构</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.2.3 聚焦声源发射声场</td><td></td><td></td><td></td></tr><tr><td>(1)聚焦声场的形成</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)聚焦声场的特点与应用</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.2.4 规则反射体的回波声压</td><td></td><td></td><td></td></tr><tr><td>(1)平底孔回波声压</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)短横孔回波声压</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)长横孔回波声压</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)球孔回波声压</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(5)大平底面回波声压</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)圆柱曲底面回波声压</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.2.5 AVG 曲线</td><td></td><td></td><td></td></tr><tr><td>(1)纵波平底孔 AVG 曲线</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(2)横波平底孔 AVG 曲线</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C3.3 无损检测仪器、探头和试块</td><td></td><td></td><td></td></tr><tr><td>C3.3.1 无损检测仪器</td><td></td><td></td><td></td></tr><tr><td>C3.3.1.1 超声检测仪</td><td></td><td></td><td></td></tr><tr><td>(1)超声检测仪的作用和分类</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)A型显示</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(3)B型显示、C型显示</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)模拟式超声检测仪</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(5)数字式超声检测仪</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(6)仪器的维护保养</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>C3.3.1.2 超声测厚仪</td><td></td><td></td><td></td></tr><tr><td>(1)共振式测厚仪、脉冲反射式测厚仪、兰姆波测厚仪</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)测厚仪的调整与应用</td><td>●</td><td>●</td><td>●</td></tr><tr><td>C3.3.2 超声探头</td><td></td><td></td><td></td></tr><tr><td>(1)压电效应与压电材料</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)压电材料的主要性能参数</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)探头的结构</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)直探头、斜探头、双晶探头、聚焦探头、水浸探头</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(5)高温探头、电磁探头、爬波探头</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(6)探头型号</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>C3.3.3 试块</td><td></td><td></td><td></td></tr><tr><td>(1)试块的分类和作用</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)标准试块的要求</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(3)常用的标准试块,IIW试块、IIW2试块、CSK-1A试块</td><td>●</td><td>●</td><td>■</td></tr><tr><td>(4)对比试块</td><td>●</td><td>■</td><td>■</td></tr><tr><td>(5)模拟试块</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(6)试块的使用和维护</td><td>●</td><td>●</td><td>●</td></tr><tr><td>C3.3.4 仪器和探头的性能及其测试</td><td></td><td></td><td></td></tr><tr><td>(1)超声检测仪、探头的主要性能及其组合性能</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)超声检测仪、探头及其组合性能的测试方法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.4 超声检测方法和基本检测技术</td><td></td><td></td><td></td></tr><tr><td>C3.4.1 超声检测方法概述</td><td></td><td></td><td></td></tr><tr><td>(1)脉冲反射法</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)衍射时差法、穿透法、共振法</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)纵波法、横波法</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(4)表面波法、板波法、爬波法</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(5)单探头法、双探头法、多探头法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(6)直接接触法、液浸法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(7)超声波检测方法的应用</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.4.2 仪器和探头的选择</td><td></td><td></td><td></td></tr><tr><td>(1)仪器的选择</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)探头的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.4.3 耦合与补偿</td><td></td><td></td><td></td></tr><tr><td>(1)耦合剂的作用、要求、种类及应用</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(2)影响声耦合的主要因素</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(3)表面耦合损耗的测定和补偿</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.4.4 检测仪的调节</td><td></td><td></td><td></td></tr><tr><td>(1)扫描速度的调节</td><td>●</td><td>●</td><td>●</td></tr><tr><td>(2)检测灵敏度的调节</td><td>●</td><td>●</td><td>●</td></tr><tr><td>C3.4.5 缺陷位置的测定</td><td></td><td></td><td></td></tr><tr><td>(1)纵波(直探头)检测时缺陷定位</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)表面波检测时缺陷定位</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)横波检测时缺陷定位</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)横波周向探测圆柱曲面时缺陷定位</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.4.6 缺陷大小的测定</td><td></td><td></td><td></td></tr><tr><td>(1)当量法:当量试块比较法、当量计算法、当量AVG曲线法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)测长法:相对灵敏度测长法、绝对灵敏度测长法、端点峰值法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)底波高度法: $F/B_F$ 法、 $F/B_G$ 法、 $B_G/B_F$ 法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.4.7 缺陷自身高度的测定</td><td></td><td></td><td></td></tr><tr><td>端部最大回波法、横波端角反射法、6dB法、端点衍射波法</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C3.4.8 影响缺陷定位、定量的主要因素</td><td></td><td></td><td></td></tr><tr><td>(1)影响缺陷定位的主要因素</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)影响缺陷定量的因素</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.4.9 非缺陷回波的判别</td><td></td><td></td><td></td></tr><tr><td>(1)迟到波、61度反射、三角反射</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)端角反射波、山形波</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)其他非缺陷回波</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.4.10 侧壁干涉</td><td></td><td></td><td></td></tr><tr><td>侧壁干涉对检测的影响、避免侧壁干涉的条件</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.4.11 超声检测工艺编制</td><td></td><td></td><td></td></tr><tr><td>(1)超声工艺的分类和一般内容</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)超声检测工艺编制和审核</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C3.5 板材和管材超声检测</td><td></td><td></td><td></td></tr><tr><td>C3.5.1 板材超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)钢板加工及常见缺陷</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)检测方法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)探头与扫查方式的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)探测范围和灵敏度的调整</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)缺陷的判别与测定</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)钢板质量级别的判别</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.5.2 复合钢板超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)复合材料中常见的缺陷、检测方法</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)缺陷的判别、缺陷测定与评级</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.5.3 管材超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)管材加工及常见缺陷</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)小径管薄壁管检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)大直径薄壁管检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)管材自动检测</td><td>—</td><td>▲</td><td>—</td></tr><tr><td>C3.6 锻件与铸件超声检测</td><td></td><td></td><td></td></tr><tr><td>C3.6.1 锻件超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)锻件加工及常见缺陷</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)检测方法概述</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)探测条件的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)扫描速度和灵敏度的调节</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)缺陷位置和大小的测定</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)缺陷回波的判别</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(7)非缺陷回波分析</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(8)锻件质量级别的评定</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.6.2 铸件超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)铸件的特点及常见缺陷</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)铸件超声检测的特点及常用技术</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7 焊缝超声检测</td><td></td><td></td><td></td></tr><tr><td>C3.7.1 焊接加工及常见缺陷</td><td></td><td></td><td></td></tr><tr><td>(1)焊接过程、坡口形式和接头形式</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)常见焊接缺陷</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.7.2 对接焊缝超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)检测技术等级选择</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)检测方法和检测条件选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)标准试块</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)扫描速度的调节</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)距离一波幅曲线和灵敏度调节</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)传输修正</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(7)扫查方式</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(8)扫查速度和扫查间距</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(9)缺陷的评定和质量分级</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.7.3 角焊缝的超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)管座角焊缝超声检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)T形焊接接头的超声检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7.4 堆焊层超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)堆焊层中常见缺陷、堆焊层晶体结构特点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)堆焊层内缺陷检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)堆焊层与母材之间未结合缺陷检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)堆焊层下母材热影响区再热裂纹的检测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7.5 奥氏体不锈钢焊缝超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)组织结构特点和检测方法</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)检测条件的选择,仪器调整与探测</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)灵敏度调节,缺陷评定和质量分级</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7.6 铝焊缝超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)结构特点与常见缺陷</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)检测准备和仪器调整</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)缺陷的测定与评级</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7.7 小径管对接焊缝超声检测</td><td></td><td></td><td></td></tr><tr><td>(1)小径管焊接接头中常见缺陷</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)仪器的调整,探测区域、探测打磨范围</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)扫查探测与缺陷判别</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C3.7.8 焊缝检测中缺陷性质与非缺陷波的判别</td><td></td><td></td><td></td></tr><tr><td>(1)缺陷波形:静态波形、动态波形</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)缺陷类型识别和性质估判</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(3)非缺陷回波分析</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C3.8 超声检测标准</td><td>●</td><td>■</td><td>▲</td></tr></table>

表 C-4 磁粉检测

<table><tr><td rowspan="2">内容及知识点</td><td colspan="3">各级要求</td></tr><tr><td>III</td><td>II</td><td>I</td></tr><tr><td>C4.1 基本知识</td><td></td><td></td><td></td></tr><tr><td>C4.1.1 漏磁场检测与磁粉检测</td><td></td><td></td><td></td></tr><tr><td>(1)磁粉检测原理</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(2)磁粉检测适用范围</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(3)磁粉检测优点和局限性</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)检测元件</td><td>●</td><td>■</td><td>■</td></tr><tr><td>C4.1.2 表面缺陷无损检测方法的比较</td><td></td><td></td><td></td></tr><tr><td>(1)方法原理及适用范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)能检测出的缺陷及表现形式</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.2 磁粉检测物理基础</td><td></td><td></td><td></td></tr><tr><td>C4.2.1 磁现象和磁场</td><td></td><td></td><td></td></tr><tr><td>(1)磁的基本现象</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(2)磁场的定义、特性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)磁感应(力)线(定义、特性)</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)圆周磁场、纵向磁化</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(5)磁感应强度(定义、特性)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)磁通量</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(7)毕奥—萨伐尔定律</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>(8)安培环路定律</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(9)磁介质(定义、分类)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(10)极化强度的定义和基本概念</td><td>■</td><td>—</td><td>—</td></tr><tr><td>(11)磁场强度(定义、特性)</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C4.2.2 铁磁性材料</td><td></td><td></td><td></td></tr><tr><td>(1)磁畴(定义、特性)</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)磁化过程特性及其应用</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)磁化曲线定义、表征特性</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)磁滞回线定义</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(5)铁磁性材料磁滞回线的特性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)软磁材料、硬磁材料磁滞回线的特征C4.2.3 电流与磁场</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(1)通电圆柱导体的方向(右手定则)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)通电圆柱导体的磁场强度计算</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)钢棒通电法磁化的磁场特征</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(4)通电钢管的磁场强度计算</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)通电线圈的磁场特征及方向(右手定则)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)通电线圈磁场强度计算</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(7)线圈分类</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(8)开路磁化和闭路磁化</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(9)感应电流和感应磁场</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.2.4 磁场的合成</td><td></td><td></td><td></td></tr><tr><td>(1)交叉磁轭的磁场合成</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)摆动磁轭的磁场合成</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.2.5 退磁场</td><td></td><td></td><td></td></tr><tr><td>(1)退磁场概念</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)有效磁场</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)影响退磁场大小的因素</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)退磁场计算</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.2.6 磁路与磁感应线的折射</td><td></td><td></td><td></td></tr><tr><td>(1)磁路的基本概念、磁路定律及表达式</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)磁路定律的计算</td><td>●</td><td>—</td><td>—</td></tr><tr><td>(3)磁感应线的折射定律及表达式,磁感应强度的边界条件</td><td>■</td><td>—</td><td>—</td></tr><tr><td>C4.2.7 漏磁场</td><td></td><td></td><td></td></tr><tr><td>(1)漏磁场的形成</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)缺陷的漏磁场分布</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)影响漏磁场的因素</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C4.2.8 磁粉检测的光学基础</td><td></td><td></td><td></td></tr><tr><td>(1)光度量术语及单位</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)紫外线</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(3)黑光灯</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.3 磁化电流、磁化方法和磁化规范</td><td></td><td></td><td></td></tr><tr><td>C4.3.1 磁化电流</td><td></td><td></td><td></td></tr><tr><td>(1)交流电的定义、物理量、优点和局限性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)交流电的趋肤效应</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)交流电断电相位的影响</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(4)非正弦交流电</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(5)整流电分类、物理量、优点和局限性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)直流电优点和局限性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(7)冲击电流</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(8)如何选用磁化电流</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C4.3.2 磁化方法</td><td></td><td></td><td></td></tr><tr><td>(1)磁场方向与发现缺陷的关系</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)磁化方法的分类</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)轴向通电法的特点、优缺点和适用范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(4)中心导体法的特点、优缺点和适用范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(5)偏置芯棒法的特点、适用范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)触头法的特点、优缺点和适用范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(7)感应电流法的特点、优缺点和适用范围</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(8)环形件绕电缆法的特点、优缺点和适用范围</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(9)线圈法的特点、优缺点和适用范围</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(10)磁轭法的特点、优缺点和适用范围</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(11)永久磁轭法的特点、优缺点</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(12)交叉磁轭法的特点、优缺点和适用范围</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(13)直流电磁轭和交流通电法复合磁化的特点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.3.3 磁化规范</td><td></td><td></td><td></td></tr><tr><td>(1)制定磁化规范考虑因素</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)制定磁化规范的方法</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)轴向通电法和中心导体法磁化规范</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)偏置芯棒法磁化规范</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)触头法磁化规范</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)线圈法磁化规范</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(7)磁轭法磁化规范</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.4 磁粉检测器材</td><td></td><td></td><td></td></tr><tr><td>C4.4.1 磁粉</td><td></td><td></td><td></td></tr><tr><td>(1)荧光磁粉和非荧光磁粉(特性、要求和应用)</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(2)磁粉的性能:磁特性、粒度、形状、流动性和密度、识别度</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)磁粉的验收试验:污染、颜色、粒度、灵敏度、悬浮性和耐用性</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.4.2 载液</td><td></td><td></td><td></td></tr><tr><td>(1)油基载液(特性及要求)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)水载液(特性及要求)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.4.3 磁悬液</td><td></td><td></td><td></td></tr><tr><td>(1)磁悬液浓度(定义、要求和应用)</td><td>■</td><td>■</td><td>■</td></tr><tr><td>(2)磁悬液配制(配制方法和要求)</td><td>■</td><td>■</td><td>●</td></tr><tr><td>C4.4.4 反差增强剂</td><td></td><td></td><td></td></tr><tr><td>(1)应用、配方、施加及清除</td><td>■</td><td>■</td><td>■</td></tr><tr><td>(2)反差增强剂喷罐</td><td>■</td><td>■</td><td>■</td></tr><tr><td>C4.4.5 标准试片和标准试块</td><td></td><td></td><td></td></tr><tr><td>(1)标准试片(用途、分类、使用)</td><td>●</td><td>●</td><td>●</td></tr><tr><td>(2)标准试块(用途、分类)</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)自然缺陷试块</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.5 磁粉检测设备</td><td></td><td></td><td></td></tr><tr><td>C4.5.1 磁粉检测设备的命名方法</td><td></td><td></td><td></td></tr><tr><td>(1)命名方法</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(2)命名参数</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C4.5.2 磁粉检测设备的分类</td><td></td><td></td><td></td></tr><tr><td>(1)固定式探伤机(结构特征及应用范围)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)移动式探伤机(结构特征及应用范围)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)便携式探伤机(结构特征及应用范围)</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.5.3 磁粉检测设备的组成部分</td><td></td><td></td><td></td></tr><tr><td>(1)磁化电源</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)工件夹持装置(装置特点及要求)</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(3)指示装置(电流表、电压表的精度和量程)</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(4)磁粉和磁悬液喷洒装置(装置组成和技术要求)</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(5)照明装置</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(6)退磁装置</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C4.5.4 常用典型磁粉检测设备</td><td></td><td></td><td></td></tr><tr><td>常用典型磁粉检测设备举例</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C4.6 磁粉检测工艺</td><td></td><td></td><td></td></tr><tr><td>C4.6.1 预处理</td><td></td><td></td><td></td></tr><tr><td>预处理要求和注意事项</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.6.2 磁化、施加磁粉或磁悬液</td><td></td><td></td><td></td></tr><tr><td>(1)连续法操作要点和优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)剩磁法操作要点和优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)湿法操作要点和优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)干法操作要点和优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.6.3 磁痕观察、记录与缺陷评级</td><td></td><td></td><td></td></tr><tr><td>磁痕观察方法、显示记录方法和缺陷评级</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.6.4 退磁</td><td></td><td></td><td></td></tr><tr><td>(1)剩磁的产生与影响</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)退磁的原理</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(3)退磁方法和退磁设备</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(4)退磁注意事项</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(5)剩磁测量</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.6.5 后处理与合格工件的标记</td><td></td><td></td><td></td></tr><tr><td>(1)后处理</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(2)合格工件的标记</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C4.6.6 超标缺陷磁痕显示的处理和复验</td><td></td><td></td><td></td></tr><tr><td>(1)超标缺陷磁痕显示的处理</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(2)复验</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.6.7 影响磁粉检测灵敏度的主要因素</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.7 磁痕分析与质量分级</td><td></td><td></td><td></td></tr><tr><td>C4.7.1 磁痕分析的意义</td><td></td><td></td><td></td></tr><tr><td>磁痕产生的原因、磁痕分析的意义</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.7.2 伪显示</td><td></td><td></td><td></td></tr><tr><td>产生原因、磁痕特征和鉴别方法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.7.3 非相关显示</td><td></td><td></td><td></td></tr><tr><td>产生原因、磁痕特征和鉴别方法</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.7.4 相关显示</td><td></td><td></td><td></td></tr><tr><td>(1)原材料缺陷磁痕显示</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)热加工产生的缺陷磁痕显示</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)冷加工产生的缺陷磁痕显示</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(4)使用后产生的缺陷磁痕显示</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(5)电镀产生的缺陷磁痕显示</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(6)常见缺陷磁痕显示比较</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.7.5 磁粉检测质量分级</td><td></td><td></td><td></td></tr><tr><td>(1)磁痕分类</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)磁粉检测质量分级</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C4.8 磁粉检测应用</td><td></td><td></td><td></td></tr><tr><td>C4.8.1 焊接件磁粉检测</td><td></td><td></td><td></td></tr><tr><td>(1)焊接件检测的内容与范围</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)检测方法选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)焊接件检测实例</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.8.2 锻钢件磁粉检测</td><td></td><td></td><td></td></tr><tr><td>(1)锻钢件检测的特点</td><td>■</td><td>■</td><td>—</td></tr><tr><td>(2)锻钢件检测方法选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)锻钢件检测实例</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.8.3 铸钢件磁粉检测</td><td></td><td></td><td></td></tr><tr><td>(1)铸钢件检测的特点</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)铸钢件检测实例</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.8.4 在用与维修件磁粉检测</td><td></td><td></td><td></td></tr><tr><td>(1)在用与维修件磁粉检测的要求</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)在用与维修件磁粉检测的特点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(3)在用与维修件磁粉检测实例</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C4.9 质量控制与安全防护</td><td></td><td></td><td></td></tr><tr><td>C4.9.1 磁粉检测质量控制</td><td></td><td></td><td></td></tr><tr><td>人员、设备、材料、检测工艺、检测环境资格的控制</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C4.9.2 磁粉检测安全防护</td><td></td><td></td><td></td></tr><tr><td>潜在危险因素,安全防护措施</td><td>■</td><td>●</td><td>●</td></tr><tr><td>C4.10 磁粉检测工艺编制</td><td></td><td></td><td></td></tr><tr><td>C4.10.1 磁粉检测工艺种类、一般内容和检测工艺程序</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C4.10.2 磁粉检测工艺编制与审核</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C4.11 国内、外磁粉检测标准对比分析</td><td></td><td></td><td></td></tr><tr><td>磁悬液浓度、校验项目、线圈法磁化的有效磁化区、剩磁法的应用、检测质量分级</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>C4.12 磁粉检测标准</td><td>●</td><td>■</td><td>▲</td></tr></table>

表 C-5 渗透检测

<table><tr><td rowspan="2">内容及知识点</td><td colspan="3">各级要求</td></tr><tr><td>III</td><td>II</td><td>I</td></tr><tr><td>C5.1 渗透检测的基础知识</td><td></td><td></td><td></td></tr><tr><td>(1)渗透检测的定义和作用</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(2)渗透检测工作原理</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(3)渗透检测方法的分类</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(4)渗透检测的基本步骤</td><td>■</td><td>■</td><td>▲</td></tr><tr><td>(5)渗透检测的优点和局限性</td><td>■</td><td>■</td><td>—</td></tr><tr><td>C5.2 渗透检测的表面化学基础</td><td></td><td></td><td></td></tr><tr><td>C5.2.1 表面张力和表面张力系数</td><td></td><td></td><td></td></tr><tr><td>(1)表面张力和表面张力系数概念</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)表面张力产生机理</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)表面过剩自由能</td><td>▲</td><td>—</td><td>—</td></tr><tr><td>C5.2.2 润湿现象</td><td></td><td></td><td></td></tr><tr><td>(1)润湿或不润湿现象</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)润湿方程与接触角</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)润湿的三种方式和润湿的四个等级</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(4)润湿现象的产生机理</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C5.2.3 毛细现象</td><td></td><td></td><td></td></tr><tr><td>(1)毛细现象</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)毛细管内液面高度</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)渗透检测中的毛细现象</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.2.4 吸附现象</td><td></td><td></td><td></td></tr><tr><td>(1)固体表面的吸附现象</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)液体表面的吸附现象</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)渗透检测中的吸附现象</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.2.5 溶解现象</td><td></td><td></td><td></td></tr><tr><td>(1)溶解现象及溶解度</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)渗透剂的浓度</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)渗透检测与溶解度、浓度</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C5.2.6 表面活性与表面活性剂</td><td></td><td></td><td></td></tr><tr><td>(1)表面活性、表面活性剂的定义</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(2)表面活性剂的作用</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(3)乳化作用,乳化形式、乳化作用的机理C5.3 渗透检测的光学基础</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(1)光的本性,光的波动性和粒子性</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(2)发光及光致发光</td><td>▲</td><td>▲</td><td>—</td></tr><tr><td>(3)渗透检测用光</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)光度学相关概念的物理意义及其应用</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(5)对比度和可见度</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(6)缺陷显示及裂纹检出能力</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.4 渗透检测剂</td><td></td><td></td><td></td></tr><tr><td>C5.4.1 渗透剂</td><td></td><td></td><td></td></tr><tr><td>(1)渗透剂的分类、渗透剂的组成、各成分的作用和对渗透剂性能的影响、渗透剂的性能</td><td>●</td><td>●</td><td>▲</td></tr><tr><td>(2)着色渗透剂:水洗型、后乳化型、溶剂去除型着色渗透剂基本成分、特点及应用</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>(3)荧光渗透剂:水洗型、后乳化型、溶剂去除型着色渗透剂基本成分、特点及应用</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C5.4.2 去除剂</td><td></td><td></td><td></td></tr><tr><td>(1)乳化剂,乳化剂分类及组成、乳化剂的性能</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)溶剂去除剂,溶剂去除剂的分类、溶剂去除剂的性能</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C5.4.3 显像剂</td><td></td><td></td><td></td></tr><tr><td>显像剂的分类及组成、显像剂的性能</td><td>●</td><td>■</td><td>▲</td></tr><tr><td>C5.4.4 渗透检测剂系统</td><td></td><td></td><td></td></tr><tr><td>(1)渗透检测系统的定义及同组族定义及构成</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)渗透检测系统的选择原则</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.5 渗透检测设备、仪器和试块</td><td></td><td></td><td></td></tr><tr><td>C5.5.1 渗透检测设备</td><td></td><td></td><td></td></tr><tr><td>(1)便携式(压力喷罐)、固定式设备</td><td>▲</td><td>▲</td><td>▲</td></tr><tr><td>(2)检测光源,白光灯、黑光灯及照度、亮度测量仪器</td><td>▲</td><td>▲</td><td>▲</td></tr><tr><td>C5.5.2 渗透检测试块</td><td></td><td></td><td></td></tr><tr><td>(1)铝合金淬火试块、不锈钢镀铬辐射状裂纹试块、黄铜板镀铬裂纹试块特征及应用</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(2)缺陷试块,选择原则</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.6 渗透检测方法</td><td></td><td></td><td></td></tr><tr><td>C5.6.1 水洗型渗透检测法</td><td></td><td></td><td></td></tr><tr><td>检测程序、适用范围、方法的优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.6.2 后乳化型渗透检测法</td><td></td><td></td><td></td></tr><tr><td>检测程序、适用范围、方法的优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.6.3 溶剂去除型渗透检测法</td><td></td><td></td><td></td></tr><tr><td>检测程序、适用范围、方法的优缺点</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.6.4 特殊的渗透检测方法</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C5.6.5 渗透检测方法的选用</td><td></td><td></td><td></td></tr><tr><td>渗透检测方法选择因素、渗透检测方法应用</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.7 渗透检测工艺</td><td></td><td></td><td></td></tr><tr><td>C5.7.1 施加渗透剂</td><td></td><td></td><td></td></tr><tr><td>渗透液施加方法及要求、渗透时间和温度与检测灵敏度的关系</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.7.2 去除多余的渗透剂</td><td></td><td></td><td></td></tr><tr><td>各种渗透剂的去除要求、去除与检测灵敏度和检测可靠性的关系</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.7.3 干燥</td><td></td><td></td><td></td></tr><tr><td>干燥的目的和时机,常用的干燥方法,干燥温度和时间</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.7.4 显像</td><td></td><td></td><td></td></tr><tr><td>显像方法、显像时间、干式显像与湿式显像比较、显像剂的选择</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.7.5 观察和评定</td><td></td><td></td><td></td></tr><tr><td>观察时机、观察光源、观察注意事项</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.7.6 后清洗及复验</td><td></td><td></td><td></td></tr><tr><td>目的、方法和要求,复验</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.8 显示的解释和缺陷的评定</td><td></td><td></td><td></td></tr><tr><td>C5.8.1 显示的解释和分类</td><td></td><td></td><td></td></tr><tr><td>相关显示、非相关显示和虚假显示定义及显示特征、区别</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.8.2 缺陷的评定</td><td></td><td></td><td></td></tr><tr><td>(1)缺陷显示的分类,线性、圆形、密集形、纵横向缺陷显示;缺陷的分类,原材料缺陷、工艺缺陷和使用缺陷;常见缺陷及其显示特征</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)缺陷显示的评定,缺陷显示等级评定的一般原则,定位、定量、定性和定级,影响缺陷评定准确性的因素,显像时间和观察时机</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.9 质量控制与安全防护</td><td></td><td></td><td></td></tr><tr><td>C5.9.1 质量控制</td><td></td><td></td><td></td></tr><tr><td>(1)渗透检测剂、乳化剂、溶剂去除剂及显像剂的性能校验内容、方法和要求</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(2)渗透检测剂系统灵敏度鉴定内容、方法和要求</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(3)渗透检测剂的质量控制,新购进的渗透检测剂的质量控制项目,渗透检测剂在使用过程中的校验内容、方法和要求</td><td>●</td><td>■</td><td>—</td></tr><tr><td>(4)渗透检测设备、仪器和试块的质量控制,渗透检测工艺设备的质量控制(包括黑光灯、紫外线辐照计、荧光亮度计、白光亮度计、紫外线辐照计校正仪的控制等)</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>(5)渗透检测用标准试块的质量控制</td><td>●</td><td>●</td><td>—</td></tr><tr><td>(6)渗透检测工艺操作的质量控制</td><td>●</td><td>●</td><td>—</td></tr><tr><td>C5.9.2 渗透检测安全防护</td><td></td><td></td><td></td></tr><tr><td>(1)防火安全:防火注意事项、防火安全措施和灭火设置</td><td>▲</td><td>▲</td><td>●</td></tr><tr><td>(2)卫生安全:大气中有害物质的允许浓度、有毒化学药品对人体危害的途径、卫生安全防护措施、强紫外线辐射的卫生安全防护</td><td>■</td><td>▲</td><td>■</td></tr><tr><td>C5.10 渗透检测应用</td><td></td><td></td><td></td></tr><tr><td>C5.10.1 焊接件的渗透检测方法选择和质量控制</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.10.2 铸件、锻件的渗透检测特点、检测程序和质量控制</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.10.3 在用设备渗透检测方法选择、预处理和质量控制</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.11 渗透检测工艺编制</td><td></td><td></td><td></td></tr><tr><td>C5.11.1 渗透检测工艺种类、一般内容和检测工艺程序</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.11.2 渗透检测工艺编制与审核</td><td>●</td><td>■</td><td>—</td></tr><tr><td>C5.11.3 国内、外渗透检测标准对比分析</td><td>■</td><td>▲</td><td>—</td></tr><tr><td>C5.12 渗透检测标准</td><td>●</td><td>■</td><td>▲</td></tr></table>

## 相关规章和规范历次制(修)订情况

1.《锅炉压力容器无损检测人员资格鉴定考核规则》(劳动人事部劳人锅〔1987〕9号，1987年3月23日颁发，1994年10月1日废止)。

2.《锅炉压力容器无损检测人员资格考核规则》(劳动部劳部发〔1993〕441号，1993年12月30日颁发，1994年10月1日起施行，2003年8月8日废止)。

3.《特种设备无损检测人员考核与监督管理规则》(国家质检总局国质检锅〔2003〕248号，2003年8月8日发布，发布之日起施行)。

4.《特种设备无损检测人员考核规则》(TSG Z8001—2013，2013年1月16日质检总局颁布，2013年6月1日起施行)。