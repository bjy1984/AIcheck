力学性能与厚度有关,表列数据仅适用于相应材料标准的规定范围。

$^{aa}$ NS1101 按 982 ℃ 退火、NS1102 按 1120 ℃ 固溶、NS1104 按 1150 ℃ 固溶。

<table><tr><td rowspan="2">标准</td><td rowspan="2">牌号等级</td><td rowspan="2">尺寸范围mm/状态</td><td rowspan="2">母材类别</td><td rowspan="2">最低使用温度°C/图1的曲线号</td><td colspan="2">标准规定最小强度MPa</td><td rowspan="2">最高使用温度°C</td><td colspan="8">在下列温度(°C)下的许用应力MPa</td><td rowspan="2">脚注</td></tr><tr><td> $R_{\mathrm{m}}$ </td><td> $R_{\mathrm{eL}}$ (或 $R_{\mathrm{p0.2}}$ )</td><td>40</td><td>65</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td></tr></table>

$^{y}$ 本附录使用的 GB/T 12771 不锈钢焊管(EFW,无填充金属)应至少符合下列各项要求：

表 B.2 螺栓许用应力表

<table><tr><td rowspan="3">标准</td><td rowspan="3">牌号等级</td><td rowspan="3">尺寸范围mm</td><td rowspan="3">最低使用温度°C</td><td rowspan="2" colspan="2">标准规定最小强度MPa</td><td rowspan="3">最高使用温度°C</td><td rowspan="2" colspan="32">在下列温度(°C)下的许用应力MPa</td><td>脚注</td></tr><tr><td></td></tr><tr><td> $R_{m}$ </td><td> $R_{eL}$ (或 $R_{p0.2}$ )</td><td>40</td><td>65</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td><td></td><td></td></tr><tr><td colspan="39">螺栓紧固件</td><td></td></tr><tr><td colspan="39">标准紧固件</td><td></td></tr><tr><td>GB/T 3098.1</td><td>5.6</td><td>≤M39</td><td>-20</td><td>500</td><td>300</td><td>300</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>125</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>GB/T 3098.1</td><td>8.8</td><td>≤M39</td><td>-20</td><td>800</td><td>640</td><td>300</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>160</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>GB/T 3098.6</td><td>A2-50</td><td>≤M39</td><td>-255</td><td>500</td><td>210</td><td>800</td><td>125</td><td>120</td><td>113</td><td>108</td><td>103</td><td>99.0</td><td>95.6</td><td>92.7</td><td>90.1</td><td>87.9</td><td>85.8</td><td>84.0</td><td>82.3</td><td>80.6</td><td>79.1</td><td>77.6</td><td>76.2</td><td>74.8</td><td>73.4</td><td>72.1</td><td>70.7</td><td>69.4</td><td>63.8</td><td>51.6</td><td>41.6</td><td>32.9</td><td>26.5</td><td>21.3</td><td>17.2</td><td>14.1</td><td>11.2</td><td>—</td><td></td></tr><tr><td>GB/T 3098.6</td><td>A4-50</td><td>≤M39</td><td>-200</td><td>500</td><td>210</td><td>800</td><td>125</td><td>121</td><td>118</td><td>112</td><td>107</td><td>103</td><td>99.1</td><td>95.8</td><td>92.8</td><td>90.3</td><td>88.1</td><td>86.2</td><td>84.6</td><td>83.3</td><td>82.2</td><td>81.2</td><td>80.4</td><td>79.7</td><td>79.0</td><td>78.4</td><td>77.7</td><td>76.9</td><td>75.9</td><td>65.0</td><td>50.5</td><td>39.2</td><td>30.4</td><td>23.6</td><td>18.4</td><td>14.3</td><td>11.1</td><td>—</td><td></td></tr><tr><td>GB/T 3098.6</td><td>A2-70</td><td>≤M24</td><td>-255</td><td>700</td><td>450</td><td>400</td><td>130</td><td>123</td><td>114</td><td>114</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>GB/T 3098.6</td><td>A4-70</td><td>≤M24</td><td>-200</td><td>700</td><td>450</td><td>400</td><td>130</td><td>126</td><td>120</td><td>114</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>113</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td colspan="39">专用紧固件</td><td></td></tr><tr><td>HG/T 20634</td><td>35CrMo</td><td>≤M22</td><td>-50</td><td>835</td><td>735</td><td>525</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>165</td><td>162</td><td>146</td><td>121</td><td>94.0</td><td>68.0</td><td>44.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>35CrMo</td><td>&gt;M24~M88</td><td>-50</td><td>805</td><td>685</td><td>525</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>160</td><td>159</td><td>156</td><td>153</td><td>139</td><td>116</td><td>93.0</td><td>68.0</td><td>44.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>35CrMo</td><td>&gt;M88</td><td>-50</td><td>735</td><td>590</td><td>525</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>144</td><td>143</td><td>141</td><td>138</td><td>125</td><td>104</td><td>83.8</td><td>68.0</td><td>40.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>42CrMo</td><td>≤M65</td><td>-50</td><td>860</td><td>720</td><td>538</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>121</td><td>93.4</td><td>67.3</td><td>41.6</td><td colspan="2">23.5(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>42CrMo</td><td>&gt;M65~100</td><td>-40</td><td>790</td><td>660</td><td>538</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>158</td><td>116</td><td>92.3</td><td>67.3</td><td>41.6</td><td colspan="2">23.5(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>25Cr2MoV</td><td>≤M48</td><td>-20</td><td>835</td><td>735</td><td>575</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>167</td><td>166</td><td>146</td><td>121</td><td>90.1</td><td>59.3</td><td>33.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr></table>

表 B.2 螺栓许用应力表（续）

<table><tr><td rowspan="3">标准</td><td rowspan="3">牌号等级</td><td rowspan="3">尺寸范围mm</td><td rowspan="3">最低使用温度°C</td><td rowspan="2" colspan="2">标准规定最小强度MPa</td><td rowspan="3">最高使用温度°C</td><td rowspan="2" colspan="31">在下列温度(°C)下的许用应力MPa</td><td>脚注</td></tr><tr><td rowspan="2"></td></tr><tr><td> $R_m$ </td><td> $R_{eL}$ (或 $R_{p0.2}$ )</td><td>40</td><td>65</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td></tr><tr><td>HG/T 20634</td><td>25Cr2MoV</td><td>&gt;M48</td><td>-20</td><td>805</td><td>685</td><td>575</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>161</td><td>152</td><td>146</td><td>132</td><td>113</td><td>90.0</td><td>59.3</td><td>33.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>HG/T 20634</td><td>06Cr19Ni10(304)</td><td>—</td><td>-255</td><td>515</td><td>205</td><td>800</td><td>129</td><td>123</td><td>113</td><td>108</td><td>103</td><td>99.0</td><td>95.6</td><td>92.7</td><td>90.1</td><td>87.9</td><td>85.8</td><td>84.0</td><td>82.3</td><td>80.6</td><td>79.1</td><td>77.6</td><td>76.2</td><td>74.8</td><td>73.4</td><td>72.1</td><td>70.7</td><td>69.4</td><td>63.8</td><td>51.6</td><td>41.6</td><td>32.9</td><td>26.5</td><td>21.3</td><td>17.2</td><td>14.1</td><td>11.2</td><td>—</td></tr><tr><td>HG/T 20634</td><td>06Cr17Ni12Mo2(316)</td><td>—</td><td>-255</td><td>515</td><td>205</td><td>800</td><td>129</td><td>126</td><td>118</td><td>112</td><td>107</td><td>103</td><td>99.1</td><td>95.8</td><td>92.8</td><td>90.3</td><td>88.1</td><td>86.2</td><td>84.6</td><td>83.3</td><td>82.2</td><td>81.2</td><td>80.4</td><td>79.7</td><td>79.0</td><td>78.4</td><td>77.7</td><td>76.9</td><td>75.9</td><td>65.0</td><td>50.5</td><td>39.2</td><td>30.4</td><td>23.6</td><td>18.4</td><td>14.3</td><td>11.1</td><td>—</td></tr><tr><td>HG/T 20634</td><td>A193 B8-2</td><td>≤M20</td><td>-200</td><td>860</td><td>690</td><td>538</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>168</td><td colspan="2">162(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8-2</td><td>&gt;M20~M24</td><td>-200</td><td>795</td><td>550</td><td>538</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td colspan="2">138(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8-2</td><td>&gt;M24~M30</td><td>-200</td><td>725</td><td>450</td><td>538</td><td>129</td><td>123</td><td>113</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td colspan="2">112(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8-2</td><td>&gt;M30~M36</td><td>-200</td><td>690</td><td>345</td><td>538</td><td>129</td><td>123</td><td>113</td><td>108</td><td>103</td><td>99.0</td><td>95.6</td><td>92.7</td><td>90.1</td><td>87.9</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td colspan="2">86.2(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8M-2</td><td>≤M20</td><td>-200</td><td>760</td><td>665</td><td>538</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td>152</td><td colspan="2">152(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8M-2</td><td>&gt;M20~M24</td><td>-200</td><td>690</td><td>550</td><td>538</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td>138</td><td colspan="2">138(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td><td>a</td></tr><tr><td>HG/T 20634</td><td>A193 B8M-2</td><td>&gt;M24~M30</td><td>-200</td><td>655</td><td>450</td><td>538</td><td>129</td><td>126</td><td>118</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td>112</td><td colspan="2">112(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>a</td></tr></table>

$^{a}$ A193 B8-2 和 B8M-2 的螺纹根部硬度应不大于 RC35。硬度测点位于螺纹根径以内 3 mm 处，硬度检查频次同拉伸试验。
b A453 660 适用于高温，但应关注 $\sigma$ 相析出而导致常温塑性和韧性的降低，见 D.6.9。

表 B.2 螺栓许用应力表（续）

<table><tr><td rowspan="3">标准</td><td rowspan="3">牌号等级</td><td rowspan="3">尺寸范围mm</td><td rowspan="3">最低使用温度°C</td><td rowspan="2" colspan="2">标准规定最小强度MPa</td><td rowspan="3">最高使用温度°C</td><td rowspan="2" colspan="31">在下列温度(°C)下的许用应力MPa</td><td>脚注</td></tr><tr><td rowspan="2"></td></tr><tr><td> $R_m$ </td><td> $R_{eL}$ (或 $R_{p0.2}$ )</td><td>40</td><td>65</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td></tr><tr><td>HG/T 20634</td><td>A193 B8M-2</td><td>&gt;M30~M36</td><td>-200</td><td>620</td><td>345</td><td>538</td><td>129</td><td>126</td><td>118</td><td>112</td><td>107</td><td>103</td><td>99.1</td><td>95.8</td><td>92.8</td><td>90.3</td><td>88.1</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td>86.2</td><td colspan="2">86.2(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—a</td><td></td></tr><tr><td>HG/T 20634</td><td>A320 L7</td><td>≤M65</td><td>-100</td><td>860</td><td>725</td><td>371</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td>172</td><td colspan="2">172(371°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>HG/T 20634</td><td>A453 660</td><td>—</td><td>-200</td><td>895</td><td>585</td><td>538</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td>147</td><td colspan="2">147(538°C)</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—b</td><td></td></tr><tr><td colspan="38">表列螺栓许用应力仅用于非标法兰设计的螺栓强度要求,而螺栓安装的目标应力可达50%~70%螺栓材料的屈服强度,且需注意控制法兰转角、垫片的蠕变松弛和螺栓的应力松弛而导致螺栓安装应力的衰减注:“—”表示暂无适用数据。</td><td></td></tr></table>

表 B.3 管子与对焊管件的纵向焊接接头系数 $\Phi_{w}$

<table><tr><td>标准</td><td>型式</td><td>简述</td><td>纵向焊接接头系数 $\Phi_w$ </td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢</td></tr><tr><td>GB/T 3087</td><td rowspan="7">无缝</td><td rowspan="7">无缝管</td><td rowspan="7">1.00</td></tr><tr><td>GB/T 5310</td></tr><tr><td>GB/T 6479</td></tr><tr><td>GB/T 8163</td></tr><tr><td>GB/T 9711</td></tr><tr><td>GB/T 9948</td></tr><tr><td>YB/T 4173</td></tr><tr><td rowspan="2">GB/T 3091</td><td>电阻焊</td><td>电阻焊焊管(直缝)</td><td>0.85</td></tr><tr><td>电熔焊(埋弧焊)</td><td>埋弧焊焊管(直缝)</td><td>0.80</td></tr><tr><td>GB/T 9711</td><td>电阻焊</td><td>电阻焊焊管(直缝)</td><td>0.85</td></tr><tr><td>GB/T 13793</td><td>电阻焊</td><td>电阻焊焊管(直缝)</td><td>0.85</td></tr><tr><td>SY/T 5037</td><td>埋弧焊</td><td>双面埋弧焊焊管(直缝或螺旋缝)</td><td>0.85</td></tr><tr><td>GB/T 13401</td><td rowspan="2">无缝或电熔焊</td><td>无缝或焊接管件</td><td rowspan="2">1.00</td></tr><tr><td>GB/T 29168.2</td><td>双面电熔焊管件+100%射线检测</td></tr><tr><td>GB/T 9711</td><td>电熔焊(埋弧焊)</td><td>双面埋弧焊板制焊管(直缝)</td><td>0.95</td></tr><tr><td rowspan="2">GB/T 32970</td><td rowspan="2">电熔焊</td><td>双面电熔焊板制焊管</td><td>0.85</td></tr><tr><td>双面电熔焊板制焊管+100%射线检测</td><td>1.00</td></tr><tr><td colspan="4">低温碳钢及低温镍钢</td></tr><tr><td>GB/T 6479</td><td rowspan="2">无缝</td><td rowspan="2">无缝管</td><td rowspan="2">1.00</td></tr><tr><td>GB/T 18984</td></tr><tr><td>GB/T 13401</td><td>无缝或电熔焊</td><td>无缝管件;双面电熔焊管件+100%射线检测</td><td>1.00</td></tr><tr><td colspan="4">合金钢</td></tr><tr><td>GB/T 5310</td><td rowspan="4">无缝</td><td rowspan="4">无缝管</td><td rowspan="4">1.00</td></tr><tr><td>GB/T 6479</td></tr><tr><td>GB/T 9948</td></tr><tr><td>YB/T 4173</td></tr><tr><td>GB/T 13401</td><td>无缝或电熔焊</td><td>无缝管件;双面电熔焊管件+100%射线检测</td><td>1.00</td></tr><tr><td>GB/T 32970</td><td>电熔焊</td><td>双面电熔焊板制焊管+100%射线检测</td><td>1.00</td></tr><tr><td colspan="4">不锈钢</td></tr><tr><td>GB/T 5310</td><td rowspan="4">无缝</td><td rowspan="4">无缝管</td><td rowspan="4">1.00</td></tr><tr><td>GB/T 9948</td></tr><tr><td>GB/T 14976</td></tr><tr><td>GB/T 21833.2</td></tr><tr><td>GB/T 12771</td><td>电熔焊</td><td>电熔焊焊管(无填充金属)</td><td>0.85</td></tr><tr><td>HG/T 20537.3</td><td>电熔焊</td><td>电熔焊焊管(无填充金属)</td><td>0.85</td></tr><tr><td>GB/T 21832.3</td><td>电熔焊</td><td>电熔焊焊管(无填充金属)</td><td>0.85</td></tr><tr><td>GB/T 13401</td><td>无缝或电熔焊</td><td>无缝管件;双面电熔焊管件+100%射线检测</td><td>1.00</td></tr><tr><td>GB/T 32964</td><td>电熔焊</td><td>双面电熔焊板制焊管+100%射线检测</td><td>1.00</td></tr><tr><td rowspan="3">HG/T 20537.4</td><td rowspan="3">电熔焊</td><td>双面电熔焊板制焊管</td><td>0.85</td></tr><tr><td>双面电熔焊板制焊管+按标准局部射线检测</td><td>0.90</td></tr><tr><td>双面电熔焊板制焊管+100%射线检测</td><td>1.00</td></tr><tr><td colspan="4">镍及镍合金</td></tr><tr><td>GB/T 2882</td><td rowspan="3">无缝</td><td rowspan="3">无缝管</td><td rowspan="3">1.00</td></tr><tr><td>GB/T 30059</td></tr><tr><td>NB/T 47047</td></tr><tr><td colspan="4">钛及钛合金</td></tr><tr><td>GB/T 3624</td><td rowspan="2">无缝</td><td rowspan="2">无缝管</td><td rowspan="2">1.00</td></tr><tr><td>GB/T 26058</td></tr><tr><td>GB/T 26057</td><td>电熔焊</td><td>电熔焊焊管(无填充金属)</td><td>0.85</td></tr><tr><td>GB/T 27684</td><td>无缝或电熔焊</td><td>无缝管件;双面电熔焊管件+100%射线检测</td><td>1.00</td></tr><tr><td colspan="4">铝及铝合金</td></tr><tr><td>GB/T 4437.1</td><td rowspan="3">无缝</td><td rowspan="3">无缝管</td><td rowspan="3">1.00</td></tr><tr><td>GB/T 6893</td></tr><tr><td>GB/T 38512</td></tr></table>

表 B.4 铸件质量系数 $\Phi_{c}$

<table><tr><td>材料类别</td><td>标准</td><td>名称</td><td>铸件质量系数 $\Phi_c$ </td></tr><tr><td rowspan="3">铸铁</td><td>GB/T 9439</td><td>灰铸铁</td><td>1.00</td></tr><tr><td>GB/T 9440</td><td>黑芯可锻铸铁</td><td>1.00</td></tr><tr><td>GB/T 1348</td><td>球墨铸铁</td><td>1.00</td></tr><tr><td>碳钢(包括碳锰钢)</td><td>GB/T 12229</td><td>碳素钢铸件</td><td>0.80</td></tr><tr><td>低温碳钢及低温镍钢</td><td>JB/T 7248</td><td>低温钢铸件</td><td>0.80</td></tr><tr><td rowspan="2">合金钢</td><td>NB/T 11268</td><td rowspan="2">合金钢铸件</td><td rowspan="2">0.80</td></tr><tr><td>GB/T 16253</td></tr><tr><td>不锈钢</td><td>GB/T 12230</td><td>不锈钢铸件</td><td>0.80</td></tr><tr><td>钛及钛合金</td><td>GB/T 6614</td><td>钛及钛合金铸件</td><td>0.80</td></tr><tr><td colspan="4">表列非铸铁材料如按表16进行无损检测, $\Phi_c$ 可适当提高</td></tr></table>

## 附录 C

(资料性)

## 材料的物理性能

表 C.1 和表 C.2 中的物理性能参数按材料类型划分,设计者也可采用具体牌号材料的物理性能参数。其中,表 C.1 给出了金属热膨胀系数和金属总热膨胀量,表 C.2 给出了金属弹性模量。

表 C.1 金属热膨胀系数和金属总热膨胀量

<table><tr><td rowspan="2">材料名称</td><td rowspan="2">系数</td><td colspan="35">在下列温度(°C)下的材料热膨胀系数和总热膨胀量</td></tr><tr><td>-200</td><td>-100</td><td>-50</td><td>20</td><td>50</td><td>75</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td></tr><tr><td rowspan="2">组别1:碳钢、低合金钢</td><td>A</td><td>9.9</td><td>10.7</td><td>11.1</td><td>11.5</td><td>11.8</td><td>11.9</td><td>12.1</td><td>12.3</td><td>12.4</td><td>12.6</td><td>12.7</td><td>12.9</td><td>13.0</td><td>13.2</td><td>13.3</td><td>13.4</td><td>13.6</td><td>13.7</td><td>13.8</td><td>14.0</td><td>14.1</td><td>14.2</td><td>14.4</td><td>14.5</td><td>14.6</td><td>14.7</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.1</td><td>15.1</td><td>15.2</td><td>15.3</td><td>15.3</td><td>15.4</td></tr><tr><td>B</td><td>-2.2</td><td>-1.3</td><td>-0.8</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.3</td><td>1.6</td><td>2.0</td><td>2.3</td><td>2.6</td><td>3.0</td><td>3.4</td><td>3.7</td><td>4.1</td><td>4.5</td><td>4.9</td><td>5.3</td><td>5.7</td><td>6.1</td><td>6.5</td><td>6.9</td><td>7.3</td><td>7.7</td><td>8.2</td><td>8.6</td><td>9.0</td><td>9.4</td><td>9.9</td><td>10.3</td><td>10.7</td><td>11.1</td><td>11.6</td><td>12.0</td></tr><tr><td rowspan="2">组别2:低合金钢</td><td>A</td><td>10.8</td><td>11.7</td><td>12.0</td><td>12.6</td><td>12.8</td><td>13.0</td><td>13.1</td><td>13.2</td><td>13.4</td><td>13.5</td><td>13.6</td><td>13.7</td><td>13.8</td><td>13.9</td><td>14.0</td><td>14.1</td><td>14.2</td><td>14.3</td><td>14.4</td><td>14.5</td><td>14.6</td><td>14.6</td><td>14.7</td><td>14.8</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.0</td><td>15.1</td><td>15.1</td><td>15.2</td><td>15.2</td><td>15.3</td><td>15.3</td><td>15.3</td></tr><tr><td>B</td><td>-2.4</td><td>-1.4</td><td>-0.8</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.4</td><td>1.7</td><td>2.1</td><td>2.4</td><td>2.8</td><td>3.2</td><td>3.6</td><td>3.9</td><td>4.3</td><td>4.7</td><td>5.1</td><td>5.5</td><td>5.9</td><td>6.3</td><td>6.7</td><td>7.1</td><td>7.5</td><td>7.9</td><td>8.3</td><td>8.7</td><td>9.1</td><td>9.5</td><td>9.9</td><td>10.3</td><td>10.7</td><td>11.1</td><td>11.1</td><td>11.5</td></tr><tr><td rowspan="2">5Cr-1Mo</td><td>A</td><td>10.1</td><td>10.8</td><td>11.2</td><td>11.5</td><td>11.8</td><td>12.0</td><td>12.1</td><td>12.3</td><td>12.4</td><td>12.5</td><td>12.6</td><td>12.6</td><td>12.7</td><td>12.8</td><td>12.8</td><td>12.9</td><td>13.0</td><td>13.0</td><td>13.1</td><td>13.2</td><td>13.2</td><td>13.3</td><td>13.4</td><td>13.4</td><td>13.5</td><td>13.6</td><td>13.6</td><td>13.7</td><td>13.7</td><td>13.8</td><td>13.9</td><td>13.9</td><td>14.0</td><td>14.0</td><td>14.1</td></tr><tr><td>B</td><td>-2.2</td><td>-1.3</td><td>-0.8</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.3</td><td>1.6</td><td>1.9</td><td>2.3</td><td>2.6</td><td>2.9</td><td>3.3</td><td>3.6</td><td>3.9</td><td>4.3</td><td>4.6</td><td>5.0</td><td>5.3</td><td>5.7</td><td>6.1</td><td>6.4</td><td>6.8</td><td>7.2</td><td>7.5</td><td>7.9</td><td>8.3</td><td>8.7</td><td>9.0</td><td>9.4</td><td>9.8</td><td>10.2</td><td>10.6</td><td>11.0</td></tr><tr><td rowspan="2">9Cr-1Mo</td><td>A</td><td>9.0</td><td>9.8</td><td>10.1</td><td>10.5</td><td>10.6</td><td>10.7</td><td>10.9</td><td>11.0</td><td>11.1</td><td>11.2</td><td>11.3</td><td>11.4</td><td>11.5</td><td>11.6</td><td>11.7</td><td>11.8</td><td>11.9</td><td>11.9</td><td>12.0</td><td>12.1</td><td>12.2</td><td>12.3</td><td>12.3</td><td>12.4</td><td>12.5</td><td>12.6</td><td>12.7</td><td>12.7</td><td>12.8</td><td>12.9</td><td>13.0</td><td>13.1</td><td>13.3</td><td>13.4</td><td>13.6</td></tr><tr><td>B</td><td>-2.0</td><td>-1.2</td><td>-0.7</td><td>0.0</td><td>0.3</td><td>0.6</td><td>0.9</td><td>1.2</td><td>1.4</td><td>1.7</td><td>2.0</td><td>2.3</td><td>2.6</td><td>3.0</td><td>3.3</td><td>3.6</td><td>3.9</td><td>4.2</td><td>4.6</td><td>4.9</td><td>5.2</td><td>5.6</td><td>5.9</td><td>6.3</td><td>6.6</td><td>7.0</td><td>7.3</td><td>7.7</td><td>8.1</td><td>8.5</td><td>8.9</td><td>9.3</td><td>9.7</td><td>10.1</td><td>10.6</td></tr><tr><td rowspan="2">12Cr~13Cr</td><td>A</td><td>9.1</td><td>9.9</td><td>10.2</td><td>10.6</td><td>10.9</td><td>11.0</td><td>11.1</td><td>11.3</td><td>11.4</td><td>11.4</td><td>11.5</td><td>11.6</td><td>11.6</td><td>11.7</td><td>11.7</td><td>11.8</td><td>11.8</td><td>11.9</td><td>11.9</td><td>12.0</td><td>12.0</td><td>12.1</td><td>12.1</td><td>12.2</td><td>12.2</td><td>12.3</td><td>12.3</td><td>12.4</td><td>12.4</td><td>12.5</td><td>12.5</td><td>12.5</td><td>12.5</td><td>12.6</td><td>12.6</td></tr><tr><td>B</td><td>-2.0</td><td>-1.2</td><td>-0.7</td><td>0.0</td><td>0.3</td><td>0.6</td><td>0.9</td><td>1.2</td><td>1.5</td><td>1.8</td><td>2.1</td><td>2.4</td><td>2.7</td><td>3.0</td><td>3.3</td><td>3.6</td><td>3.9</td><td>4.2</td><td>4.5</td><td>4.9</td><td>5.2</td><td>5.5</td><td>5.8</td><td>6.2</td><td>6.5</td><td>6.8</td><td>7.2</td><td>7.5</td><td>7.8</td><td>8.2</td><td>8.5</td><td>8.8</td><td>9.2</td><td>9.5</td><td>9.8</td></tr><tr><td rowspan="2">15Cr~17Cr</td><td>A</td><td>8.1</td><td>8.8</td><td>9.1</td><td>9.6</td><td>9.7</td><td>9.9</td><td>10.0</td><td>10.1</td><td>10.2</td><td>10.3</td><td>10.4</td><td>10.5</td><td>10.6</td><td>10.7</td><td>10.8</td><td>10.8</td><td>10.9</td><td>11.0</td><td>11.0</td><td>11.1</td><td>11.2</td><td>11.2</td><td>11.3</td><td>11.3</td><td>11.4</td><td>11.4</td><td>11.5</td><td>11.5</td><td>11.5</td><td>11.6</td><td>11.6</td><td>11.7</td><td>11.7</td><td>11.8</td><td>11.9</td></tr><tr><td>B</td><td>-1.8</td><td>-1.1</td><td>-0.6</td><td>0.0</td><td>0.3</td><td>0.5</td><td>0.8</td><td>1.1</td><td>1.3</td><td>1.6</td><td>1.9</td><td>2.2</td><td>2.4</td><td>2.7</td><td>3.0</td><td>3.3</td><td>3.6</td><td>3.9</td><td>4.2</td><td>4.5</td><td>4.8</td><td>5.1</td><td>5.4</td><td>5.7</td><td>6.0</td><td>6.3</td><td>6.6</td><td>7.0</td><td>7.3</td><td>7.6</td><td>7.9</td><td>8.2</td><td>8.6</td><td>8.9</td><td>9.3</td></tr><tr><td rowspan="2">27Cr</td><td>A</td><td>7.7</td><td>8.5</td><td>8.7</td><td>9.0</td><td>9.2</td><td>9.2</td><td>9.3</td><td>9.4</td><td>9.4</td><td>9.5</td><td>9.5</td><td>9.6</td><td>9.6</td><td>9.7</td><td>9.7</td><td>9.8</td><td>9.9</td><td>9.9</td><td>10.0</td><td>10.0</td><td>10.1</td><td>10.2</td><td>10.2</td><td>10.3</td><td>10.4</td><td>10.4</td><td>10.5</td><td>10.5</td><td>10.6</td><td>10.6</td><td>10.7</td><td>10.7</td><td>10.8</td><td>10.8</td><td>10.9</td></tr><tr><td>B</td><td>-1.7</td><td>-1.0</td><td>-0.6</td><td>0.0</td><td>0.3</td><td>0.5</td><td>0.7</td><td>1.0</td><td>1.2</td><td>1.5</td><td>1.7</td><td>2.0</td><td>2.2</td><td>2.5</td><td>2.7</td><td>3.0</td><td>3.3</td><td>3.5</td><td>3.8</td><td>4.1</td><td>4.3</td><td>4.6</td><td>4.9</td><td>5.2</td><td>5.5</td><td>5.8</td><td>6.1</td><td>6.4</td><td>6.7</td><td>7.0</td><td>7.2</td><td>7.6</td><td>7.9</td><td>8.2</td><td>8.5</td></tr><tr><td rowspan="2">奥氏体不锈钢(304,316,321,347等)</td><td>A</td><td>13.5</td><td>14.3</td><td>14.7</td><td>15.3</td><td>15.6</td><td>15.9</td><td>16.2</td><td>16.4</td><td>16.6</td><td>16.8</td><td>17.0</td><td>17.2</td><td>17.4</td><td>17.5</td><td>17.7</td><td>17.8</td><td>17.9</td><td>18.0</td><td>18.1</td><td>18.2</td><td>18.3</td><td>18.4</td><td>18.4</td><td>18.5</td><td>18.6</td><td>18.7</td><td>18.8</td><td>18.9</td><td>19.0</td><td>19.1</td><td>19.2</td><td>19.3</td><td>19.4</td><td>19.4</td><td></td></tr><tr><td>B</td><td>-3.0</td><td>-1.7</td><td>-1.0</td><td>0.0</td><td>0.5</td><td>0.9</td><td>1.3</td><td>1.7</td><td>2.2</td><td>2.6</td><td>3.1</td><td>3.5</td><td>4.0</td><td>4.5</td><td>4.9</td><td>5.4</td><td>5.9</td><td>6.4</td><td>6.9</td><td>7.4</td><td>7.9</td><td>8.3</td><td>8.9</td><td>9.4</td><td>9.9</td><td>10.4</td><td>10.9</td><td>11.4</td><td>12.0</td><td>12.5</td><td>13.1</td><td>13.6</td><td>14.1</td><td>14.7</td><td>15.2</td></tr><tr><td rowspan="2">其他奥氏体不锈钢(309,310等)</td><td>A</td><td>12.8</td><td>13.6</td><td>14.1</td><td>14.7</td><td>15.0</td><td>15.2</td><td>15.4</td><td>15.6</td><td>15.7</td><td>15.9</td><td>16.0</td><td>16.1</td><td>16.3</td><td>16.4</td><td>16.5</td><td>16.6</td><td>16.6</td><td>16.7</td><td>16.8</td><td>16.9</td><td>17.0</td><td>17.1</td><td>17.2</td><td>17.2</td><td>17.3</td><td>17.4</td><td>17.5</td><td>17.6</td><td>17.7</td><td>17.8</td><td>17.9</td><td>18.0</td><td>18.1</td><td>18.2</td><td>18.3</td></tr><tr><td>B</td><td>-2.8</td><td>-1.6</td><td>-1.0</td><td>0.0</td><td>0.4</td><td>0.8</td><td>1.2</td><td>1.6</td><td>2.0</td><td>2.5</td><td>2.9</td><td>3.3</td><td>3.7</td><td>4.2</td><td>4.6</td><td>5.0</td><td>5.5</td><td>5.9</td><td>6.4</td><td>6.8</td><td>7.3</td><td>7.8</td><td>8.2</td><td>8.7</td><td>9.2</td><td>9.7</td><td>10.2</td><td>10.6</td><td>11.1</td><td>11.7</td><td>12.2</td><td>12.7</td><td>13.2</td><td>13.7</td><td>14.3</td></tr><tr><td rowspan="2">灰铸铁</td><td>A</td><td>—</td><td>—</td><td>—</td><td>9.8</td><td>10.1</td><td>10.2</td><td>10.4</td><td>10.5</td><td>10.7</td><td>10.8</td><td>11.0</td><td>11.1</td><td>11.2</td><td>11.4</td><td>11.5</td><td>11.7</td><td>11.8</td><td>12.0</td><td>12.1</td><td>12.3</td><td>12.4</td><td>12.6</td><td>12.7</td><td>12.9</td><td>13.0</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td></tr><tr><td>B</td><td>—</td><td>—</td><td>—</td><td>0.0</td><td>0.3</td><td>0.6</td><td>0.8</td><td>1.1</td><td>1.4</td><td>1.7</td><td>2.0</td><td>2.3</td><td>2.6</td><td>2.9</td><td>3.2</td><td>3.6</td><td>3.9</td><td>4.2</td><td>4.6</td><td>5.0</td><td>5.3</td><td>5.7</td><td>6.1</td><td>6.5</td><td>6.9</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td></tr><tr><td rowspan="2">球墨铸铁</td><td>A</td><td>—</td><td>8.8</td><td>9.5</td><td>10.3</td><td>10.5</td><td>10.7</td><td>10.9</td><td>11.1</td><td>11.3</td><td>11.6</td><td>11.8</td><td>12.0</td><td>12.2</td><td>12.4</td><td>12.5</td><td>12.6</td><td>12.8</td><td>12.9</td><td>13.0</td><td>13.1</td><td>13.2</td><td>13.2</td><td>13.3</td><td>13.4</td><td>13.5</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td></tr><tr><td>B</td><td>—</td><td>-1.1</td><td>-0.7</td><td>0.0</td><td>0.3</td><td>0.6</td><td>0.9</td><td>1.2</td><td>1.5</td><td>1.8</td><td>2.1</td><td>2.5</td><td>2.8</td><td>3.1</td><td>3.5</td><td>3.9</td><td>4.2</td><td>4.6</td><td>4.9</td><td>5.3</td><td>5.7</td><td>6.0</td><td>6.4</td><td>6.8</td><td>7.2</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">蒙乃尔合金(UNS N04400)67Ni-30Cu</td><td>A</td><td>10.4</td><td>12.2</td><td>13.0</td><td>13.8</td><td>14.1</td><td>14.4</td><td>14.6</td><td>14.8</td><td>15.0</td><td>15.1</td><td>15.3</td><td>15.4</td><td>15.5</td><td>15.6</td><td>15.7</td><td>15.8</td><td>15.9</td><td>16.0</td><td>16.0</td><td>16.1</td><td>16.1</td><td>16.2</td><td>16.2</td><td>16.3</td><td>16.3</td><td>16.4</td><td>16.4</td><td>16.5</td><td>16.5</td><td>16.6</td><td>16.6</td><td>16.7</td><td></td><td></td><td></td></tr><tr><td>B</td><td>-2.3</td><td>-1.5</td><td>-0.9</td><td>0.0</td><td>0.4</td><td>0.8</td><td>1.2</td><td>1.6</td><td>1.9</td><td>2.3</td><td>2.8</td><td>3.2</td><td>3.6</td><td>4.0</td><td>4.4</td><td>4.8</td><td>5.2</td><td>5.7</td><td>6.1</td><td>6.5</td><td>6.9</td><td>7.4</td><td>7.8</td><td>8.2</td><td>8.6</td><td>9.1</td><td>9.5</td><td>10.0</td><td>10.4</td><td>10.8</td><td>11.3</td><td>12.2</td><td></td><td></td><td></td></tr><tr><td rowspan="2">材料名称</td><td rowspan="2">系数</td><td colspan="34">在下列温度(°C)下的材料热膨胀系数和总热膨胀量</td><td></td></tr><tr><td>-200</td><td>-100</td><td>-50</td><td>20</td><td>50</td><td>75</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td></tr><tr><td rowspan="2">镍合金(UNS N02200,N02201)</td><td>A</td><td>9.6</td><td>10.8</td><td>11.4</td><td>11.9</td><td>12.4</td><td>12.7</td><td>13.0</td><td>13.3</td><td>13.5</td><td>13.7</td><td>13.9</td><td>14.0</td><td>14.2</td><td>14.3</td><td>14.4</td><td>14.5</td><td>14.6</td><td>14.7</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.1</td><td>15.2</td><td>15.3</td><td>15.4</td><td>15.5</td><td>15.6</td><td>15.6</td><td>15.7</td><td>15.8</td><td>15.9</td><td>15.9</td><td>16.0</td><td>16.1</td><td>16.2</td></tr><tr><td>B</td><td>-2.2</td><td>-1.4</td><td>-0.8</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.4</td><td>1.8</td><td>2.1</td><td>2.5</td><td>2.9</td><td>3.3</td><td>3.6</td><td>4.0</td><td>4.4</td><td>4.8</td><td>5.2</td><td>5.6</td><td>6.0</td><td>6.5</td><td>6.9</td><td>7.3</td><td>7.7</td><td>8.2</td><td>8.6</td><td>9.0</td><td>9.5</td><td>9.9</td><td>10.3</td><td>10.8</td><td>11.2</td><td>11.7</td><td>12.2</td><td>12.6</td></tr><tr><td rowspan="2">镍合金(UNS N06600)</td><td>A</td><td>9.9</td><td>10.8</td><td>11.5</td><td>12.3</td><td>12.5</td><td>12.7</td><td>12.8</td><td>13.0</td><td>13.2</td><td>13.3</td><td>13.5</td><td>13.6</td><td>13.7</td><td>13.8</td><td>14.0</td><td>14.1</td><td>14.2</td><td>14.3</td><td>14.4</td><td>14.5</td><td>14.6</td><td>14.7</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.1</td><td>15.2</td><td>15.3</td><td>15.4</td><td>15.6</td><td>15.7</td><td>15.8</td><td>15.9</td><td>16.1</td><td>16.2</td></tr><tr><td>B</td><td>-2.2</td><td>-1.3</td><td>-0.8</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.4</td><td>1.7</td><td>2.1</td><td>2.4</td><td>2.8</td><td>3.2</td><td>3.5</td><td>3.9</td><td>4.3</td><td>4.7</td><td>5.1</td><td>5.5</td><td>5.9</td><td>6.3</td><td>6.7</td><td>7.1</td><td>7.5</td><td>7.9</td><td>8.4</td><td>8.8</td><td>9.3</td><td>9.7</td><td>10.2</td><td>10.7</td><td>11.1</td><td>11.6</td><td>12.1</td><td>12.6</td></tr><tr><td rowspan="2">镍合金(UNS N06625)</td><td>A</td><td>—</td><td>—</td><td>—</td><td>12.0</td><td>12.4</td><td>12.6</td><td>12.8</td><td>12.9</td><td>13.0</td><td>13.1</td><td>13.2</td><td>13.2</td><td>13.3</td><td>13.3</td><td>13.3</td><td>13.4</td><td>13.5</td><td>13.5</td><td>13.6</td><td>13.7</td><td>13.8</td><td>14.0</td><td>14.1</td><td>14.2</td><td>14.3</td><td>14.5</td><td>14.6</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.1</td><td>15.3</td><td>15.4</td><td>15.6</td><td></td></tr><tr><td>B</td><td>—</td><td>—</td><td>—</td><td>0.0</td><td>0.4</td><td>0.7</td><td>1.0</td><td>1.4</td><td>1.7</td><td>2.0</td><td>2.4</td><td>2.7</td><td>3.0</td><td>3.4</td><td>3.7</td><td>4.1</td><td>4.4</td><td>4.8</td><td>5.1</td><td>5.5</td><td>5.9</td><td>6.3</td><td>6.7</td><td>7.1</td><td>7.5</td><td>8.0</td><td>8.4</td><td>8.8</td><td>9.3</td><td>9.8</td><td>10.2</td><td>10.7</td><td>11.2</td><td>11.6</td><td>12.1</td></tr><tr><td rowspan="2">镍合金(UNS N08800)</td><td>A</td><td>10.6</td><td>12.5</td><td>13.3</td><td>14.2</td><td>14.6</td><td>14.9</td><td>15.1</td><td>15.3</td><td>15.5</td><td>15.6</td><td>15.8</td><td>15.9</td><td>16.0</td><td>16.1</td><td>16.2</td><td>16.3</td><td>16.4</td><td>16.5</td><td>16.5</td><td>16.6</td><td>16.7</td><td>16.8</td><td>16.8</td><td>16.9</td><td>17.0</td><td>17.1</td><td>17.2</td><td>17.2</td><td>17.3</td><td>17.4</td><td>17.5</td><td>17.6</td><td>17.7</td><td>17.8</td><td>17.9</td></tr><tr><td>B</td><td>-2.3</td><td>-1.5</td><td>-0.9</td><td>0.0</td><td>0.4</td><td>0.8</td><td>1.2</td><td>1.6</td><td>2.0</td><td>2.4</td><td>2.8</td><td>3.3</td><td>3.7</td><td>4.1</td><td>4.5</td><td>5.0</td><td>5.4</td><td>5.8</td><td>6.3</td><td>6.7</td><td>7.2</td><td>7.6</td><td>8.1</td><td>8.5</td><td>9.0</td><td>9.5</td><td>9.9</td><td>10.4</td><td>10.9</td><td>11.4</td><td>11.9</td><td>12.4</td><td>12.9</td><td>13.4</td><td>14.0</td></tr><tr><td rowspan="2">镍合金(UNS N08825)</td><td>A</td><td>—</td><td>—</td><td>12.9</td><td>13.5</td><td>13.6</td><td>13.7</td><td>13.9</td><td>14.0</td><td>14.2</td><td>14.3</td><td>14.4</td><td>14.4</td><td>14.5</td><td>14.6</td><td>14.7</td><td>14.8</td><td>14.9</td><td>15.0</td><td>15.1</td><td>15.1</td><td>15.2</td><td>15.3</td><td>15.4</td><td>15.5</td><td>15.6</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>B</td><td>—</td><td>—</td><td>-0.9</td><td>0.0</td><td>0.4</td><td>0.8</td><td>1.1</td><td>1.5</td><td>1.8</td><td>2.2</td><td>2.6</td><td>3.0</td><td>3.3</td><td>3.7</td><td>4.1</td><td>4.5</td><td>4.9</td><td>5.3</td><td>5.7</td><td>6.1</td><td>6.5</td><td>7.0</td><td>7.4</td><td>7.8</td><td>8.3</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td rowspan="2">镍合金(UNS N010276)</td><td>A</td><td>—</td><td>—</td><td>—</td><td>10.8</td><td>11.0</td><td>11.2</td><td>11.4</td><td>11.6</td><td>11.7</td><td>11.9</td><td>12.0</td><td>12.2</td><td>12.4</td><td>12.5</td><td>12.6</td><td>12.8</td><td>12.9</td><td>13.0</td><td>13.1</td><td>13.2</td><td>13.3</td><td>13.4</td><td>13.5</td><td>13.6</td><td>13.7</td><td>13.8</td><td>13.9</td><td>14.0</td><td>14.1</td><td>14.2</td><td>14.3</td><td>14.3</td><td>14.4</td><td>14.5</td><td>14.6</td></tr><tr><td>B</td><td>—</td><td>—</td><td>—</td><td>0.0</td><td>0.3</td><td>0.6</td><td>0.9</td><td>1.2</td><td>1.5</td><td>1.8</td><td>2.2</td><td>2.5</td><td>2.8</td><td>3.2</td><td>3.5</td><td>3.9</td><td>4.3</td><td>4.6</td><td>5.0</td><td>5.4</td><td>5.7</td><td>6.1</td><td>6.5</td><td>6.9</td><td>7.3</td><td>7.7</td><td>8.1</td><td>8.5</td><td>8.9</td><td>9.3</td><td>9.7</td><td>10.1</td><td>10.5</td><td>10.9</td><td>11.4</td></tr><tr><td rowspan="2">青铜</td><td>A</td><td>15.1</td><td>15.8</td><td>16.4</td><td>17.2</td><td>17.6</td><td>17.9</td><td>18.0</td><td>18.2</td><td>18.2</td><td>18.3</td><td>18.4</td><td>18.5</td><td>18.5</td><td>18.6</td><td>18.7</td><td>18.8</td><td>18.9</td><td>19.0</td><td>19.0</td><td>19.1</td><td>19.2</td><td>19.3</td><td>19.4</td><td>19.4</td><td>19.5</td><td>19.6</td><td>19.7</td><td>19.7</td><td>19.8</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>B</td><td>-3.3</td><td>-1.9</td><td>-1.1</td><td>0.0</td><td>0.5</td><td>1.0</td><td>1.4</td><td>1.9</td><td>2.4</td><td>2.8</td><td>3.3</td><td>3.8</td><td>4.3</td><td>4.7</td><td>5.2</td><td>5.7</td><td>6.2</td><td>6.7</td><td>7.2</td><td>7.7</td><td>8.3</td><td>8.8</td><td>9.3</td><td>9.8</td><td>10.3</td><td>10.9</td><td>11.4</td><td>11.9</td><td>12.5</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td rowspan="2">黄铜</td><td>A</td><td>14.7</td><td>15.4</td><td>16.0</td><td>16.7</td><td>17.1</td><td>17.4</td><td>17.6</td><td>17.8</td><td>18.0</td><td>18.2</td><td>18.4</td><td>18.6</td><td>18.8</td><td>19.0</td><td>19.2</td><td>19.3</td><td>19.5</td><td>19.6</td><td>19.8</td><td>20.1</td><td>20.3</td><td>20.5</td><td>20.7</td><td>20.8</td><td>21.0</td><td>21.2</td><td>21.4</td><td>21.6</td><td>21.8</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td>B</td><td>-3.2</td><td>-1.9</td><td>-1.1</td><td>0.0</td><td>0.5</td><td>1.0</td><td>1.4</td><td>1.9</td><td>2.3</td><td>2.8</td><td>3.3</td><td>3.8</td><td>4.3</td><td>4.8</td><td>5.4</td><td>5.9</td><td>6.4</td><td>7.0</td><td>7.5</td><td>8.2</td><td>8.7</td><td>9.3</td><td>9.9</td><td>10.5</td><td>11.1</td><td>11.8</td><td>12.4</td><td>13.1</td><td>13.7</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td></tr><tr><td rowspan="2">白铜 70Cu-30Ni</td><td>A</td><td>11.9</td><td>13.4</td><td>14.0</td><td>14.5</td><td>14.9</td><td>15.2</td><td>15.3</td><td>15.5</td><td>15.7</td><td>15.8</td><td>16.0</td><td>16.1</td><td>16.3</td><td>16.4</td><td>16.5</td><td>16.5</td><td>16.6</td><td>16.6</td><td>16.7</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td></tr><tr><td>B</td><td>-2.6</td><td>-1.6</td><td>-1.0</td><td>0.0</td><td>0.4</td><td>0.8</td><td>1.2</td><td>1.6</td><td>2.0</td><td>2.5</td><td>2.9</td><td>3.3</td><td>3.7</td><td>4.2</td><td>4.6</td><td>5.0</td><td>5.5</td><td>5.9</td><td>6.3</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td></tr><tr><td rowspan="2">铝合金</td><td>A</td><td>18.0</td><td>19.7</td><td>20.8</td><td>21.7</td><td>22.6</td><td>23.1</td><td>23.4</td><td>23.7</td><td>23.9</td><td>24.4</td><td>24.4</td><td>24.7</td><td>25.0</td><td>25.2</td><td>25.5</td><td>25.6</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td></tr><tr><td>B</td><td>-4.0</td><td>-2.4</td><td>-1.5</td><td>0.0</td><td>0.7</td><td>1.3</td><td>1.9</td><td>2.5</td><td>3.1</td><td>3.7</td><td>4.4</td><td>5.1</td><td>5.7</td><td>6.4</td><td>7.1</td><td>7.8</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="2">钛合金(Grade1,2,3,7,12)</td><td>A</td><td>—</td><td>—</td><td>8.2</td><td>8.3</td><td>8.4</td><td>8.5</td><td>8.5</td><td>8.6</td><td>8.6</td><td>8.6</td><td>8.7</td><td>8.7</td><td>8.8</td><td>8.8</td><td>8.8</td><td>8.9</td><td>8.9</td><td>9.0</td><td>9.2</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>B</td><td>—</td><td>—</td><td>-0.6</td><td>0.0</td><td>0.3</td><td>0.5</td><td>0.7</td><td>0.9</td><td>1.1</td><td>1.3</td><td>1.6</td><td>1.8</td><td>2.0</td><td>2.2</td><td>2.5</td><td>2.7</td><td>2.9</td><td>3.2</td><td>3.4</td><td>3.7</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

表 C.1 金属热膨胀系数和金属总热膨胀量（续）

<table><tr><td rowspan="2">材料名称</td><td rowspan="2">系数</td><td colspan="34">在下列温度(°C)下的材料热膨胀系数和总热膨胀量</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>-200</td><td>-100</td><td>-50</td><td>20</td><td>50</td><td>75</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td colspan="101">注1:系数A:金属热膨胀系数, $10^{-6}$ /°C。注2:系数B:金属总热膨胀量,mm/m(从20°C至表列温度时所产生的总的单位长度热膨胀量)。注3:表列数据仅供参考,“一”表示暂无适用数据。注4:组别1材料包括下列公称成分的钢: $C-\frac{1}{2}Mo$   $3Cr-1Mo$  $\frac{1}{2}Cr-\frac{1}{5}Mo-V$   $\frac{1}{2}Ni-\frac{1}{2}Mo-V$  $\frac{1}{2}Cr-\frac{1}{4}Mo-Si$   $\frac{1}{2}Ni-\frac{1}{2}Cr-\frac{1}{4}Mo-V$  $\frac{1}{2}Cr-\frac{1}{2}Mo$   $\frac{3}{4}Ni-\frac{1}{2}Mo-Cr-V$  $\frac{1}{2}Cr-\frac{1}{2}Ni-\frac{1}{4}Mo$   $\frac{3}{4}Ni-\frac{1}{2}Mo-\frac{1}{3}Cr-V$  $\frac{3}{4}Cr-\frac{1}{2}Ni-Cu$   $\frac{3}{4}Ni-\frac{1}{2}Cu-Mo$  $\frac{3}{4}Cr-\frac{3}{4}Ni-Cu-Al$   $\frac{3}{4}Ni-\frac{1}{2}Cr-\frac{1}{2}Mo-V$  $1Cr-\frac{1}{5}Mo$   $\frac{3}{4}Ni-1Mo-\frac{3}{4}Cr$  $1Cr-\frac{1}{5}Mo-Si$   $1Ni-\frac{1}{2}Cr-\frac{1}{2}Mo$  $1Cr-\frac{1}{2}Mo$   $1\frac{1}{4}Ni-1Cr-\frac{1}{2}Mo$  $1Cr-\frac{1}{2}Mo-V$   $1\frac{3}{4}Ni-\frac{3}{4}Cr-\frac{1}{4}Mo$  $1\frac{1}{4}C-\frac{1}{2}Mo$   $2Ni-\frac{3}{4}Cr-\frac{1}{4}Mo$  $1\frac{1}{4}Cr-\frac{1}{2}Mo-Si$   $2Ni-\frac{3}{4}Cr-\frac{1}{3}Mo$  $1\frac{3}{4}Cr-\frac{1}{2}Mo-Cu$   $2\frac{1}{2}Ni$ </td></tr></table>

表 C.1 金属热膨胀系数和金属总热膨胀量（续）

<table><tr><td rowspan="2">材料名称</td><td rowspan="2">系数</td><td colspan="32">在下列温度(°C)下的材料热膨胀系数和总热膨胀量</td><td></td><td></td><td></td></tr><tr><td>-200</td><td>-100</td><td>-50</td><td>20</td><td>50</td><td>75</td><td>100</td><td>125</td><td>150</td><td>175</td><td>200</td><td>225</td><td>250</td><td>275</td><td>300</td><td>325</td><td>350</td><td>375</td><td>400</td><td>425</td><td>450</td><td>475</td><td>500</td><td>525</td><td>550</td><td>575</td><td>600</td><td>625</td><td>650</td><td>675</td><td>700</td><td>725</td><td>750</td><td>775</td><td>800</td></tr><tr><td colspan="36"> $2Cr-\frac{1}{2}Mo$   $3\frac{1}{2}Ni$  $2\frac{1}{4}Cr-1Mo$   $3\frac{1}{2}Ni-1\frac{3}{4}Cr-\frac{1}{2}Mo-V$ 注5:组别2材料包括下列公称成分的钢:Mn-VMn- $\frac{1}{4}Mo$ Mn- $\frac{1}{2}Mo$ Mn- $\frac{1}{2}Mo-\frac{1}{4}Ni$ Mn- $\frac{1}{2}Mo-\frac{1}{2}Ni$ Mn- $\frac{1}{2}Mo-\frac{3}{4}Ni$ </td><td></td></tr></table>

表 C.2 金属弹性模量

<table><tr><td rowspan="2">材料名称</td><td colspan="21">在下列温度(°C)下的弹性模量(E) $10^{3} \text{ N/mm}^{2}$ </td></tr><tr><td>-225</td><td>-200</td><td>-125</td><td>-75</td><td>25</td><td>100</td><td>150</td><td>200</td><td>250</td><td>300</td><td>350</td><td>400</td><td>450</td><td>500</td><td>550</td><td>600</td><td>650</td><td>700</td><td>750</td><td>800</td><td>850</td></tr><tr><td colspan="22">铁基金属</td></tr><tr><td>灰铸铁</td><td>—</td><td>—</td><td>—</td><td>—</td><td>92</td><td>91</td><td>89</td><td>87</td><td>85</td><td>82</td><td>78</td><td>73</td><td>67</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>碳钢, $C\leqslant 0.3\%$ </td><td>220</td><td>216</td><td>212</td><td>209</td><td>202</td><td>198</td><td>195</td><td>192</td><td>189</td><td>185</td><td>179</td><td>171</td><td>162</td><td>151</td><td>137</td><td>122</td><td>107</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>碳钢, $C>0.3\%$ </td><td>218</td><td>215</td><td>211</td><td>207</td><td>201</td><td>197</td><td>194</td><td>191</td><td>188</td><td>183</td><td>178</td><td>170</td><td>161</td><td>149</td><td>136</td><td>121</td><td>106</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>C-Mo钢</td><td>218</td><td>214</td><td>210</td><td>207</td><td>200</td><td>196</td><td>193</td><td>190</td><td>187</td><td>183</td><td>177</td><td>170</td><td>160</td><td>149</td><td>135</td><td>121</td><td>106</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Ni钢, $Ni 2\%\sim 9\%$ </td><td>207</td><td>204</td><td>200</td><td>197</td><td>191</td><td>187</td><td>184</td><td>181</td><td>178</td><td>174</td><td>171</td><td>167</td><td>163</td><td>158</td><td>153</td><td>147</td><td>141</td><td>133</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Cr-Mo钢, $1⁄2Cr\sim 2Cr$ </td><td>221</td><td>218</td><td>213</td><td>210</td><td>204</td><td>200</td><td>197</td><td>193</td><td>190</td><td>186</td><td>183</td><td>179</td><td>174</td><td>169</td><td>164</td><td>157</td><td>150</td><td>142</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Cr-Mo钢, $21⁄4Cr\sim 3Cr$ </td><td>228</td><td>225</td><td>220</td><td>217</td><td>210</td><td>206</td><td>202</td><td>199</td><td>196</td><td>192</td><td>188</td><td>184</td><td>180</td><td>175</td><td>169</td><td>162</td><td>155</td><td>146</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Cr-Mo钢, $5Cr\sim 9Cr$ </td><td>230</td><td>228</td><td>223</td><td>220</td><td>213</td><td>208</td><td>205</td><td>201</td><td>198</td><td>195</td><td>191</td><td>187</td><td>183</td><td>179</td><td>174</td><td>168</td><td>161</td><td>153</td><td>—</td><td>—</td><td>—</td></tr><tr><td>奥氏体钢(304、310、316、321、347、309等)</td><td>212</td><td>209</td><td>204</td><td>201</td><td>195</td><td>189</td><td>186</td><td>183</td><td>179</td><td>176</td><td>172</td><td>169</td><td>165</td><td>160</td><td>156</td><td>151</td><td>146</td><td>140</td><td>134</td><td>127</td><td>—</td></tr><tr><td>Cr钢, $12Cr、17Cr、27Cr$ </td><td>219</td><td>215</td><td>212</td><td>208</td><td>201</td><td>195</td><td>192</td><td>189</td><td>186</td><td>182</td><td>178</td><td>173</td><td>166</td><td>157</td><td>145</td><td>131</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td colspan="22">镍及镍合金</td></tr><tr><td>镍200,201,625</td><td>225</td><td>222</td><td>216</td><td>213</td><td>207</td><td>202</td><td>199</td><td>197</td><td>194</td><td>191</td><td>189</td><td>186</td><td>183</td><td>180</td><td>176</td><td>172</td><td>169</td><td>164</td><td>160</td><td>156</td><td>—</td></tr><tr><td>蒙耐尔400</td><td>195</td><td>192</td><td>188</td><td>185</td><td>179</td><td>175</td><td>173</td><td>171</td><td>168</td><td>166</td><td>163</td><td>161</td><td>158</td><td>155</td><td>152</td><td>149</td><td>146</td><td>142</td><td>139</td><td>135</td><td>—</td></tr><tr><td>Ni-Cr-Fe合金600</td><td>233</td><td>229</td><td>224</td><td>220</td><td>213</td><td>209</td><td>206</td><td>203</td><td>201</td><td>198</td><td>195</td><td>192</td><td>189</td><td>186</td><td>182</td><td>178</td><td>174</td><td>170</td><td>165</td><td>161</td><td>—</td></tr><tr><td>Ni-Fe-Cr合金800,800H</td><td>214</td><td>211</td><td>206</td><td>202</td><td>196</td><td>192</td><td>189</td><td>187</td><td>184</td><td>182</td><td>179</td><td>176</td><td>173</td><td>170</td><td>167</td><td>164</td><td>160</td><td>156</td><td>152</td><td>148</td><td>—</td></tr><tr><td>合金C276</td><td>224</td><td>220</td><td>215</td><td>212</td><td>205</td><td>201</td><td>198</td><td>195</td><td>193</td><td>190</td><td>187</td><td>184</td><td>181</td><td>178</td><td>175</td><td>171</td><td>167</td><td>163</td><td>159</td><td>155</td><td>—</td></tr><tr><td colspan="22">钛及钛合金</td></tr><tr><td>TA0~TA3、TA9</td><td>—</td><td>—</td><td>—</td><td>—</td><td>107</td><td>103</td><td>101</td><td>97</td><td>92</td><td>88</td><td>84</td><td>80</td><td>75</td><td>71</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr></table>

表 C.2 金属弹性模量（续）

<table><tr><td rowspan="2">材料名称</td><td colspan="21">在下列温度(°C)下的弹性模量(E) $10^{3} \text{ N/mm}^{2}$ </td></tr><tr><td>-225</td><td>-200</td><td>-125</td><td>-75</td><td>25</td><td>100</td><td>150</td><td>200</td><td>250</td><td>300</td><td>350</td><td>400</td><td>450</td><td>500</td><td>550</td><td>600</td><td>650</td><td>700</td><td>750</td><td>800</td><td>850</td></tr><tr><td colspan="22">铝及铝合金</td></tr><tr><td>1060,3003,3004,6061,6063</td><td>78</td><td>77</td><td>74</td><td>72</td><td>69</td><td>66</td><td>63</td><td>60</td><td>57</td><td>52</td><td>46</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>5052,5454</td><td>80</td><td>78</td><td>76</td><td>74</td><td>70</td><td>67</td><td>65</td><td>62</td><td>58</td><td>53</td><td>47</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>5083,5086</td><td>80</td><td>79</td><td>76</td><td>75</td><td>71</td><td>68</td><td>65</td><td>62</td><td>58</td><td>54</td><td>47</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td colspan="22">铜及铜合金</td></tr><tr><td>海军黄铜(C4640)</td><td>—</td><td>110</td><td>108</td><td>106</td><td>103</td><td>101</td><td>99</td><td>97</td><td>96</td><td>93</td><td>90</td><td>86</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>铜、红铜、铝青铜(C1020、C1100、C1220、C2300、C6140)</td><td>—</td><td>124</td><td>122</td><td>121</td><td>117</td><td>114</td><td>112</td><td>110</td><td>108</td><td>106</td><td>102</td><td>98</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>90Cu-10Ni(C7060)</td><td>—</td><td>131</td><td>129</td><td>127</td><td>124</td><td>121</td><td>119</td><td>117</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>80Cu-20Ni(C7100)</td><td>—</td><td>146</td><td>144</td><td>142</td><td>138</td><td>134</td><td>132</td><td>130</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>70Cu-30Ni(C7150)</td><td>—</td><td>161</td><td>158</td><td>156</td><td>152</td><td>148</td><td>145</td><td>143</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td colspan="22">注:“—”表示暂无适用数据。</td></tr></table>

# 附录 D

# (资料性)

# 基于风险的材料设计和选用

## D.1 材料设计和选用

## D.1.1 概述

D.1.1.1 本文件的材料设计和选用是基于应对由压力载荷而导致的材料强度失效以及延性金属材料在低于韧脆转变温度下的低应力脆断风险而提出的。

D.1.1.2 本文件未涉及的材料需根据介质相容性和使用环境进行选材。用户单位或设计单位可参考相关的腐蚀手册、图表和专著，尤其是类似装置的长期使用经验、现场试验和分析以及新工艺开发中的实验数据。

D.1.1.3 除 D.1.1.1 和 D.1.1.2 以外，本附录为常用工业管道材料选用时予以考虑的损伤风险以及对应材料的设计要求和工程措施。

## D.1.2 通用的设计和选用

管道材料选用时,考虑下列情况可能对材料产生影响:

a）管道暴露明火下的可能性以及管道材料的熔点、软化温度、高温下强度的降低和材料可燃性；

b) 发生火灾或者采取灭火措施时,热冲击导致管道材料脆性断裂或损坏的敏感性以及由此而产生的次生灾害;

c) 发生火灾时,管道绝热材料对管道的损伤(如稳定性、耐火性能以及在火中保持原有位置的能力);

d) 在垫片密封面、螺纹或承插接头等部位处，管道材料对缝隙腐蚀的敏感性；

e) 两种腐蚀电位差较大的金属材料相互紧密接触时，管道材料对电偶腐蚀的敏感性，包括电位差大小、阳极与阴极面积比大小、材料表面状态等；

注 1: 电偶腐蚀是两种腐蚀电位相差较大的金属材料紧密接触时,通过电解质构成腐蚀电流回路,致使腐蚀电位较低侧的金属成为阳极加速腐蚀,腐蚀电位较高侧的金属成为阴极而得到保护。

注 2：电位差越大、阳极与阴极面积比越小(即小阳极/大阴极)，则电偶腐蚀越严重。

注 3: 材料表面的状态, 包括非金属或金属涂层及阴极保护(牺牲阳极), 都会对减轻电偶腐蚀产生重大影响, 可采取以下防护措施减轻电偶腐蚀:

1）对腐蚀电位较高侧的金属施以非金属涂层；

2）碳钢的热镀锌(水温不高于 $66^{\circ}$ C);

3）埋地管道采用阴极保护(牺牲阳极)及绝缘法兰。

f) 螺纹润滑剂或密封剂与流体工况的兼容性；

g）衬垫、密封件和“O”形环与流体工况的兼容性；

h）其他材料(如胶黏剂、熔剂等)与流体工况的兼容性。

## D.2 低温脆性断裂

## D.2.1 碳钢、碳锰钢和合金钢的低温脆性断裂

D.2.1.1 低温脆性断裂是金属材料在低温或韧脆转变温度以下,发生突然破裂的灾难性失效现象。发生脆性断裂时,构件承受应力水平远低于材料屈服强度,因此构件断裂前无塑性变形,断口呈脆性。

D.2.1.2 基于金属材料的韧脆转变温度、使用经验及断裂力学分析,本文件列出了材料最低允许使用

温度(MDMT)及相应冲击试验要求。

D.2.1.3 除本文件的要求外,下列因素对低温脆性断裂也有影响,需采取相应措施:

a) 降低钢材韧脆转变温度的主要因素并非合金化( $-50^{\circ}C$ 以上)，而是纯净化、细晶化及热处理状态；

b) 厚度是影响脆性断裂的重要因素,一方面材料的韧性水平随厚度增加而降低;另一方面厚壁构件更易产生三向应力,从而诱发脆性断裂;

c) 应力水平(包括缺陷处的应力集中和残余应力、组织应力)对低温脆性断裂也有重大影响,50 MPa 以下的低载荷状态可大大缓解脆性断裂的风险;而焊接残余应力及焊接热影响区的晶粒粗化使焊缝成为受压部件脆性断裂的主要区域,因此,焊后热处理(PWHT)是降低脆性断裂风险的重要措施之一;

d) 压力设备高于转变温度的超载“温压力试验”具有缺陷尖端钝化、降低焊接残余应力、过载保护等多重效能，已成为控制脆性断裂风险的重要措施。

D.2.1.4 下列情况可对 5.5.1.3.4 所列的免除冲击试验的碳钢和碳锰钢管道系统造成脆性断裂的风险：

a) 冲击载荷(管道内部或外部的冲击载荷、流体的撞击等冲击荷载、泄压或排放产生的反力等);

b) 热加工而导致材料韧性损失；

c) 奥氏体和铁素体材料之间的异种钢焊接,由于线膨胀系数的差异而产生的附加应力;

d) 管道强行装配和冷紧导致的附加轴向应力,尤其是对低温低应力工况评定的影响;

e）考虑材料低温下的弹性模量变化对评估上述作用力的影响。

D.2.1.5 由于液态烃、液化气体之类高挥发性流体，由节流、闪蒸、骤冷可导致脆性断裂的风险增加。

D.2.1.6 低温(材料产生脆性)或高温(降低材料强度)可导致管道支架损坏的可能性提高。

## D.2.2 奥氏体不锈钢的低温脆性断裂

D.2.2.1 奥氏体不锈钢为面心立方晶格的奥氏体组织，其韧脆转变温度低于绝对零度 $(-273\;^{\circ}\mathrm{C})$ ，因此300系列奥氏体不锈钢固溶状态下不存在低温脆性断裂的风险。

D.2.2.2 下列情况,有可能导致 300 系列奥氏体不锈钢的脆性转变温度提高,需采取相应措施:

a) 剧烈冷变形,可导致奥氏体组织的马氏体转变而脆性转变温度的提高,重新进行固溶热处理可避免;

b) 奥氏体不锈钢的焊缝可能含有高达 $10\%$ 以上的 $\delta$ 铁素体，由此会影响 $-100^{\circ}\mathrm{C}$ 及以下的焊缝冲击韧性，为此可控制焊缝铁素体数 $\mathrm{FN} \leqslant 8 \sim 10$ ；在控制焊缝 FN 的同时，也要防止 FN 过低而引起的热裂纹风险，加强 PT 检测可及时发现热裂纹；

c) 避免使用 321、347，降低含碳量、提高镍含量有利于提高奥氏体不锈钢的低温稳定性；

d) 316L、316LN 是 $-253^{\circ}C$ 液氢管道的通用选材，AWS A5.4 E16-8-2 (FN $\leqslant 5$ ) 焊条为其配套焊条。

## D.3 高温

## D.3.1 蠕变断裂

D.3.1.1 蠕变断裂是金属材料在高温和低于屈服强度的应力的共同作用下，产生随时间延长而不断增加的变形，直至断裂。压力设备典型金属材料的蠕变阈值温度见表 D.1。

表 D.1 典型金属材料的蠕变阈值温度

<table><tr><td>材料</td><td>蠕变阈值温度</td></tr><tr><td>碳钢( $R_m \leqslant 414$  MPa)</td><td>343 °C (650 °F)</td></tr><tr><td>碳钢( $R_m > 414$  MPa)</td><td>371 °C (700 °F)</td></tr><tr><td>0.5Mo 钢</td><td>399 °C (750 °F)</td></tr><tr><td>铬钼合金钢 $1\frac{1}{4}Cr-1/2Mo$ (正火+回火)</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢 $1\frac{1}{4}Cr-1/2Mo$ (退火)</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢 $2\frac{1}{4}Cr-1Mo$ (正火+回火)</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢 $2\frac{1}{4}Cr-1Mo$ (退火)</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢 $2\frac{1}{4}Cr-1Mo$ (调质)</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢 $2\frac{1}{4}Cr-1Mo-V$ </td><td>441 °C (825 °F)</td></tr><tr><td>铬钼合金钢3Cr-1Mo-V</td><td>441 °C (825 °F)</td></tr><tr><td>铬钼合金钢5Cr-1/2Mo</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢7Cr-1/2Mo</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢9Cr-1Mo</td><td>427 °C (800 °F)</td></tr><tr><td>铬钼合金钢9Cr-1Mo-V</td><td>454 °C (850 °F)</td></tr><tr><td>马氏体不锈钢12Cr</td><td>482 °C (900 °F)</td></tr><tr><td>铬镍奥氏体不锈钢304,304H</td><td>510 °C (950 °F)</td></tr><tr><td>铬镍奥氏体不锈钢316,316H</td><td>538 °C (1 000 °F)</td></tr><tr><td>铬镍奥氏体不锈钢321,321H</td><td>538 °C (1 000 °F)</td></tr><tr><td>铬镍奥氏体不锈钢347,347H</td><td>538 °C (1 000 °F)</td></tr><tr><td>Ni-Cu-Fe 合金800,800H,800HT</td><td>565 °C (1 050 °F)</td></tr><tr><td>铬镍奥氏体不锈钢HK-40</td><td>649 °C (1 200 °F)</td></tr></table>

D.3.1.2 虽然本文件已列入材料高于蠕变阈值温度的使用温度上限和相应的寿命为 $1.0 \times 10^{5}$ h 的设计许用应力，但工程实践中还存在诸多涉及高温蠕变断裂的工况需作安全评估，常见评估项如下：

a）高温短时应力的安全评估；

b）两种以上高温短时应力的累积损伤安全评估；

c) 剩余寿命安全评估；

d) 大于 $10^{5}$ h 的材料设计许用应力。

上述 a) 可按受压部件在预期工况下的应力水平不高于按 Larson-Miller 法获得的材料在 $25 \, h \sim 2.5 \times 10^{5} \, h$ ，温度高于蠕变阈值温度至极限使用温度区间的平均或最小持久断裂应力（考虑相应安全系数）为准则进行评估。

上述 b) 可按受压部件在预期工况下应力水平根据 MPC- $\Omega$ 压法求得材料在 25 h～2.5×10 $^{5}$ h，温度高于蠕变阈值温度至极限使用温度区间的蠕变速率 RC(1/h)。蠕变速率 RC 与该工况的使用时间 t（小时）的乘积即为该工况（温度、时间、应力）对材料造成的蠕变损伤 DC。依据 MPC- $\Omega$ 法及 API 579-1/ASME FFS-1—2007 的第 10 部分，DC≤2.5。管道组成件服役期间如将经历多种蠕变温度区间内的工况（温度、时间、应力），均可按上述方法逐个求得每一工况下的 DC，其累积值按上述相同准则，不大于 2.5。

上述 c) 同样可按 a) 或 b) 所述方法进行剩余寿命安全评估。

上述 d) 可按 Larson-Miller 法或查阅 ASME Ⅲ-1 NH 卷取得。

## D.3.2 475 ℃ 脆化

D.3.2.1 Cr 含量≥12%的 400 系列不锈钢(高铬不锈钢)、锻造或铸造奥氏体不锈钢和双相不锈钢，它们中的铁素体相在 $316\;^{\circ}C \sim 540\;^{\circ}C$ 温度范围内停留较长时间后，会造成 Cr-P 金属中间相的析出，引起材料的硬度增加，塑性韧性的下降，从而导致脆化，而脆化的最大速率发生在 $475\;^{\circ}C$ ，故常称为 $475\;^{\circ}C$ 脆化。

D.3.2.2 Cr 含量越高以及不锈钢中的铁素体相得比例越高，475 ℃ 脆化越严重；但这种脆化主要导致材料在常温或较低温度下的塑性韧性的下降，而对其高温下的塑性韧性影响甚微，因此，在压力设备的开停车及压力试验期间容易产生风险。410 型马氏体不锈钢对 475 ℃ 脆化免疫，而 405 型铁素体不锈钢则不能幸免。

D.3.2.3 工作温度在上述温度范围,或者当敏感材料在热处理或冷却过程中,在此温度范围的停留时间过长,都可能发生 $475^{\circ}$ C 脆化。

## D.4 铸铁

铸铁、可锻铸铁、高硅铸铁以及断后伸长率小于15%的球墨铸铁均属脆性材料，对冲击载荷及热冲击较为敏感，可在有限条件下控制使用。必要时，需采取相应的防护措施。

## D.5 碳钢、碳锰钢和合金钢

## D.5.1 碱脆(Caustic Embrittlement)

D.5.1.1 输送中高浓度 NaOH 或其他强碱性流体的碳钢管道, 可能发生应力腐蚀开裂(晶间裂纹), 俗称“碱脆”, 碱脆随碱液浓度和温度的提高而加剧。

D.5.1.2 温度小于 $46^{\circ}C$ 时，一般不会发生碱脆；温度介于 $46^{\circ}C \sim 82^{\circ}C$ 之间时，随 NaOH 质量分数的升高而加剧；温度大于 $82^{\circ}C$ 时，仅当 NaOH 质量浓度 $\leqslant 5\%$ 才不发生碱脆，但易发生碱液蒸发浓缩，仍存在碱脆的风险。

D.5.1.3 碱脆经常出现在未作消除应力热处理的焊缝附近,因此,采取 $620^{\circ}$ C 以上的焊后热处理 (PWHT) 和防止过热的措施,可相应扩大碳钢在碱液中的适用范围。

## D.5.2 碱性应力腐蚀开裂(Alkaline Stress Corrosion Cracking, ASCC)

D.5.2.1 碳钢除上述在苛性钠中发生的碱脆以及下述在酸性介质中的氢致应力腐蚀开裂外,还存在如下列介质中发生的多种碱性应力腐蚀开裂的风险:

a）常温或低温无水液氨；

b) 醇胺液(常用于脱硫、脱 $CO_{2}$ );

c) 碱性碳酸盐-酸水溶液(气体净化系统)。

D.5.2.2 碳钢、低合金高强度钢的 ASCC，与残余应力、介质组成、浓度（包括反应物杂质副反应污染）和特定的温度区间有关。通常裂纹位于焊接热影响区，许多硬度达标的焊接接头还是会发生 ASCC。

与酸性介质中发生 SCC 归因于氢致开裂不同，对于 ASCC 的机理，目前，倾向归因于过高的焊接或冷变形残余拉应力存在，致使材料在特定的弱碱性（含有 $H_{2}S$ 、 $CO_{2}$ 、 $NH_{4}$ 、 $O_{2}$ 、氯化物、氰化物）腐蚀环境中形成的钝化膜滑移破裂，而使失去钝化膜保护的裸露金属产生局部快速腐蚀。

因此，PWHT 就成为控制 ASCC 的关键措施，而控制硬度反成多余。实践表明，对于常用的碳钢、碳锰钢，规范规定 $600^{\circ}$ C 的 PWHT 还不足以把焊接热影响区的残余应力峰值降低到免除 ASCC 的阈值，需采用更高温度 ( $620^{\circ}$ C～ $650^{\circ}$ C) 的 PWHT。对于如碳酸盐溶液管道系统的局部热处理，还需把 PWHT 温度提高至 $650^{\circ}$ C～ $660^{\circ}$ C。

D.5.2.3 防止 ASCC 的措施主要为限制使用高强钢(但一般不必控制硬度)、冷变形和采用较高的温度进行 PWHT。对于液氨引起的 ASCC，避免 $O_{2}$ (空气) 污染或加入 0.2% 以上水也可有效地控制 ASCC。

## D.5.3 石墨化

D.5.3.1 碳钢和 0.5Mo 钢长期在 427 ℃ 以上工作，能使稳定性不高的碳化物分解成铁素体和石墨，导致材料常温强度和高温长期强度下降，下降程度取决于石墨化进程。

D.5.3.2 温度和时间是影响石墨化的最重要因素,温度高于 $538^{\circ}C$ 时,热影响区发生严重石墨化仅需 5 年,而温度 $454^{\circ}C$ 时,产生轻微的石墨化则需要 30 年～40 年。

D.5.3.3 冷变形及焊接热影响区,相对更易发生石墨化。

## D.5.4 软化(球化)

D.5.4.1 铬钼合金钢，如 15CrMo、1-1/4Cr-0.5Mo、2-1/4Cr-1Mo、12Cr1MoV、5Cr-0.5Mo 钢长期在 440℃以上工作，珠光体中的碳化物不稳定，由原先的片状或弥散分布聚集成球状或块状碳化物，导致材料常温强度和高温长期强度下降。

D.5.4.2 温度、时间和合金含量是影响球化的重要因素。退火状态相对优于正火+回火状态 $(N+T)$ 或淬火状态(QT);硅镇静的粗晶粒钢相对优于铝镇静的细晶粒钢。

D.5.4.3 虽然球化致使材料高温强度下降,但伴随塑性的提高,即使在应力集中部位也允许有更大的应变。除高应力水平的应力集中区或伴随其他材料失效风险,仅由于球化而导致压力设备更换维修的案例甚为罕见。

## D.5.5 高温氢腐蚀

D.5.5.1 碳钢及铬含量不大于 3% 的铬钼合金钢使用温度在 $177^{\circ}$ C 以上，且氢分压不低于 0.345 MPa 时，有可能发生高温高压氢侵蚀，又称为“热氢侵蚀”，以区别于常见的氢脆、氢白点、氢致裂纹等在常温或相对较低温度下产生的氢损伤。

D.5.5.2 随着温度及氢分压的提高,氢原子与钢中的碳反应而生成甲烷,从而在材料表面形成脱碳层;而在钢材内部反应生成的甲烷集聚在晶界或钢材内部的缺陷处(如夹杂物)无法扩散逸出而形成很高压力，致使钢材内部脱碳、产生微裂纹直致破裂。晶界或夹杂处集聚的高压若接近材料表面则可产生氢鼓泡。

D.5.5.3 表面脱碳层较薄，对材料整体的强度和延性影响甚小，工程上可忽略；但内部脱碳及裂纹将导致临氢压力设备发生灾难性事故。较高温度和较低氢分压条件下，高温氢侵蚀的损伤模式为表面脱碳（见 Nelson 曲线的虚线）；而较低温度和较高氢分压条件下，高温氢侵蚀的损伤模式为内部脱碳及裂纹（见 Nelson 曲线的实线）；高温和高压条件下，则两种损伤模式都可能存在，尤以后者为甚。由此可见影响高温氢侵蚀最重要的因素是温度，其次是氢分压。

D.5.5.4 铬、钼合金元素的加入是工程中应对高温氢侵蚀的常见有效措施，并由此根据长期经验绘制成 Nelson 曲线，制定了 API RP 941，一般情况如下：

a) 铬含量大于或等于 $5\%$ 的铬钼合金钢以及不锈钢，从目前工程实例而言，对高温氢侵蚀是免疫的；奥氏体不锈钢常用于内壁堆焊、复合或衬里用于抵御高温硫或其他介质的腐蚀；

b) 奥氏体不锈钢的氢溶解度比铁素体钢大一个数量级, 氢的扩散速度要低两个数量级, 因此可降低复合材料中基层材料的氢分压。

D.5.5.5 根据 Nelson 曲线进行选材时需注意下列事项：

a) 留有 $20^{\circ}$ C 以上安全裕量，切不可超温，防止过热；采用内部隔热衬里降低基层材料温度时，隔热衬里的完整性破损可引起过热热点；

b) Nelson 曲线是基于材料良好的热处理状态，以保证其金相组织及碳化物稳定性，而焊接热影响区及 5% 以上冷变形将改变金相组织及碳化物形态和稳定性，导致其抗氢性能的下降；近年来，碳钢、0.5Mo 钢临氢设备多次在低于但接近 Nelson 曲线的安全区域发生高温氢侵蚀的重大事故，究其原因都归于焊后未作 PWHT 或产生了冷变形，因此，碳钢及铬钼合金钢临氢设备，如换热器管子与管板，焊后均作 PWHT，或将 Nelson 曲线留有 50 ℃ 以上安全裕量可减少事故的发生；碳钢焊后无需做 PWHT 的 Nelson 曲线见图 D.1。

![](images/bb89b894a52306e6e7c74c85da95ee2cd208f5a869d4b3541cb0b01e25393b80.jpg)  
图 D.1 焊后无需作 PWHT 的碳钢 Nelson 曲线 (API 941—2016)

## D.5.6 湿硫化氢/硫化物应力腐蚀开裂(Sulfate Stress Corrosion Cracking, SSC)

D.5.6.1 湿硫化氢/硫化物应力腐蚀开裂是金属在水(电解质)和硫化氢存在下由拉伸应力和腐蚀介质共同作用的开裂。硫化物应力开裂(SSC)有多种失效分类，如应力腐蚀开裂(SCC)、氢应力开裂(HSC)、氢诱导开裂(HIC)、应力导向氢诱导开裂(SOHIC)、阶梯开裂(SWC)等，从开裂的机理而言也可归因为氢致应力开裂，由于都是吸收硫化物在金属表面电化学腐蚀所产生的原子氢而造成的，为此本附录均将其归为SSC。碳钢或低合金钢焊接压力设备是发生SSC的重灾区。为此，仅就此列出选材时予以关注的要点。

D.5.6.2 影响 SSC 的环境因素有 $H_{2}S$ 浓度 ( $H_{2}S$ 分压 0.035 MPa 绝压以上)、pH（酸性）及温度，氰化物的存在对 SSC 有催化作用且易诱发 HIC。氯化物、 $CO_{2}$ 的存在也将引起多种腐蚀形态的共生与加剧。 $H_{2}S$ 浓度（分压）越高，pH 越低，SSC 越敏感，因此工程中常称为酸性介质的 SSC。温度提高导致氢的渗透速率提高，SSC 发生的概率反而下降，因此 SSC 通常发生在常温或工作温度 65 ℃ 以下。

D.5.6.3 防止碳钢或低合金钢焊接压力设备发生 SSC 的工程措施核心是控制硬度。控制硬度就是控制金相组织、组织应力及残余应力。因为这些部位正是 SSC 产生的根源。碳钢、低合金钢防止 SSC 发生的硬度上限为 RC22 或 $HV_{10}$ 237。由于焊接热影响区的高硬度区很窄， $HV_{10}$ 无法用于现场检测，HB 压痕较大，其读数代表的是平均硬度而非峰值，因此，焊缝检测时的硬度上限为 HB200。

控制硬度要落实到工程设备的每一细节，包括内壁外壁、宏观微观；如不准许冷变形、锤击、钢印、坡口外焊接打弧和飞溅。低强度钢优于高强钢；原材料进行正火、正火加回火、退火、调质等热处理及PWHT都有益于防止SSC的发生。

D.5.6.4 产生HIC的材料因素是板材单向轧制过程中形成的片状MnS夹杂，因此控制板材及板焊管母材的S含量不大于 $0.002\%$ 或加Ca促使MnS夹杂球化是抗HIC板材生产的附加要求。但无缝钢管、锻件无需要求该低S含量要求，焊缝则更没必要，因为MnS夹杂在此类材料中不可能呈片状分布。

## D.5.7 层状撕裂

D.5.7.1 碳钢或低合金钢厚板中的片状 MnS 夹杂也易导致焊接部位的层状撕裂发生。当夹杂邻近 T 型焊接接头的板材表面时，在焊接热应力和/或 Z 向（厚度方向）载荷的作用下会发生撕裂，如安放式接管与主管、凸形封头与裙座、管板、平封头与壳体、管子的焊接；或当夹杂邻近焊接热影响区，由焊接过程的充氢扩散和焊接热应力的共同作用下可发生类似硫化氢 SCC 中的氢致阶梯状开裂（HOHIC）。

D.5.7.2 控制层状撕裂的对策如下：

a）待焊部位 UT 检测，排除可能的夹杂；

b) 改变 T 型角接为 L 型角接或对接, 如安放式接管改为插入式接管;

c) 降低钢材含硫量，片状 MnS 夹杂将导致钢板 Z 向（厚度方向）拉伸性能，尤其是断面收缩率大幅下降；Z 向断面收缩率与含硫量的关系大致为 Z15（S 含量 $\leqslant 0.010\%$ ）、Z25（S 含量 $\leqslant 0.007\%$ ）、Z35（S 含量 $\leqslant 0.005\%$ ）；因此，根据具体工况，选用相应 Z 向（厚度方向）性能厚板就成为海上平台之类厚板焊接钢结构的惯例。

## D.5.8 高温硫化物腐蚀

D.5.8.1 碳钢、合金钢和不锈钢在超过 $260^{\circ}$ C 环境下与硫化物发生反应造成腐蚀，氢的存在会加速腐蚀。硫化物腐蚀主要是由 $H_{2}S$ 和其他活性硫化物（即在高温下容易分解生成 $H_{2}S$ 的硫化物，而非总硫）引起的。因此， $H_{2}S$ 和活性硫化物浓度和温度越高，尤其在 $260^{\circ}C \sim 425^{\circ}C$ ，随着温度升高，腐蚀速率呈指数式升高，而在 $425^{\circ}C$ 达到峰值。

D.5.8.2 碳钢、合金钢、不锈钢和镍基合金的耐蚀性取决于生成保护性硫化物膜的能力。对碳钢而言，Si含量≥0.1%将比Si含量≤0.1%者大大增加耐硫化的能力。对合金钢而言，Cr含量可以明显增加耐硫化的能力，但 Cr 含量低于 7%～9%，耐蚀性能提高不多。当氢与高温硫化物腐蚀共存时，Cr 含量低于 12% 对耐蚀性能提高不明显。因此，当采用不锈钢和镍基合金时，其耐蚀性同样取决于 Cr 含量。

D.5.8.3 工程设计时通常按 McConomy 曲线或 Couper-Gorman 曲线进行初步选材。

## D.5.9 铬钼合金钢的回火脆性

D.5.9.1 合金钢在 $343^{\circ}C \sim 577^{\circ}C$ 温度停留将导致材料韧性不同程度地下降，由于该温度范围与钢材的回火温度相近，故称为回火脆性。由于铬钼合金钢的使用温度范围又与其高度重合，因此对其格外关注。产生回火脆性的根源在于钢中磷(P)、砷(As)、锑(Sb)、锡(Sn)等有害元素的晶间析出集聚，而硅、锰对此亦有辅助作用。此外大截面构件的热过程也对其回火脆性的敏感性带来显着的影响。

D.5.9.2 回火脆性导致的韧性下降主要对压力组件开停车阶段以及在转变温度下快速加载或承受冲击载荷构成威胁，尤其是厚壁( $\geqslant$ 50 mm)及结构不连续构件。因此提高材料的纯净度和原始韧性水平就成为规避回火脆性风险的核心工程措施。

D.5.9.3 铬钼合金钢中对回火脆性最为敏感的是 $440^{\circ}$ C 左右长期使用的 $2.25Cr \sim 3Cr-1Mo$ 钢且壁厚大于或者等于 38 mm 的厚壁临氢压力设备。为此工程中采用控制措施如下：

$$
\text {母材的} J = (\mathrm{Si} + \mathrm{Mn}) (\mathrm{P} + \mathrm{Sn}) \times 1 0 0 0 0 \leqslant 1 5 0 (\text {质量分数})
$$

$$
\text {   焊缝的   } X = (1 0 \mathrm{P} + 5 \mathrm{Sb} + 4 \mathrm{Sn} + \mathrm{As}) / 1 0 0 \leqslant 1 5 \times 1 0 ^ {- 6}
$$

通过控制材料经历 PWHT 和步冷处理后的转变温度增值来控制厚壁临氢压力设备的回火脆性风险。用户根据自身情况及使用经验，不必盲目套用上述要求。

D.5.9.4 $\mathrm{Cr}(5\% \sim 9\%)$ 的铬钼合金钢对回火脆性并不敏感。工程界曾担忧 $1\mathrm{Cr} \sim 1.25\mathrm{Cr}-0.5\mathrm{Mo}$ 钢的回火脆性敏感性，研究表明，随着用户对铬钼合金钢韧性要求的提高， $1\mathrm{Cr} \sim 1.25\mathrm{Cr}-0.5\mathrm{Mo}$ 钢的回火脆性敏感性低于 $2.25\mathrm{Cr} \sim 3\mathrm{Cr}-1\mathrm{Mo}$ 钢。

D.5.9.5 近年来铬钼合金钢的冶金技术已由粗晶钢转为铝脱氧的细晶钢，如钢中的P含量≤0.010%；S含量≤0.005%，在0℃～-20℃时，AKV 50J就足以控制1Cr～1.25Cr-0.5Mo厚壁压力设备的回火脆性风险。因此，1Cr～1.25Cr-0.5Mo厚壁(壁厚大于或等于25mm)压力设备通过下列工程措施以控制再热裂纹及回火脆性的风险：

a）母材及焊缝的 X 系数 $\leqslant 15 \times 10^{-6}$ 、C 含量 $\leqslant 0.15\%$ ;

b）采用低氢焊材(H8)、焊接区域PWHT后硬度 $\mathrm{HV}_{10}\leqslant 235$ 或 $\mathrm{HB}\leqslant 225$

c) 水压试验温度不低于 $15^{\circ}$ C。

D.5.9.6 材料的回火脆性可通过 $620^{\circ}$ C 的回火热处理来恢复韧性,但并不能对再次发生回火脆性免疫。

## D.5.10 氢脆和氢致开裂(Hydrogen Embrittlement, HE)

D.5.10.1 由于碳钢、低合金钢为体心立方晶格，氢在钢中的溶解度比面心立方晶格的奥氏体钢或镍合金要低得多，而且其在相变冷却过程中过饱和的氢大量析出，在晶格畸变、组织应力高或缺陷、空穴处的集聚致使碳钢、低合金钢成为氢脆和氢致开裂的敏感金属。

D.5.10.2 氢的来源有下列三大渠道。

a）材料冶炼、锻造、焊接过程中进入，而其后快速冷却到常温过程中来不及逸出，而导致脆裂或韧性大幅下降，如氢白点、焊接延迟裂纹(冷裂纹)。

b) 材料电化学腐蚀过程中阴极产生的氢原子渗入金属，而导致的氢致裂纹 HSC；除上述 $H_{2}S$ 导致的 SSC、HIC 外，高浓度的氢氟酸与碳钢、低合金钢腐蚀反应生成的原子氢渗入钢中也将产生与酸性 $H_{2}S$ 溶液类同的 SCC 和 HIC；此外，钢材的过酸洗和阴极保护中过电位也可能导致阴极充氢而引发氢脆。

c) 氢对金属材料的渗透率随氢分压的提高而加大，除上述高温高压氢侵蚀外，在常温或较低温度下，随着氢分压的提高也将导致高强钢或钢的淬硬组织处产生氢脆；如气体工业将常温氢分压大于或等于 $1.0\mathrm{MPa}$ 的压力设备列入考虑采取防范氢脆的范围；ASME B31.12是专门应对高压下常温与低温氢脆的标准规范。

## D.5.10.3 控制氢脆和氢致开裂的对策如下：

a）采用真空脱气或采用低氢焊材，降低钢中氢含量；由于氢在温度升高时，氢在钢中的渗透率大大提高，因此缓冷、脱氢处理也将大大缓解氢脆风险；

b) 控制材料强度、硬度、冷变形、PWHT、板材的含硫量(HIC)等从材料及应力(包括内应力、残余应力)侧控制氢脆风险。

## D.6 奥氏体不锈钢和镍基合金

## D.6.1 奥氏体不锈钢和镍基合金的冶金特征

奥氏体不锈钢的用量在压力设备用材中仅次于碳钢、碳锰钢，选择奥氏体不锈钢的理由大致有两个：首先是一钢多用，洁净美观、耐蚀、耐高温（800 ℃～1 000 ℃）、耐超低温（-253 ℃），此外，其具有良好机械强度、塑性、韧性和加工焊接性能。正确使用奥氏体不锈钢，规避其常见的潜在风险需了解下列各项基本冶金特征。

a) 300 系列奥氏体不锈钢的耐蚀性主要来自其铬含量及其表面只有 2 nm 厚的氧化铬钝化膜的完整性、自钝化和修复能力；而 Ni 的作用主要在于形成奥氏体组织及由此带来优良的塑性韧性和加工焊接性能；一切有损于钝化膜完整性的因素都将对其耐蚀性带来颠覆性的后果，因此，保证钝化膜完整性是应对不锈钢一切腐蚀问题的基础。

b) 不锈钢的不锈是相对碳钢而言，在氧化性介质中有良好的耐蚀性，而300系列奥氏体不锈钢对还原性介质、强氧化性介质、氧化还原性介质、卤式盐以及抗SCC的能力十分有限；而高性能奥氏体不锈钢、双相不锈钢以及Inconel、Incoloy、哈氏等镍基耐蚀合金的选用正好填补这方面的空白。

c) 奥氏体不锈钢的组织特征、常用的耐蚀评价方法和指标，如铬当量、镍当量、Schaeffler图、Delong图、FN数、PRE点蚀指数、ASTM A262晶间腐蚀试验B法、C法、E法、ASTM G48的A法等，都对分析和应对不锈钢和镍基耐蚀合金各种失效风险至关重要。

## D.6.2 晶间腐蚀(Intergranular Corrosion, IGC)

D.6.2.1 晶间腐蚀是奥氏体不锈钢和镍基耐蚀合金在特定有限的几种无机及有机酸中(通常在高于常温的温度下)发生的沿晶界进行的选择性局部腐蚀(属电化学腐蚀)。

D.6.2.2 发生晶间腐蚀的机理一般解释为与不良的热过程导致碳化铬在晶界连续析出而产生的敏化贫铬现象有关。此外， $\sigma$ 相、Chi相、焊接金属中的 $\delta$ 铁素体甚至“端晶”也有可能导致类似晶间腐蚀的选择性局部腐蚀。由于碳在高Ni含量镍基耐蚀合金中的溶解度比低Ni含量的奥氏体不锈钢更低，因此，高Ni含量镍基耐蚀合金由于敏化而产生晶间腐蚀的倾向更大。

## D.6.2.3 防止晶间腐蚀的对策如下。

a) 固溶(即将碳化物重新在高温下溶解到奥氏体晶内)后快冷,防止碳化物在敏化区再次析出。

b) 采用超低碳材料(300系列奥氏体不锈钢 C 含量≤0.030%；镍基耐蚀合金及双相不锈钢、高性能奥氏体不锈钢 C 含量≤0.020%，甚至 0.015%)；但超低碳奥氏体合金在敏化区长期停留碳化物仍可析出，见图 D.2。

c) 加入 Nb、Ti 等强烈碳化物元素,优先形成 Nb、Ti 的碳化物而减少碳化铬在晶界连续析出,或再施以稳定化处理进一步强化稳定化效果。

d) 晶间腐蚀试验是研究奥氏体合金及其制作工艺应对晶间腐蚀倾向的重要方法，但各种晶间腐蚀试验方法与不锈钢用户所面临的腐蚀环境缺乏对应性与可比性。因此，晶间腐蚀试验不可成为用户的选材依据。对于腐蚀环境下使用300系列奥氏体不锈钢而言，超低碳、双牌号或稳定化热处理已成惯例，绝大多数潜在的晶间腐蚀风险已被控制，加上常用的硫酸-硫酸铜法的敏感性不高，因此除极少数的工况外（如尿素、硝酸用途的休氏试验），晶间腐蚀试验在实际工程中很少用作300系列奥氏体不锈钢质量控制要求。

e) 而对镍基耐蚀合金及高 Ni 的高性能不锈钢，由于产生晶间腐蚀的倾向更大，同时面临更为严苛的腐蚀环境，因此晶间腐蚀试验经常作为质量控制的保证，但要注意试验方法的对应性。双相不锈钢要注意敏化处理的适用性。

![](images/eeedfc4dc292889bfaef3c799426be265bbf20f4671171adb83c7571acfba1f2.jpg)  
图D.2 304不锈钢的敏化C曲线

## D.6.3 点蚀和缝隙腐蚀(Pitting Corrosion and Crevice Corrosion)

D.6.3.1 点蚀是发生在金属表面的局部腐蚀，腐蚀局限于一个点或很小的区域，蚀坑优先沿重力方向向纵深发展直至穿孔，也有可能在蚀坑的前端诱发腐蚀速度更快的应力腐蚀裂纹。通常认为点蚀机理是金属表面钝化膜首先被局部击穿，形成一个电解槽。小孔内小面积的阳极（相对于未被击穿的大面积金属钝化的阴极）迅速腐蚀，而且通过自身或催化过程不断向纵深发展。蚀坑的进展包括金属的溶解以及坑底部溶解的金属离子的水解而维持高酸度这两个过程。点蚀是奥氏体不锈钢和镍基合金在中性或偏酸性的氯化物溶液中最常见的局部腐蚀现象。图 D.3 所示为使不同 Mo 含量奥氏体钢开始发生点蚀的氯离子浓度与 pH 的关系（65 ℃～80 ℃）。

缝隙腐蚀是点蚀发生在缝隙中的特殊形式。缝隙宽度一般在 $0.1 \, mm \sim 0.01 \, mm$ （腐蚀介质可进入并滞留）。由于缝隙内缺氧，造成氢离子和氯离子的浓缩、pH 下降、腐蚀速度加快等“自催化过程”，缝隙外构成阴极保护、缝隙内则成为牺牲阳极。

![](images/4fe055effa37e877070d1fe2a142aa4d59c2e5c25e471f12142051b928c1e721.jpg)  
图 D.3 使不同含钼量奥氏体钢开始发生点蚀的氯离子质量浓度与 pH 的关系(65 ℃ \~ 80 ℃)

D.6.3.2 点蚀和缝隙腐蚀的影响因素如下。

a）依靠钝化膜来抵御电化学腐蚀的材料，其钝化膜的完整性及钝化膜抵御卤素离子的能力就成为关键，因此，钝化膜的缺陷就是点蚀和缝隙腐蚀的高发区。

b) 点蚀和缝隙腐蚀大多与氯化物、溴化物和次氯酸盐有关，尤其是氧化性金属盐，如铜、铁、汞的卤化物，因为这些金属盐本身具有氧化性，即使在缺氧的条件下也具有很强的侵蚀性。Na、Ca、Mg、Al 的卤化物在有氧条件下也会发生点蚀和缝隙腐蚀。

c) 卤化物浓度增加(或蒸发、浓缩)、pH降低、温度升高或充氧等因素的变化,在一定范围内都可能对点蚀和缝隙腐蚀有促进作用。但任何因素都有一个度,物极必反,更何况多因素共同作用时的相互制约作用,因此,从介质及工况情况预测点蚀是否发生,在实际应用中尚有困难。

d) 统计表明,点蚀和缝隙腐蚀大多发生在 $60^{\circ}$ C 以下。这可能与下列因素有关:

1）温度升高，氧在介质中的溶解度下降，降低了 NaCl 的点蚀倾向；

2）温度升高导致腐蚀速率以及氯离子浓缩概率大大提高，由点蚀诱发氯化物应力腐蚀开裂（CLSCC)的概率也随之提高。

e) 点蚀通常与介质滞留、蒸发、浓缩有关；反之，提高流速、避免缝隙、结垢、沉积、气液两相交替和滞液区，也可大大降低点蚀风险。

D.6.3.3 通常用点蚀指数 PRE 来衡量奥氏体不锈钢、双相不锈钢的相对耐点蚀、缝隙腐蚀和 SCC 的能力：

$$
\mathrm{PRE} = \mathrm{Cr} + 3. 3 \mathrm{Mo} + 1. 6 5 \mathrm{W} + 1 6 \mathrm{N}
$$

常用奥氏体不锈钢、双相不锈钢的点蚀指数PRE见表D.2。经验表明，奥氏体不锈钢、双相不锈钢的点蚀指数PRE不低于32，可有效耐海水的点蚀。

表 D.2 常用奥氏体不锈钢、双相不锈钢和镍基耐蚀合金点蚀指数 PRE 典型值

<table><tr><td>300系列ASS</td><td>PRE</td><td>高性能 ASS</td><td>PRE</td><td>双相钢 DSS</td><td>PRE</td><td>Ni基合金</td><td>PRE</td></tr><tr><td>304、304L</td><td>18</td><td>Alloy 20</td><td>30</td><td>2304</td><td>23</td><td>625</td><td>51</td></tr><tr><td>304LN</td><td>19.6</td><td>904L</td><td>34</td><td>3RE60</td><td>27</td><td>C22</td><td>70</td></tr><tr><td>316316L</td><td>22.6</td><td>254SMO</td><td>43</td><td>31803(2205)</td><td>30.5</td><td>C276</td><td>75</td></tr><tr><td>316LN</td><td>24.2</td><td>AL-6XN</td><td>44</td><td>2205</td><td>34</td><td>Alloy 59</td><td>76</td></tr><tr><td>317L</td><td>27.9</td><td>654SMO</td><td>56</td><td>2507</td><td>43</td><td>Alloy 686</td><td>81</td></tr></table>

D.6.3.4 不锈钢和镍基合金的点蚀试验与点蚀临界温度按下列方法确定。

a）工程中采用浓度为 $6\%$ 的 $\mathrm{FeCl}_3$ 溶液来测试各种奥氏体不锈钢、双相不锈钢和镍基耐蚀合金的点蚀临界温度(CPT)和缝隙腐蚀临界温度(CCT)。

b) 常用的试验方法有 ASTM G48 的 A 法(CPT)、B 法(CCT)、C 法(CPT)、D 法(CCT)和 ASTM A923 的 C 法(DSS-CPT)。试验溶液大致相同，但试样处理、pH 调节、时间、判据等细节上有差异，对 CPT、CCT 有影响。图 D.4 所示为 ASTM G48 的 B 法缝隙腐蚀临界温度与点蚀指数 PRE 对应关系。

c) 浓度为 $6\%$ 的 $\mathrm{FeCl}_3$ 溶液的 $\mathrm{pH}$ 约1.3，具有很强点蚀倾向，所以由试验而确定的材料CCT和CPT并不代表材料在实际工况中的点蚀临界温度，但基本反映了各种奥氏体不锈钢、双相不锈钢和镍基耐蚀合金的相对耐点蚀和缝隙腐蚀能力和排序。

d) ASTM A923 的 C 法及 ASTM G48 的 A 法常用于双相不锈钢产品(包括母材及焊缝), 质量检验的判定如下:

采用 ASTM A923 的 C 法, 对于 2205 不锈钢, 母材的试验温度为 $25^{\circ}C$ 、焊缝的试验温度为 $22^{\circ}C$ , 无点蚀为合格; 对于 2507 不锈钢, 母材的试验温度为 $45^{\circ}C \sim 50^{\circ}C$ 、焊缝的试验温度为 $40^{\circ}C$ , 无点蚀为合格。

![](images/f4e2767bec074f0fc0fc23d7a72fbbf611570a767f6b7f3cea7bbef659dd2449.jpg)  
图 D.4 缝隙腐蚀临界温度与点蚀指数 PRE 对应关系(ASTM G48 的 B 法)

## D.6.4 氯化物应力腐蚀开裂(Chloride Stress Corrosion Cracking, CLSCC)

## D.6.4.1 氯化物应力腐蚀开裂机理和规律如下。

a) 氯化物应力腐蚀开裂是奥氏体不锈钢，尤其是常用的304、316不锈钢最常见的失效模式。发生氯化物应力腐蚀破裂的机理，在其诱发孕育期大都与上述点蚀基本相同，都经历了钝化膜被击穿，随后经“自催化过程”形成蚀坑，其后在应力与温度的作用下，在缺陷(蚀坑或裂纹)尖端“自催化过程”更为加剧、金属快速溶解，形成穿晶带树枝状分枝的裂纹，裂纹间隙的电子探针可见高浓度的氯化物腐蚀产物。奥氏体不锈钢发生CLSCC的应力阈值较低，且一般由冷加工应力或焊接残余应力引起，与载荷应力关系不大。氯化物应力腐蚀开裂概率与镍含量的关系见图D.5：

1）300 系列奥氏体不锈钢对氯化物应力腐蚀开裂最为敏感；304 不锈钢的 CLSCC 阈值温度为 20 ℃ 左右，316 不锈钢阈值温度为 50 ℃ 左右；

2）双相钢、铁素体不锈钢及镍含量30%以上的镍基合金对氯化物应力腐蚀开裂几乎是免疫的；

3）提高 Mo 含量可提高 CLSCC 阈值温度，含 6%Mo 的 AL-6XN 的 CLSCC 阈值温度可达

240 ℃左右。

b) 从腐蚀环境(介质)来看,氯离子浓度越高、pH越低,CLSCC发生的概率越高;但氯离子含量从几百万分之一直至几百分之一、pH从1到10的条件下都有发生CLSCC的事例。在破裂断口的腐蚀产物分析可见:氯离子可浓缩数百倍达数百分之一、同时pH≈0。可见除了自催化过程外,氯离子的沉积、蒸发、干湿交替是诱发点蚀及CLSCC的重要因素。导致发生CLSCC的氯离子质量分数往往取决于整个服役期间(包括水压、使用、维修等过程)氯离子的最高质量分数。

c) 60 ℃以上时, 温度越高, CLSCC 发生的概率越高; 发生 CLSCC 的温度往往取决于整个服役期间(包括水压、使用、维修等过程)的最高温度。以 60 ℃～80 ℃作为点蚀及 CLSCC 的分界点, 主要原因如下:

1）温度越高，SCC 的腐蚀速率加快且超过点蚀的腐蚀速率，因此失效模式就表现为 CLSCC；

2）温度越高，氯离子的浓缩概率越大；60 ℃以下 CLSCC 发生的概率较低，而点蚀的概率较高，但在临界条件也有常温发生 CLSCC 的案例。

![](images/69a8bcb759022bd179bd12fcf3a2a83096fbcf68b8bd0160532ca9f225c74c2d.jpg)  
图D.5 氯化物应力腐蚀破裂概率与镍含量的关系

D.6.4.2 氯化物应力腐蚀开裂的影响因素(以 304L 材质为例)如下。

a）氯离子质量分数、温度对 304L 的影响见表 D.3。

表 D.3 氯离子质量分数、温度对 304L 的 CLSCC 的影响

<table><tr><td rowspan="2">温度°C</td><td colspan="4">氯离子质量分数 $\times 10^{-6}$ (pH $\leqslant$ 10)</td><td rowspan="2">存在浓缩、沉积、蒸发</td></tr><tr><td>1~10</td><td>11~100</td><td>101~1 000</td><td>&gt;1 000</td></tr><tr><td>10~38</td><td>低风险</td><td>低风险</td><td>低风险</td><td>中等风险</td><td>高风险</td></tr><tr><td>&gt;38~66</td><td>低风险</td><td>中等风险</td><td>中等风险</td><td>高风险</td><td>高风险</td></tr><tr><td>&gt;66~93</td><td>中等风险</td><td>中等风险</td><td>高风险</td><td>高风险</td><td>高风险</td></tr><tr><td>&gt;93</td><td>中等风险</td><td>高风险</td><td>高风险</td><td>高风险</td><td>高风险</td></tr><tr><td colspan="6">注:表列氯离子浓度、pH和温度为整个服役期间(包括水压、使用、维修等过程)可能存在的最高值。</td></tr></table>

b) 下列情况将提高表 D.3 的 CLSCC 风险等级：

1）材料敏化；

2）表面质量差(钝化膜完整性、酸洗钝化、污染、氧化色、机械损伤等)；

3）铁离子污染；

4）材料纯净度差；

5）冷加工变形或易切削级不锈钢；

6）已存在点蚀或锈斑；

7）存在缝隙、未焊透之类结构缺陷；

8）频繁开停车或温度波动。

D.6.4.3 控制氯化物应力腐蚀开裂的对策如下：

a）规避 D.6.4.2 所述的不利因素，降低 CLSCC 风险等级；

b) 表面涂(喷)非金属涂层或热喷铝,采用包裹铝箔应对外壁绝热层下腐蚀(CUI);

c) 采用点蚀指数(PRE)更高的材料或图 D.5 所示对 CLSCC 免疫的材料；

d) 加注缓蚀剂或采用阴极保护；

e）在未彻底清除氯化物应力腐蚀开裂区域前，不能采取焊补措施。

## D.6.5 连多硫酸应力腐蚀开裂(Polythionic Acid Stress Cracking, PTASCC)

D.6.5.1 连多硫酸应力腐蚀开裂是一种通常发生在停工、开工和有水及湿气存在的操作过程中的应力腐蚀开裂。开裂是由于材料在含有硫化物的高温腐蚀环境中使用后，在停工、维修期间由于气体的冷凝以及空气、氧和湿气侵入，与金属的硫化腐蚀层形成连多硫酸，然后当设备再次运行后很快就引起的开裂。

D.6.5.2 300 系列的奥氏体不锈钢、INCONEL 600 和 INCOLOY 800 系列的镍铬铁合金都会发生连多硫酸应力腐蚀破裂。裂纹集中在焊缝区域，呈类似晶间腐蚀状的沿晶开裂（区别于上述 CLSCC 大多为穿晶树枝状开裂）。

由于设备工作温度与不锈钢的敏化温度重合，因此常规的超低碳或稳定化不锈钢不能防止在敏化温度长时间停留后的碳化铬析出和贫铬现象。此外，奥氏体不锈钢一般不作PWHT，而且现场管道要进行固溶处理十分困难，所以焊缝区域就成为PTASCC的高风险区。

D.6.5.3 防止连多硫酸应力腐蚀开裂的对策如下。

a）材料和制造：

1）采用稳定型不锈钢并在固溶热处理后进行稳定化处理，以减少在敏化温度长时间停留后的碳化铬析出；

2）采用改良型 347H；

3）PWHT，保温温度为稳定化温度，空冷。

b) 停车保护：

1）充氮保护(干燥、无氧或加 $5 \times 10^{-3}$ 氨);

2）碱洗(采用 $1\% \sim 5\%$ $Na_{2}CO_{3}$ 溶液);

3）充干燥空气(空气的露点温度低于金属内壁温度至少22℃)。

## D.6.6 焊接裂纹

D.6.6.1 焊接热裂纹具有如下特征：

a) 奥氏体不锈钢和镍基合金的焊接裂纹与碳钢、合金钢的焊接冷裂纹(延迟裂纹或 D.5.10 的氢致裂纹)不同,它是焊缝凝固结晶的后期,即固液共存温度下产生的裂纹,故称为焊接热裂纹,又称为凝固裂纹;

b) 焊接热裂纹的表现形式有两种:一种是位于焊缝中央纵向裂纹或收弧弧坑中的放射性裂纹;另一种是位于熔合线及临近的母材部位(包括多层焊时,上层焊道与底层焊道的熔合区)的晶间开裂,又称液化裂纹;

c) 奥氏体不锈钢和镍基合金，与焊接关系密切的、工程中常见的还有应力松弛裂纹(D.6.7)和液体金属侵蚀(D.6.8)导致的裂纹。

D.6.6.2 焊接热裂纹机理如下。

a) 单相的奥氏体熔池在结晶后期，奥氏体柱状晶、树枝状晶之间富集着低熔点的液态共晶物或化合物在冷却收缩变形时形成的拉应力作用下导致的晶间开裂。奥氏体钢发生凝固裂纹倾向的原因如下：

1）奥氏体钢导热系数小、线胀系数大、焊接变形和应力大；

2）Nb、Si、S、P 在首先凝固的 $\gamma$ 奥氏体相中溶解度小，而偏析在柱状晶、树枝状晶之间富集形成低熔点的液态共晶物或化合物。而 Mn、Mo、W、V、Ti 则有利于防止凝固裂纹。

b) 液化裂纹多为过高焊接热量导致熔合线区域中金属重新液化(尤其是低熔点夹杂较多部位的偏析)，后又快速冷却产生应力而造成的开裂。

D.6.6.3 控制焊接热裂纹的对策如下。

a) 当前工程上最有效的措施是: 在单相的奥氏体焊接材料中人为地提高铁素体形成元素含量, 即铬当量, 调整铬镍比, 使焊缝金属含有一定量的 $\delta$ 铁素体, 改变熔池的凝固过程, 以消除或降低焊接热裂纹风险; 通常 304、316、321 不锈钢的 FN 不低于 3; 而 347 不锈钢的 FN 不低于 5。特殊工况需要控制 FN 更低时, 可采用 16-8-2 型低铁素体焊材。

b) 焊接工艺的调整改善措施如下：

1）避免过高焊接输入热量，多层焊时让底层焊缝充分冷却后再焊下一道；

2）控制焊道熔深与宽度之比，避免形成既深又窄的熔池(易热裂)；

3）弧坑要填满、焊缝要饱满或凸起，不要形成凹形焊道；

4）采用碱性焊条，其抗裂性优于酸性焊条。

c) 降低母材和焊接材料中 S、P 等杂质含量, 提高纯净度。

## D.6.7 应力松弛裂纹(Stress Relaxation Cracking, SRC)

D.6.7.1 应力松弛裂纹又称为再热裂纹，是含有稳定化元素（如 Nb、Ti）的奥氏体不锈钢和镍基合金，焊后在高温（550 ℃～750 ℃）使用或焊后在该温度区间停留后（如热处理或热加工的升温过程），在焊缝残余应力峰值区域发生开裂的现象。应力松弛裂纹大多位于焊接热影响区的粗晶区，呈晶间开裂状，裂纹有少量也可能位于焊缝金属以及母材的冷变形区。

D.6.7.2 产生 SRC 的机理常归为下列三个因素共同作用的结果：

a) 稳定化元素(如 Nb、Ti)的碳化物在焊接热影响作用下,在晶界的大量析出导致该部位的蠕变塑性大大降低(可检 $HV_{10} \geqslant 200$ ; 蠕变塑性<2%, 甚至<0.1%);

b) 焊接的原因,尤其是在厚壁(12 mm\~25 mm 以上)、角接(如支管座)焊缝的应力集中区和缺陷区的过高残余应力;

c) 在高温(550 ℃～750 ℃)区间,残余应力松弛的过程中,由于该部位的蠕变造成塑性过低而导致开裂。

D.6.7.3 应力松弛裂纹的敏感程度如下：

a) 奥氏体不锈钢的开裂敏感度: 347H 最高、321H 中等、304H 较低、316H 免疫; 镍基合金的开裂敏感度: 617、601 高于 800HT、625;

b) 粗晶粒敏感度高于细晶粒；固溶后的稳定化热处理可降低应力松弛裂纹的敏感度。

D.6.7.4 控制应力松弛裂纹的对策如下：

a) 除非必要, 少用 $347\mathrm{H}$ , 改用 $316\mathrm{H}$ ; 617 焊材降级为 $\mathrm{NiCrFe-3}$ ; 亦有认为, 对 $347\mathrm{H}$ : 降低含碳量 $\leqslant 0.020\%$ ; 提高铌碳质量比 $\geqslant 15$ ; 氮含量 $0.05\% \sim 0.10\%$ 可改善 $347\mathrm{H}$ 的抗 SRC 能力, 免除 PWHT;

b) 晶粒度细于或等于 3.5 级；进行固溶 + 稳定化处理；

c) 降低焊接线能量( $\leqslant2.15\ kJ/mm$ )、窄焊道( $\leqslant15\ mm$ )、控制层间温度 $\leqslant135\ ^{\circ}C$ ;改善焊缝表面质量及应力集中(焊缝粗糙、咬边、未焊透、未熔合);控制支管座焊缝尺寸及成型;如采用焊补,采用16-8-2的316型焊材;

d) 焊后 PWHT 是消除焊接残余应力的有效措施, 免除了其后使用过程中发生 SRC 的隐患; 但 PWHT 的过程, 尤其是高于 $460^{\circ}$ C 的升温过程, 又是产生 SRC 的高风险区, 需快速通过该区域。PWHT 温度一般选择稳定化温度, PWHT 后空冷即可;

e) PWHT 后对焊接区域全面进行 PT 检测, 清除可能产生的 SRC 缺陷。

## D.6.8 液体金属侵蚀(Liquid Metal Embrittlement, LME)

D.6.8.1 液体金属侵蚀是金属材料与熔点较低的液体金属接触时引起的晶间脆裂现象。

D.6.8.2 常见的 LME 现象有下列两种。

a) 不锈钢的热加工或焊接热影响区表面，由于低熔点金属粉末的污染，其残留的粉末在热加工或焊接热量下熔化而对不锈钢的晶间侵入所致。典型的低熔点金属有锌、铜、铅、锡、汞，其来源于加工环境、机具、切割砂轮、回丝、钎焊料、表面擦痕或标记颜料、墨水等；少量的残留粉末，焊后PT检测热影响区就可检出微裂纹。破裂断口的光谱分析可见低熔点金属痕迹。表面浅层的LME，打磨清除即可。

b) 铜含量较高的不锈钢，如 316Cu、904L 的大截面锻件的锻造过程中，高温加热致使表面氧化后富集的铜在高温熔化后渗入晶界而产生裂纹，又称为“铜脆”。

## D.6.9 $\pmb{\sigma}$ 相脆化

D.6.9.1 $\sigma$ 相脆化是 $\mathrm{Cr}$ 含量超过 $17\%$ 的不锈钢，尤其如铬镍奥氏体不锈钢和双相不锈钢在 $540^{\circ}\mathrm{C} \sim 900^{\circ}\mathrm{C}$ 温度下停留或使用一段时间，形成一种硬而脆的铁-铬金属间化合物而引起的脆化。 $\sigma$ 相脆化（其数量及其形态）取决于不锈钢中 $\delta$ 铁素体相的比例及其铁素体形成元素 $\mathrm{Cr}$ 当量（即 $\mathrm{Cr}, \mathrm{Si}, \mathrm{Mo}, \mathrm{Al}, \mathrm{W}, \mathrm{V}, \mathrm{Ti}, \mathrm{Nb}$ ）的高低。反之，奥氏体形成元素 Ni 当量（即 C、Ni、N、Mn）可阻滞 $\sigma$ 相脆化。

D.6.9.2 $\sigma$ 相脆化将导致材料韧性的下降(冲击吸收能量及断口收缩率)。随着 $\sigma$ 相数量的增加将大大提高不锈钢的脆性转变温度， $1\% \sim 2\%$ 的 $\sigma$ 相不锈钢的脆性转变温度尚在 $-46^{\circ}\mathrm{C}$ 以下，而 $5\% \sim 8\%$ 的 $\sigma$ 相不锈钢的脆性转变温度在 $0^{\circ}\mathrm{C}$ 左右，对压力设备的开停车及压力试验就可能存在风险；如 $\sigma$ 相达到 $10\%$ 或以上，脆性转变温度将提高至数百摄氏度，而且显著降低蠕变塑性，降低了压力组件抗热冲击和温度-载荷波动的能力,管道组成件在高温下的脆性断裂风险大大增加。

D.6.9.3 奥氏体不锈钢过量的冷变形及其焊缝中的 $\delta$ 铁素体将促使 $\sigma$ 相脆化。重新进行 $1065^{\circ}\mathrm{C}$ 以上保温较长时间后快冷可溶解 $\sigma$ 相，从而消除 $\sigma$ 相脆化。因此，控制焊缝中的 $\delta$ 铁素体数 $FN \leqslant 8$ ，过量的冷变形后重新固溶处理就成为控制奥氏体不锈钢 $\sigma$ 相脆化的主要工程措施。

## D.7 铜合金的氨裂和脱锌(脱合金)

## D.7.1 铜合金的氨裂

黄铜与氨接触会发生严重的应力腐蚀开裂，俗称“氨裂”。铜合金的氨裂有下列特征。

a) 锌含量大于 $15\%$ 的海军黄铜和铝黄铜为氨裂敏感材料。降低锌含量可降低氨裂敏感性但不足以免疫，而铜-镍合金和镍-铜合金对氨裂是免疫的。

b) pH 大于 8.5 的液氨、氨水、含氨的溶液如胺液，在各种温度下都可能产生氨裂；即使在气相时，空气中氧的污染也将促进氨裂。避免敏感材料在上述环境接触是规避风险的主要途径。

c) 拉伸应力可加速氨裂，材料的残余应力足以导致氨裂。

## D.7.2 铜合金的脱锌(脱合金)

铜合金的脱锌有如下特征：

a) 表 D.4 所列的铜合金和环境组合易发生脱合金现象,所谓脱合金就是铜合金中某一合金元素在特定的介质中发生的选择性腐蚀现象,合金中某一合金元素(或组织)优先快速被腐蚀,而残留的合金呈多孔状而失效,其中以黄铜的脱锌最为多见,故又称为“脱锌”;

b) 铜合金增加某种合金元素可以提高耐脱合金的性能，锡可以提高铜合金的耐脱合金性能；加入非常少量的磷、锑、砷可以提高海军黄铜的耐蚀性能；铝青铜的脱铝可以通过热处理产生 $\alpha$ 和 $\beta$ 微观组织来防护。

表 D.4 发生脱合金的铜合金和环境组合

<table><tr><td>铜合金</td><td>环境</td><td>被脱除的合金元素</td></tr><tr><td>黄铜(&gt;15% Zn)</td><td>水,尤其是静止的凝结水</td><td>锌(脱锌)</td></tr><tr><td>铝青铜(通常 Al 质量分数大于 8%)</td><td>HF 酸,含氯化物的酸,海水</td><td>铝(脱铝)</td></tr><tr><td>硅青铜</td><td>高温蒸汽和酸性物质</td><td>硅(脱硅)</td></tr><tr><td>锡青铜</td><td>热盐或蒸汽</td><td>锡(脱锡)</td></tr><tr><td>铜镍合金(70-30)</td><td>高热通量和低流速的水</td><td>镍(脱镍)</td></tr><tr><td>Monel</td><td>HF 或其他酸</td><td>镍(脱镍)</td></tr></table>

## D.8 微生物腐蚀(Microbiologicaly Induced Corrosion, MIC)

## D.8.1 微生物腐蚀的机理

微生物腐蚀是由微生物代谢作用而导致在大多数金属材料(包括碳钢、不锈钢、镍基合金)表面产生的类似于点蚀的杯状腐蚀现象。各种未经消毒的水，如给水、冷却水、消防水、海水都含有大量的细菌、藻类和真菌，在滞留及流速缓慢的情况下，借助各种无机物(硫、氨、硫化氢等)、有机物(碳氢化合物和有机酸)，包括泄漏的介质、结垢或腐蚀产物的营养而大量繁殖代谢，在其附着的金属表面下产生严重的孔蚀。

## D.8.2 微生物腐蚀的防护措施

结合具体情况选择如下防护措施：

a）采用加氯、溴、臭氧、紫外线等消毒措施，杀灭微生物；

b) 清除滞留的积水、提高流速、消除滞流死角；

c) 采用表面涂层、包裹或阴极保护，如埋地管道及储罐底板的防腐；

d) 采用定期冲刷、化学清洗、消毒等方法清除表面附着的各种污垢、结疤等，也可减轻 MIC，延长使用寿命。

## D.9 绝热层下腐蚀(Corrosion Under Insulation, CUI)

## D.9.1 绝热层下腐蚀的机理

绝热层下腐蚀(CUI)是压力容器或管道在绝热层下，由于水或蒸汽的渗入、结露以及在外表某些局部区域集聚、蒸发及浓缩而造成的局部电化学腐蚀。碳钢、合金钢以及奥氏体不锈钢、双相不锈钢都会发生CUI，但两者的腐蚀机理及其形态不同。前者是相当于充气水(饱和氧)对钢的氧化腐蚀，生成氧化铁的锈蚀层，而后者大多与氯离子的浓缩而引起的点蚀和应力腐蚀开裂有关。

## D.9.2 影响因素

影响 CUI 的主要因素有两个:首先是水渗入绝热层及在管道外表面某些部位的集聚。对于不锈钢的点蚀和氯化物应力腐蚀开裂(CLSCC)还包含着氯离子的溶入。水的来源有多种:雨水、结露、蒸汽冷凝、跑冒滴漏、绝热层的吸潮都有可能成为腐蚀介质的来源;而特定部位如绝热层外壳的易渗水或破损处、设备外表面的积液处、热蒸汽排放或疏水点、冷却塔或局部酸雨区域都是 CUI 的敏感区。统计表明,温暖、湿润的东南沿海区域发生 CUI 的概率要大于寒冷、干燥的内陆区域。

## D.9.3 温度

影响绝热层下腐蚀的温度参数并非一定是正常工作温度或设计温度，还可能是实际影响腐蚀速率的金属温度及其温度波动或温差。因为，温度波动、温差或开停车将促使金属外表的冷凝、蒸发、干湿交替，从而提高腐蚀速率。常用金属材料的绝热层下腐蚀呈现如下规律：

a) 碳钢、合金钢发生 CUI 的温度范围为 $-12^{\circ}C \sim 175^{\circ}C$ ，为氧化性腐蚀，腐蚀速率随温度提高而加速；由于低温部位通常不需设置绝热层，而高温部位大多因渗入的水快速蒸发而干燥，丧失了电化学腐蚀环境，因此，碳钢、合金钢发生 CUI 的温度敏感区为 $75^{\circ}C \sim 110^{\circ}C$ ；

b) 奥氏体不锈钢、双相不锈钢发生 CUI 的温度范围为 $60^{\circ}C \sim 205^{\circ}C$ ，同样腐蚀速率随温度提高而加速，因为温度升高促使水的蒸发和氯离子浓缩，并使腐蚀形态由点蚀转变为腐蚀速率更快的 SCC 应力腐蚀开裂，高温部位也因渗入的水快速蒸发，从而丧失了电化学腐蚀环境，因此，奥氏体不锈钢发生 CUI 的温度敏感区为 $60^{\circ}C \sim 175^{\circ}C$ ；双相不锈钢相对 300 系列的奥氏体不锈钢有较高的 PRE 点蚀指数和双相抗 SCC 应力腐蚀开裂组织，所以，发生 CUI 的概率相对要低一些，但在严酷环境下也不能免疫。

## D.9.4 对策

解决 CUI 的对策如下：

a）消除上述 D.9.2 所列入水的来源及结构泄漏破损部位；

b) 选择更换吸潮率低、氯离子含量低或有抑制腐蚀功能的绝热层材料；

c) 采用表面涂料、热喷铝或采用铝箔包裹等保护措施。

## 附录 E

(资料性)

国内与国外近似材料标准及牌号对照表

本附录列举了国内常用的材料标准及牌号，与国外近似材料标准及牌号的对照表见表 E.1。

表 E.1 国内与国外近似材料标准及牌号对照表

<table><tr><td>国内标准</td><td>国内材料牌号</td><td>国外标准</td><td>国外材料牌号</td></tr><tr><td colspan="4">铸铁</td></tr><tr><td>GB/T 9439</td><td>HT200</td><td>ASTM A48</td><td>200</td></tr><tr><td>GB/T 9439</td><td>HT250</td><td>ASTM A48</td><td>250</td></tr><tr><td>GB/T 9439</td><td>HT300</td><td>ASTM A48</td><td>300</td></tr><tr><td>GB/T 9439</td><td>HT350</td><td>ASTM A48</td><td>350</td></tr><tr><td>GB/T 1348</td><td>QT400-18</td><td>ASTM A395</td><td>60-40-18</td></tr><tr><td>GB/T 1348</td><td>QT400-18L</td><td>ASTM A395</td><td>60-40-18</td></tr><tr><td>GB/T 9440</td><td>KTH300-06</td><td>ASTM A47</td><td>22010</td></tr><tr><td>GB/T 9440</td><td>KTH350-10</td><td>ASTM A47</td><td>22010</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢无缝管</td></tr><tr><td>GB/T 3087</td><td>10</td><td>ASTM A53</td><td>Type S,Grade  $A^a$ </td></tr><tr><td>GB/T 6479</td><td>10</td><td>ASTM A53</td><td>Type S,Grade  $A^a$ </td></tr><tr><td>GB/T 8163</td><td>10</td><td>ASTM A106</td><td>Type S,Grade A</td></tr><tr><td>GB/T 9948</td><td>10</td><td>ASTM A106</td><td>Type S,Grade A</td></tr><tr><td>GB/T 3087</td><td>20</td><td>ASTM A53</td><td>Type S,Grade  $B^a$ </td></tr><tr><td>GB/T 5310</td><td>20G</td><td>ASTM A106</td><td>Grade B</td></tr><tr><td>GB/T 6479</td><td>20</td><td>ASTM A106</td><td>Grade  $B^a$ </td></tr><tr><td>GB/T 8163</td><td>20</td><td>ASTM A53</td><td>Type S,Grade B</td></tr><tr><td>GB/T 9948</td><td>20</td><td>ASTM A106</td><td>Grade B</td></tr><tr><td>YB/T 4173</td><td>20G</td><td>ASTM A369</td><td>Grade FPB</td></tr><tr><td>GB/T 5310</td><td>20MnG</td><td>ASTM A106</td><td>Grade B</td></tr><tr><td>YB/T 4173</td><td>20MnG</td><td>ASTM A369</td><td>Grade FPB</td></tr><tr><td>GB/T 9711</td><td>L245/B(PSL1)</td><td>API 5L</td><td>Grade B(PSL1)-SMLS</td></tr><tr><td>GB/T 9711</td><td>L245/B(PSL2)</td><td>API 5L</td><td>Grade B(PSL2)-SMLS</td></tr><tr><td>GB/T 8163</td><td>Q345A</td><td>ASTM A106</td><td>Grade C</td></tr><tr><td>GB/T 5310</td><td>25MnG</td><td>ASTM A106</td><td>Grade C</td></tr><tr><td>YB/T 4173</td><td>25MnG</td><td>ASTM A369</td><td>FPC(A106 Grade C)</td></tr><tr><td>GB/T 6479</td><td>Q345B</td><td>ASTM A106</td><td>Grade  $C^b$ </td></tr><tr><td>GB/T 6479</td><td>Q345D</td><td>ASTM A106</td><td>Grade  $C^b$ </td></tr><tr><td>GB/T 9711</td><td>L290/X42~L555/X80(PSL2)</td><td>API 5L</td><td>X42~X80(PSL2)</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢焊管(ERW)</td></tr><tr><td>GB/T 3091</td><td>Q215A</td><td>ASTM A53</td><td>TypeE,Grade A</td></tr><tr><td>GB/T 3091</td><td>Q215B</td><td>ASTM A53</td><td>TypeE,Grade A</td></tr><tr><td>GB/T 9711</td><td>L210/A(PSL1)</td><td>API 5L</td><td>Grade A(PSL1)-ERW</td></tr><tr><td>GB/T 3091</td><td>Q235A</td><td>ASTM A53</td><td>TypeE,Grade Ba</td></tr><tr><td>GB/T 3091</td><td>Q235B</td><td>ASTM A53</td><td>TypeE,Grade Ba</td></tr><tr><td>GB/T 9711</td><td>L245/B(PSL1)</td><td>API 5L</td><td>Grade B(PSL1)-ERW</td></tr><tr><td>GB/T 9711</td><td>L290/X42~L450/X65(PSL2)</td><td>API 5L</td><td>X42~X65(PSL2)-ERW</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢板焊管(EFW/SAW)</td></tr><tr><td>GB/T 3091SY/T 5037</td><td>Q215A</td><td>ASTM A134</td><td>A283,Grade Ca</td></tr><tr><td>GB/T 3091SY/T 5037</td><td>Q215B</td><td>ASTM A134</td><td>A283,Grade Ca</td></tr><tr><td>GB/T 3091SY/T 5037</td><td>Q235A</td><td>ASTM A134</td><td>A283,Grade Da</td></tr><tr><td>GB/T 3091SY/T 5037</td><td>Q235B</td><td>ASTM A134</td><td>A283,Grade Da</td></tr><tr><td>GB/T 9711</td><td>L245/B(PSL1)</td><td>API 5L</td><td>Grade,B(PSL1)-EFW/SAW</td></tr><tr><td>GB/T 9711</td><td>L245/B(PSL2)</td><td>API 5L</td><td>Grade,B(PSL2)-EFW/SAW</td></tr><tr><td>GB/T 32970</td><td>Q245</td><td>ASTM A672</td><td>C60,Cl22a</td></tr><tr><td>GB/T 32970</td><td>Q345</td><td>ASTM A672</td><td>C70,Cl22b</td></tr><tr><td>GB/T 9711</td><td>L290/X42~L555/X80(PSL2)</td><td>API 5L</td><td>X42~X80(PSL2)-EFW/SAW</td></tr><tr><td>—</td><td>—</td><td>ASTM A671</td><td>CC60,Cl22</td></tr><tr><td>—</td><td>—</td><td>ASTM A671</td><td>CC70,Cl22</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢管件(包括对焊、锻制)</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>CF370</td><td>ASTM A234</td><td>(WPA)b</td></tr><tr><td>GB/T 13401</td><td>CF415</td><td>ASTM A234</td><td>WPB</td></tr><tr><td>GB/T 14383</td><td>CF415</td><td>ASTM A105</td><td>A105a</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>CF415K</td><td>ASTM A234ASTM A105</td><td>WPBA105a</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>CF485</td><td>ASTM A234ASTM A105</td><td>WPCA105</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>CF485K</td><td>ASTM A234ASTM A105</td><td>WPCA105</td></tr><tr><td>GB/T 29168.2</td><td>L290/X42~L450/X80</td><td>MSS SP75ISO 15590-2</td><td>WPHY42~WPHY80</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)、管线钢锻件</td></tr><tr><td>GB/T 12228</td><td>25</td><td>ASTM A181</td><td>70b</td></tr><tr><td>GB/T 12228</td><td>A105</td><td>ASTM A105</td><td>A105</td></tr><tr><td>GB/T 29168.3</td><td>F290(F42)~F555(F80)</td><td>ASTM A694ISO 15590-3</td><td>F42~F80</td></tr><tr><td colspan="4">碳钢(包括碳锰钢)铸件</td></tr><tr><td>GB/T 12229</td><td>WCA</td><td>ASTM A216</td><td>WCA</td></tr><tr><td>GB/T 12229</td><td>WCB</td><td>ASTM A216</td><td>WCB</td></tr><tr><td>GB/T 12229</td><td>WCC</td><td>ASTM A216</td><td>WCC</td></tr><tr><td colspan="4">低温碳钢及低温镍钢无缝管</td></tr><tr><td>GB/T 6479</td><td>Q345E</td><td>ASTM A333</td><td>Grade6b</td></tr><tr><td>GB/T 18984</td><td>10MnDG</td><td>ASTM A333</td><td>Grade6b</td></tr><tr><td>GB/T 18984</td><td>16MnDG</td><td>ASTM A333</td><td>Grade6b</td></tr><tr><td>GB/T 18984</td><td>06Ni3MoDG</td><td>ASTM A333</td><td>Grade3</td></tr><tr><td>GB/T 18984</td><td>06Ni9DG</td><td>ASTM A333</td><td>Grade8</td></tr><tr><td colspan="4">低温碳钢及低温镍钢管件(包括对焊、锻制)</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>LF415K1</td><td>ASTM A420ASTM A350</td><td>WPL6</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>LF415K2</td><td>ASTM A420ASTM A350</td><td>WPL6</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>LF485K2</td><td>ASTM A420ASTM A350</td><td>WPL6b</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>LF450K3</td><td>ASTM A420ASTM A350</td><td>WPL3</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>LF680K4</td><td>ASTM A420ASTM A350</td><td>WPL8</td></tr><tr><td colspan="4">低温碳钢及低温镍钢铸件</td></tr><tr><td>JB/T 7248</td><td>LCB</td><td>ASTM A352</td><td>LCB</td></tr><tr><td>JB/T 7248</td><td>LCC</td><td>ASTM A352</td><td>LCC</td></tr><tr><td>JB/T 7248</td><td>LC3</td><td>ASTM A352</td><td>LC3</td></tr><tr><td>JB/T 7248</td><td>LC9</td><td>ASTM A352</td><td>LC9</td></tr><tr><td colspan="4">合金钢无缝管</td></tr><tr><td>GB/T 5310</td><td>15CrMoG</td><td>ASTM A335</td><td> $P12^d$ </td></tr><tr><td>GB/T 6479</td><td>15CrMo</td><td>ASTM A335</td><td> $P12^d$ </td></tr><tr><td>GB/T 9948</td><td>15CrMo</td><td>ASTM A335</td><td> $P12^d$ </td></tr><tr><td>YB/T 4173</td><td>15CrMoG</td><td>ASTM A369</td><td> $FP12^d$ </td></tr><tr><td>GB/T 9948</td><td>12Cr1Mo</td><td>ASTM A335</td><td>P11</td></tr><tr><td>GB/T 5310</td><td>12Cr2MoG</td><td>ASTM A335</td><td> $P22^d$ </td></tr><tr><td>GB/T 6479</td><td>12Cr2Mo</td><td>ASTM A335</td><td> $P22^d$ </td></tr><tr><td>GB/T 9948</td><td>12Cr2Mo</td><td>ASTM A335</td><td> $P22^d$ </td></tr><tr><td>YB/T 4173</td><td>12Cr2MoG</td><td>ASTM A369</td><td> $FP22^d$ </td></tr><tr><td>GB/T 5310</td><td>12Cr1MoVG</td><td>—</td><td>—</td></tr><tr><td>GB/T 9948</td><td>12Cr1MoV</td><td>—</td><td>—</td></tr><tr><td>YB/T 4173</td><td>12Cr1MoVG</td><td>—</td><td>—</td></tr><tr><td>GB/T 6479</td><td>10MoWVNb</td><td>—</td><td>—</td></tr><tr><td>GB/T 9948</td><td>12Cr5Mo I</td><td>ASTM A335</td><td>P5</td></tr><tr><td>GB/T 9948</td><td>12Cr5MoNT</td><td>ASTM A335</td><td> $P5^d$ </td></tr><tr><td>GB/T 9948</td><td>12Cr9Mo I</td><td>ASTM A335</td><td>P9</td></tr><tr><td>GB/T 9948</td><td>12Cr9MoNT</td><td>ASTM A335</td><td> $P9^d$ </td></tr><tr><td>GB/T 5310</td><td>10Cr9Mo1VNbN</td><td>ASTM A335</td><td>P91</td></tr><tr><td>YB/T 4173</td><td>10Cr9Mo1VNbN</td><td>ASTM A369</td><td>FP91</td></tr><tr><td colspan="4">合金钢板焊管(EFW/SAW)</td></tr><tr><td>GB/T 32970</td><td>15CrMo</td><td>ASTM A691</td><td>1Cr, A387 Gr.12-2, Cl22</td></tr><tr><td>GB/T 32970</td><td>14Cr1Mo</td><td>ASTM A691</td><td>1-1/4Cr, A387 Gr.11-2, Cl22</td></tr><tr><td>GB/T 32970</td><td>12Cr1MoV</td><td>—</td><td>—</td></tr><tr><td>GB/T 32970</td><td>12Cr2Mo1</td><td>ASTM A691</td><td>2-1/4Cr, A387 Gr.22-2, Cl22</td></tr><tr><td>GB/T 32970</td><td>12Cr5Mo</td><td>ASTM A691</td><td>5Cr, A387 Gr.5-2, Cl22</td></tr><tr><td colspan="4">合金钢管件(包括对焊、锻制)</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF12</td><td>ASTM A234ASTM A350</td><td>WP12-1</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF12G</td><td>ASTM A234ASTM A350</td><td>WP12-2</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF11</td><td>ASTM A234ASTM A350</td><td>WP11-1</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF11G</td><td>ASTM A234ASTM A350</td><td>WP11-2</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF14</td><td>—</td><td>—</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF22</td><td>ASTM A234ASTM A350</td><td> $WP22-2^d$ </td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF22G</td><td>ASTM A234ASTM A350</td><td>WP22-3</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF5</td><td>ASTM A234ASTM A350</td><td>WP5</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF5G</td><td>ASTM A234ASTM A350</td><td> $WP5^d$ </td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF9</td><td>ASTM A234ASTM A350</td><td>WP9 Cl.1</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF9G</td><td>ASTM A234ASTM A350</td><td>WP9 Cl.3</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>AF91</td><td>ASTM A234ASTM A350</td><td>WP91</td></tr><tr><td colspan="4">合金钢铸件</td></tr><tr><td>NB/T 11268</td><td>ZG14Cr1Mo</td><td>ASTM A217</td><td>WC6</td></tr><tr><td>NB/T 11268</td><td>ZG12Cr2Mo</td><td>ASTM A217</td><td>WC9</td></tr><tr><td>NB/T 11268</td><td>ZG10Cr9Mo1VNbN</td><td>ASTM A217</td><td> $C12^c$ </td></tr><tr><td>GB/T 16253</td><td>ZG16Cr5MoG</td><td>ASTM A217</td><td>C5</td></tr><tr><td colspan="4">不锈钢无缝管</td></tr><tr><td>GB/T 14976</td><td>022Cr19Ni10</td><td>ASTM A312</td><td>TP304L</td></tr><tr><td>GB/T 14976</td><td>06Cr19Ni10</td><td>ASTM A312</td><td>TP304</td></tr><tr><td>GB/T 5310GB/T 9948GB/T 14976</td><td>07Cr19Ni10</td><td>ASTM A312</td><td>TP304H</td></tr><tr><td>GB/T 9948GB/T 14976</td><td>022Cr17Ni12Mo2</td><td>ASTM A312</td><td>TP316L</td></tr><tr><td>GB/T 14976</td><td>06Cr17Ni12Mo2</td><td>ASTM A312</td><td>TP316</td></tr><tr><td>GB/T 14976</td><td>07Cr17Ni12Mo2</td><td>ASTM A312</td><td>TP316H</td></tr><tr><td>GB/T 14976</td><td>06Cr18Ni11Ti</td><td>ASTM A312</td><td>TP321</td></tr><tr><td>GB/T 5310GB/T 9948GB/T 14976</td><td>07Cr19Ni11Ti</td><td>ASTM A312</td><td>TP321H</td></tr><tr><td>GB/T 14976</td><td>06Cr18Ni11Nb</td><td>ASTM A312</td><td>TP347</td></tr><tr><td>GB/T 5310GB/T 9948GB/T 14976</td><td>07Cr18Ni11Nb</td><td>ASTM A312</td><td>TP347H</td></tr><tr><td>GB/T 5310</td><td>08Cr18Ni11NbFG</td><td>ASTM A213</td><td>347HFG</td></tr><tr><td>GB/T 14976</td><td>06Cr23Ni13</td><td>ASTM A312</td><td>TP309</td></tr><tr><td>GB/T 14976</td><td>06Cr25Ni20</td><td>ASTM A312</td><td>TP310</td></tr><tr><td>GB/T 21833.2</td><td>022Cr22Ni5Mo3N</td><td>ASTM A790</td><td>31803</td></tr><tr><td>GB/T 21833.2</td><td>022Cr23Ni5Mo3N</td><td>ASTM A790</td><td>32205</td></tr><tr><td>GB/T 21833.2</td><td>022Cr25Ni7Mo4N</td><td>ASTM A790</td><td>32750</td></tr><tr><td colspan="4">不锈钢焊管(EFW,无填充金属)</td></tr><tr><td>GB/T 12771HG/T 20537.3</td><td>022Cr19Ni10</td><td>ASTM A312</td><td>TP304L-W</td></tr><tr><td>GB/T 12771HG/T 20537.3</td><td>06Cr19Ni10</td><td>ASTM A312</td><td>TP304-W</td></tr><tr><td>GB/T 12771HG/T 20537.3</td><td>022Cr17Ni12Mo2</td><td>ASTM A312</td><td>TP316L-W</td></tr><tr><td>GB/T 12771HG/T 20537.3</td><td>06Cr17Ni12Mo2</td><td>ASTM A312</td><td>TP316-W</td></tr><tr><td>GB/T 12771HG/T 20537.3</td><td>06Cr18Ni11Ti</td><td>ASTM A312</td><td>TP321-W</td></tr><tr><td>GB/T 12771</td><td>06Cr18Ni11Nb</td><td>ASTM A312</td><td>TP347-W</td></tr><tr><td>GB/T 12771</td><td>06Cr23Ni13</td><td>ASTM A312</td><td>TP309-W</td></tr><tr><td>GB/T 12771</td><td>06Cr25Ni20</td><td>ASTM A312</td><td>TP310-W</td></tr><tr><td>GB/T 21832.2</td><td>022Cr22Ni5Mo3N</td><td>ASTM A790</td><td>31803-W</td></tr><tr><td>GB/T 21832.2</td><td>022Cr23Ni5Mo3N</td><td>ASTM A790</td><td>32205-W</td></tr><tr><td>GB/T 21832.2</td><td>022Cr25Ni7Mo4N</td><td>ASTM A790</td><td>32750-W</td></tr><tr><td colspan="4">不锈钢板焊管(EFW)</td></tr><tr><td>GB/T 32964HG/T 20537.4</td><td>022Cr19Ni10</td><td>ASTM A358</td><td>304L</td></tr><tr><td>GB/T 32964HG/T 20537.4</td><td>06Cr19Ni10</td><td>ASTM A358</td><td>304</td></tr><tr><td>GB/T 32964HG/T 20537.4</td><td>022Cr17Ni12Mo2</td><td>ASTM A358</td><td>316L</td></tr><tr><td>GB/T 32964HG/T 20537.4</td><td>06Cr17Ni12Mo2</td><td>ASTM A358</td><td>316</td></tr><tr><td>GB/T 32964HG/T 20537.4</td><td>06Cr18Ni11Ti</td><td>ASTM A358</td><td>321</td></tr><tr><td>GB/T 32964</td><td>06Cr18Ni11Nb</td><td>ASTM A358</td><td>347</td></tr><tr><td colspan="4">不锈钢管件(包括对焊、锻制)</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF304L</td><td>ASTM A403</td><td>WP304L</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF304</td><td>ASTM A403</td><td>WP304</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF304H</td><td>ASTM A403</td><td>WP304H</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF316L</td><td>ASTM A403</td><td>WP316L</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF316</td><td>ASTM A403</td><td>WP316</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF316H</td><td>ASTM A403</td><td>WP316H</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF321</td><td>ASTM A403</td><td>WP321</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF321H</td><td>ASTM A403</td><td>WP321H</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF347</td><td>ASTM A403</td><td>WP347</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF347H</td><td>ASTM A403</td><td>WP347H</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF310</td><td>ASTM A403</td><td>WP310</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF2225</td><td>ASTM A815</td><td>WP31803</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF2205</td><td>ASTM A815</td><td>WP32205</td></tr><tr><td>GB/T 13401GB/T 14383</td><td>SF2507</td><td>ASTM A815</td><td>WP32750</td></tr><tr><td colspan="4">不锈钢铸件</td></tr><tr><td>GB/T 12230</td><td>CF3</td><td>ASTM A351</td><td>CF3</td></tr><tr><td>GB/T 12230</td><td>CF8</td><td>ASTM A351</td><td>CF8</td></tr><tr><td>GB/T 12230</td><td>CF3M</td><td>ASTM A351</td><td>CF3M</td></tr><tr><td>GB/T 12230</td><td>CF8M</td><td>ASTM A351</td><td>CF8M</td></tr><tr><td>GB/T 12230</td><td>CF8C</td><td>ASTM A351</td><td>CF8C</td></tr><tr><td colspan="4">镍及镍合金管</td></tr><tr><td>NB/T 47047</td><td>N5</td><td>ASTM B161</td><td>UNS N02201</td></tr><tr><td>NB/T 47047</td><td>N7</td><td>ASTM B161</td><td>UNS N02200</td></tr><tr><td>NB/T 47047</td><td>NCu30</td><td>ASTM B165</td><td>UNS N04400</td></tr><tr><td>NB/T 47047</td><td>NS1102</td><td>ASTM B407</td><td>UNS N08810</td></tr><tr><td>NB/T 47047</td><td>NS1104</td><td>ASTM B407</td><td>UNS N08811</td></tr><tr><td>NB/T 47047</td><td>NS1101</td><td>ASTM B407</td><td>UNS N08800</td></tr><tr><td>NB/T 47047</td><td>NS3102</td><td>ASTM B167</td><td>UNS N06600</td></tr><tr><td>NB/T 47047</td><td>NS1402</td><td>ASTM B705</td><td>UNS N08825</td></tr><tr><td>NB/T 47047</td><td>NS3304</td><td>ASTM B622</td><td>UNS N10276</td></tr><tr><td>NB/T 47047</td><td>NS3306</td><td>ASTM B444</td><td>UNS N06625</td></tr><tr><td colspan="4">镍及镍合金管件</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNL(N02201)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPN(N02200)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>NCu30(N04400)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNIC10(N08810)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNIC11(N08811)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNIC(N08800)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNCI(N06600)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNICMC(N08825)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPHC276(N10276)</td></tr><tr><td>—</td><td>—</td><td>ASTM B366</td><td>WPNCMC(N06625)</td></tr><tr><td colspan="4">镍及镍合金锻件</td></tr><tr><td>NB/T 47028</td><td>N5</td><td>ASTM B564</td><td>UNS N02201</td></tr><tr><td>NB/T 47028</td><td>N7</td><td>ASTM B564</td><td>UNS N02200</td></tr><tr><td>NB/T 47028</td><td>NCu30</td><td>ASTM B564</td><td>UNS N04400</td></tr><tr><td>NB/T 47028</td><td>NS1102</td><td>ASTM B564</td><td>UNS N08810</td></tr><tr><td>NB/T 47028</td><td>NS1104</td><td>ASTM B564</td><td>UNS N08811</td></tr><tr><td>NB/T 47028</td><td>NS1101</td><td>ASTM B564</td><td>UNS N08800</td></tr><tr><td>NB/T 47028</td><td>NS3102</td><td>ASTM B564</td><td>UNS N06600</td></tr><tr><td>NB/T 47028</td><td>NS1402</td><td>ASTM B564</td><td>UNS N08825</td></tr><tr><td>NB/T 47028</td><td>NS3304</td><td>ASTM B564</td><td>UNS N10276</td></tr><tr><td>NB/T 47028</td><td>NS3306</td><td>ASTM B564</td><td>UNS N06625</td></tr><tr><td colspan="4">钛及钛合金管(无缝管及挤压管)</td></tr><tr><td>GB/T 3624</td><td>TA1G</td><td>ASTM B861</td><td>1</td></tr><tr><td>GB/T 26058</td><td>TA1</td><td>ASTM B861</td><td>1</td></tr><tr><td>GB/T 3624</td><td>TA2G</td><td>ASTM B861</td><td>2</td></tr><tr><td>GB/T 26058</td><td>TA2</td><td>ASTM B861</td><td>2</td></tr><tr><td>GB/T 3624</td><td>TA3G</td><td>ASTM B861</td><td>3</td></tr><tr><td>GB/T 26058</td><td>TA3</td><td>ASTM B861</td><td>3</td></tr><tr><td>GB/T 3624</td><td>TA9</td><td>ASTM B861</td><td>7</td></tr><tr><td>GB/T 3624</td><td>TA9-1</td><td>ASTM B861</td><td>7</td></tr><tr><td>GB/T 26058</td><td>TA9</td><td>ASTM B861</td><td>7</td></tr><tr><td>GB/T 3624</td><td>TA10</td><td>ASTM B861</td><td>12</td></tr><tr><td>GB/T 26058</td><td>TA10</td><td>ASTM B861</td><td>12</td></tr><tr><td colspan="4">钛及钛合金管(EFW 焊管-无填充金属)</td></tr><tr><td>GB/T 26057</td><td>TA1</td><td>ASTM B862</td><td>1</td></tr><tr><td>GB/T 26057</td><td>TA2</td><td>ASTM B862</td><td>2</td></tr><tr><td>GB/T 26057</td><td>TA3</td><td>ASTM B862</td><td>3</td></tr><tr><td>GB/T 26057</td><td>TA9</td><td>ASTM B862</td><td>7</td></tr><tr><td>GB/T 26057</td><td>TA10</td><td>ASTM B862</td><td>12</td></tr><tr><td colspan="4">钛及钛合金管件</td></tr><tr><td>GB/T 27684</td><td>TA1</td><td>ASTM B363</td><td>WPT1</td></tr><tr><td>GB/T 27684</td><td>TA2</td><td>ASTM B363</td><td>WPT2</td></tr><tr><td>GB/T 27684</td><td>TA3</td><td>ASTM B363</td><td>WPT3</td></tr><tr><td>GB/T 27684</td><td>TA9</td><td>ASTM B363</td><td>WPT7</td></tr><tr><td>GB/T 27684</td><td>TA10</td><td>ASTM B363</td><td>WPT12</td></tr><tr><td colspan="4">钛及钛合金锻件</td></tr><tr><td>GB/T 25137</td><td>F1</td><td>ASTM B381</td><td>F1</td></tr><tr><td>GB/T 25137</td><td>F2</td><td>ASTM B381</td><td>F2</td></tr><tr><td>GB/T 25137</td><td>F3</td><td>ASTM B381</td><td>F3</td></tr><tr><td>GB/T 25137</td><td>F7</td><td>ASTM B381</td><td>F7</td></tr><tr><td>GB/T 25137</td><td>F12</td><td>ASTM B381</td><td>F12</td></tr><tr><td colspan="4">钛及钛合金铸件</td></tr><tr><td>GB/T 6614</td><td>ZTA1</td><td>ASTM B367</td><td>C-2</td></tr><tr><td>GB/T 6614</td><td>ZTA2</td><td>ASTM B367</td><td>C-3</td></tr><tr><td colspan="4">铝及铝合金管</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>1060-O</td><td>ASTM B210</td><td>1060-O</td></tr><tr><td>GB/T 4437.1GB/T 38512</td><td>1060-H112</td><td>ASTM B210</td><td>1060-H112</td></tr><tr><td>GB/T 6893</td><td>1060-H14</td><td>ASTM B210</td><td>1060-H14</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>3003-O</td><td>ASTM B210</td><td>3003-O</td></tr><tr><td>GB/T 4437.1GB/T 38512</td><td>3003-H112</td><td>ASTM B210</td><td>3003-H112</td></tr><tr><td>GB/T 6893</td><td>3003-H14</td><td>ASTM B210</td><td>3003-H14</td></tr><tr><td>GB/T 4437.1GB/T 6893</td><td>5052-O</td><td>ASTM B210</td><td>5052-O</td></tr><tr><td>GB/T 4437.1</td><td>5052-H112</td><td>ASTM B210</td><td>5052-H112</td></tr><tr><td>GB/T 6893</td><td>5052-H14</td><td>ASTM B210</td><td>5052-H14</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>5083-O</td><td>ASTM B210</td><td>5083-O</td></tr><tr><td>GB/T 4437.1GB/T 38512</td><td>5083-H112</td><td>ASTM B210</td><td>5083-H112</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>6061-T4 焊,T6 焊</td><td>ASTM B210</td><td>6061-T4 Wld,T6 Wld</td></tr><tr><td>GB/T 6893GB/T 38512</td><td>6061-T4</td><td>ASTM B210</td><td>6061-T4</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>6061-T6</td><td>ASTM B210</td><td>6061-T6</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>6063-T4 焊,T6 焊</td><td>ASTM B210</td><td>6063-T4Wld,T6 Wld</td></tr><tr><td>GB/T 6893GB/T 38512</td><td>6063-T4</td><td>ASTM B210</td><td>6063-T4</td></tr><tr><td>GB/T 4437.1GB/T 6893GB/T 38512</td><td>6063-T6</td><td>ASTM B210</td><td>6063-T6</td></tr><tr><td colspan="4">铝及铝合金管件</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP1060-OWP1060-H112</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP3003-OWP3003-H112</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP5052-OWP5052-H34</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP5083-O</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP6061-T4WP6061-T6</td></tr><tr><td>—</td><td>—</td><td>ASTM B361</td><td>WP6063-T4WP6063-T6</td></tr><tr><td colspan="4">铝及铝合金锻件</td></tr><tr><td>NB/T 47029</td><td>1050A-H112</td><td>—</td><td>—</td></tr><tr><td>NB/T 47029</td><td>3003-H112</td><td>ASTM B247</td><td>3003</td></tr><tr><td>NB/T 47029</td><td>5083-H112</td><td>ASTM B247</td><td>5083</td></tr><tr><td>NB/T 47029</td><td>6061-T6</td><td>ASTM B247</td><td>6061</td></tr><tr><td colspan="4">标准紧固件</td></tr><tr><td>GB/T 3098.1</td><td>5.6</td><td>ISO 898-1</td><td>5.6</td></tr><tr><td>GB/T 3098.1</td><td>8.8</td><td>ISO 898-1</td><td>8.8</td></tr><tr><td>GB/T 3098.6</td><td>A2-50</td><td>ISO 3506-4</td><td>A2-50</td></tr><tr><td>GB/T 3098.6</td><td>A4-50</td><td>ISO 3506-4</td><td>A4-50</td></tr><tr><td>GB/T 3098.6</td><td>A2-70</td><td>ISO 3506-4</td><td>A2-70</td></tr><tr><td>GB/T 3098.6</td><td>A4-70</td><td>ISO 3506-4</td><td>A4-70</td></tr><tr><td colspan="4">专用紧固件</td></tr><tr><td>HG/T 20634</td><td>35CrMo</td><td>ASTM A193</td><td>B7</td></tr><tr><td>HG/T 20634</td><td>42CrMo(B7)</td><td>ASTM A193</td><td>B7</td></tr><tr><td>HG/T 20634</td><td>25Cr2MoV</td><td>ASTM A193</td><td>B16</td></tr><tr><td>HG/T 20634</td><td>06Cr19Ni10(304)</td><td>ASTM A193</td><td>B8</td></tr><tr><td>HG/T 20634</td><td>06Cr17Ni12Mo2(316)</td><td>ASTM A193</td><td>B8M</td></tr><tr><td>HG/T 20634</td><td>A193 B8-2</td><td>ASTM A193</td><td>B8-2</td></tr><tr><td>HG/T 20634</td><td>A193 B8M-2</td><td>ASTM A193</td><td>B8M-2</td></tr><tr><td>HG/T 20634</td><td>A320 L7</td><td>ASTM A320</td><td>L7</td></tr><tr><td>HG/T 20634</td><td>A453-660</td><td>ASTM A453</td><td>660</td></tr><tr><td colspan="4"> $^a$ 均属碳钢,ASTM 材料机械性能(抗拉/屈服)相对略高。 $^b$ 均属碳钢,ASTM 材料机械性能(抗拉/屈服)相对较低。 $^c$ 化学成分相近,因热处理制度差异,ASTM 材料机械性能(抗拉/屈服)相对略高。 $^d$ 化学成分相近,因热处理制度差异,ASTM 材料机械性能(抗拉/屈服)相对较低。</td></tr></table>

## 附录F

(资料性)

## 风荷载和地震荷载的计算

## F.1 水平风力的计算

作用于管道上的水平风力可看成为作用于管道上的均布荷载，对于不等直径的管道，按直径分段进行均布荷载的计算。单位长度上的水平风力可按公式(F.1)计算：

$$
p = K _ {1} K _ {2} q _ {0} \mu_ {z} D \times 1 0 ^ {- 6}\tag{……( F.1}
$$

式中：

p ——单位长度上管道所受的水平风力,单位为牛顿每毫米(N/mm);

$q_{0}$ ——基本风压值,单位为牛顿每平方米 $\left(\mathrm{N}/\mathrm{m}^{2}\right)$ ,按表 F.1 查取;

$\mu_{z}$ ——风压高度变化系数,按表 F.2 查取;

D ——所计算的管道外径,如有保温层,需计及保温层的厚度,单位为毫米(mm);

$K_{1}$ ——空气动力系数,按以下取值:

a）上下双管(见图 F.1)， $K_{1}$ 按表 F.3 取值；

表 F.1 全国主要城市的风压数据 $q_{0}$  
单位为千牛每立方米

<table><tr><td>城市名</td><td>北京</td><td>天津</td><td>塘沽</td><td>上海</td><td>重庆</td><td>石家庄</td><td>邢台</td><td>张家口</td></tr><tr><td>风压</td><td>0.45</td><td>0.50</td><td>0.55</td><td>0.55</td><td>0.40</td><td>0.35</td><td>0.30</td><td>0.55</td></tr><tr><td>城市名</td><td>承德</td><td>秦皇岛</td><td>唐山</td><td>保定</td><td>沧州</td><td>太原</td><td>大同</td><td>阳泉</td></tr><tr><td>风压</td><td>0.40</td><td>0.45</td><td>0.40</td><td>0.40</td><td>0.40</td><td>0.40</td><td>0.55</td><td>0.40</td></tr><tr><td>城市名</td><td>临汾</td><td>长治县</td><td>呼和浩特</td><td>满洲里</td><td>海拉尔</td><td>乌兰浩特</td><td>包头</td><td>集宁</td></tr><tr><td>风压</td><td>0.40</td><td>0.50</td><td>0.55</td><td>0.65</td><td>0.65</td><td>0.55</td><td>0.55</td><td>0.60</td></tr><tr><td>城市名</td><td>通辽</td><td>赤峰</td><td>沈阳</td><td>阜新</td><td>锦州</td><td>鞍山</td><td>本溪</td><td>抚顺</td></tr><tr><td>风压</td><td>0.55</td><td>0.55</td><td>0.55</td><td>0.60</td><td>0.60</td><td>0.50</td><td>0.45</td><td>0.45</td></tr><tr><td>城市名</td><td>营口</td><td>丹东</td><td>大连</td><td>长春</td><td>四平</td><td>吉林</td><td>通化</td><td>哈尔滨</td></tr><tr><td>风压</td><td>0.65</td><td>0.55</td><td>0.65</td><td>0.65</td><td>0.55</td><td>0.50</td><td>0.50</td><td>0.55</td></tr><tr><td>城市名</td><td>齐齐哈尔</td><td>绥化</td><td>安达</td><td>牡丹江</td><td>济南</td><td>德州</td><td>烟台</td><td>威海</td></tr><tr><td>风压</td><td>0.45</td><td>0.55</td><td>0.55</td><td>0.50</td><td>0.45</td><td>0.45</td><td>0.55</td><td>0.65</td></tr><tr><td>城市名</td><td>淄博</td><td>青岛</td><td>兖州</td><td>南京</td><td>徐州</td><td>镇江</td><td>无锡</td><td>泰州</td></tr><tr><td>风压</td><td>0.40</td><td>0.60</td><td>0.40</td><td>0.40</td><td>0.35</td><td>0.40</td><td>0.45</td><td>0.40</td></tr><tr><td>城市名</td><td>连云</td><td>常州</td><td>杭州</td><td>金华</td><td>宁波</td><td>衢州</td><td>温州</td><td>合肥</td></tr><tr><td>风压</td><td>0.55</td><td>0.40</td><td>0.45</td><td>0.35</td><td>0.50</td><td>0.35</td><td>0.60</td><td>0.35</td></tr><tr><td>城市名</td><td>宿县</td><td>蚌埠</td><td>安庆</td><td>南昌</td><td>赣州</td><td>景德镇</td><td>福州</td><td>厦门</td></tr><tr><td>风压</td><td>0.40</td><td>0.35</td><td>0.40</td><td>0.45</td><td>0.30</td><td>0.35</td><td>0.70</td><td>0.80</td></tr><tr><td>城市名</td><td>西安</td><td>榆林</td><td>宝鸡</td><td>兰州</td><td>酒泉</td><td>张掖</td><td>武威</td><td>天水</td></tr><tr><td>风压</td><td>0.35</td><td>0.40</td><td>0.35</td><td>0.30</td><td>0.55</td><td>0.50</td><td>0.55</td><td>0.35</td></tr><tr><td>城市名</td><td>银川</td><td>中卫</td><td>西宁</td><td>格尔木</td><td>乌鲁木齐</td><td>克拉玛依</td><td>库尔勒</td><td>喀什</td></tr><tr><td>风压</td><td>0.65</td><td>0.45</td><td>0.35</td><td>0.40</td><td>0.60</td><td>0.90</td><td>0.45</td><td>0.55</td></tr><tr><td>城市名</td><td>哈密</td><td>郑州</td><td>新乡</td><td>洛阳</td><td>许昌</td><td>开封</td><td>武汉</td><td>宜昌</td></tr><tr><td>风压</td><td>0.60</td><td>0.45</td><td>0.40</td><td>0.40</td><td>0.40</td><td>0.45</td><td>0.35</td><td>0.30</td></tr><tr><td>城市名</td><td>黄石</td><td>长沙</td><td>岳阳</td><td>邵阳</td><td>衡阳</td><td>广州</td><td>汕头</td><td>深圳</td></tr><tr><td>风压</td><td>0.35</td><td>0.35</td><td>0.40</td><td>0.30</td><td>0.40</td><td>0.50</td><td>0.80</td><td>0.75</td></tr><tr><td>城市名</td><td>湛江</td><td>南宁</td><td>桂林</td><td>柳州</td><td>梧州</td><td>北海</td><td>海口</td><td>三亚</td></tr><tr><td>风压</td><td>0.80</td><td>0.35</td><td>0.30</td><td>0.30</td><td>0.30</td><td>0.75</td><td>0.75</td><td>0.85</td></tr><tr><td>城市名</td><td>成都</td><td>宜宾</td><td>西昌</td><td>内江</td><td>泸州</td><td>贵阳</td><td>遵义</td><td>昆明</td></tr><tr><td>风压</td><td>0.30</td><td>0.30</td><td>0.30</td><td>0.40</td><td>0.30</td><td>0.30</td><td>0.30</td><td>0.30</td></tr></table>

表 F.2 风压高度变化系数 $\mu_{z}$

<table><tr><td rowspan="2">计算截面距地面高度 $^a$ m</td><td colspan="4">地面粗糙度类别 $^b$ </td></tr><tr><td>A</td><td>B</td><td>C</td><td>D</td></tr><tr><td>5</td><td>1.09</td><td>1.00</td><td>0.65</td><td>0.51</td></tr><tr><td>10</td><td>1.28</td><td>1.00</td><td>0.65</td><td>0.51</td></tr><tr><td>15</td><td>1.42</td><td>1.13</td><td>0.65</td><td>0.51</td></tr><tr><td>20</td><td>1.52</td><td>1.23</td><td>0.74</td><td>0.51</td></tr><tr><td>30</td><td>1.67</td><td>1.39</td><td>0.88</td><td>0.51</td></tr><tr><td>40</td><td>1.79</td><td>1.52</td><td>1.00</td><td>0.60</td></tr><tr><td>50</td><td>1.89</td><td>1.62</td><td>1.10</td><td>0.69</td></tr><tr><td>60</td><td>1.97</td><td>1.71</td><td>1.20</td><td>0.77</td></tr><tr><td>70</td><td>2.05</td><td>1.79</td><td>1.28</td><td>0.84</td></tr><tr><td>80</td><td>2.12</td><td>1.87</td><td>1.36</td><td>0.91</td></tr><tr><td>90</td><td>2.18</td><td>1.93</td><td>1.43</td><td>0.98</td></tr><tr><td>100</td><td>2.23</td><td>2.00</td><td>1.50</td><td>1.04</td></tr><tr><td>150</td><td>2.46</td><td>2.25</td><td>1.79</td><td>1.33</td></tr><tr><td>200</td><td>2.64</td><td>2.46</td><td>2.03</td><td>1.58</td></tr><tr><td colspan="5"> $^a$ 可按一根管道的最高点查取,但当将  $μ_z$  用于计算  $K_2$  时,应按一根管道的最低点查取。 $^b$  A 类系指近海海面及海岛、海岸、湖岸及沙漠地区;B 类系指田野、乡村、丛林、丘陵以及房屋比较稀疏的乡镇和城市郊区;C 类系指有密集建筑群的城市市区;D 类系指有密集建筑群且房屋较高的城市市区。</td></tr></table>

![](images/3e01a342cb1d0af1fb10d00d3faebf9e19b416a79cbb639c6702b34c12ee410c.jpg)  
图F.1 上下双管示意图

表 F.3 上下双管系数 $K_{1}$

<table><tr><td>s/d</td><td> $\leqslant 0.25$ </td><td>0.5</td><td>0.75</td><td>1.0</td><td>1.5</td><td>2.0</td><td> $\geqslant 3.0$ </td></tr><tr><td> $K_1$ </td><td>1.2</td><td>0.9</td><td>0.75</td><td>0.7</td><td>0.65</td><td>0.63</td><td>0.6</td></tr></table>

b) 前后双管(见图 F.2), $K_{1}$ 按表 F.4 取值;

![](images/9a6949603166d72bc5abe4c7af5b834188dbc5caee254dfbebe54d29c6cdc621.jpg)  
图F.2 前后双管示意图

表 F.4 前后双管系数 $K_{1}$

<table><tr><td> $s/d$ </td><td> $\leqslant 0.25$ </td><td>0.5</td><td>1.5</td><td>3.0</td><td>4.0</td><td>6.0</td><td>8.0</td><td> $\geqslant 10.0$ </td></tr><tr><td> $K_1$ </td><td>0.68</td><td>0.86</td><td>0.94</td><td>0.99</td><td>1.08</td><td>1.11</td><td>1.14</td><td>1.20</td></tr><tr><td colspan="9">注:表列 $K_1$ 为前后两管之和,其中前管为0.6。</td></tr></table>

c) 密排多管(见图 F.3), $K_{1}=1.4$ 。

![](images/a57503efa0c169004e42b920d814e45e4c36a503ef1c3d54030fa8c0e249070f.jpg)  
图 F.3 密排多管示意图

$K_{1}$ 值为各管之总和。

$K_{2}$ ——风振系数,按公式(F.2)计算:

$$
K _ {2} = 1 + 5 I _ {1 0} B _ {z} \sqrt {1 + R _ {2}}\tag{……( F.2}
$$

式中：

$I_{10}$ ——10 m 高度名义湍流强度，对应 A、B、C 和 D 类地面粗糙度，可分别取 0.12、0.14、0.23 和 0.39；

R ——脉动风荷载的共振分量因子,按公式(F.3)、公式(F.4)计算:

$$
R = \sqrt {\frac {\pi}{0 . 0 6} \cdot \frac {X _ {1} ^ {2}}{\left(1 + X _ {1} ^ {2}\right) ^ {4 / 3}}}\tag{……( F.3}
$$

$$
X _ {1} = \frac {3 0 f _ {1}}{\sqrt {k _ {\mathrm{w}} q _ {0}}}, X _ {1} > 5\tag{……( F.4}
$$

式中：

$f_{1}$ ——管道系统第1阶自振频率,单位为赫兹(Hz);

注：计算管道系统的自振频率时，可在固定支架处将管段分开计算。对于非等直径、作用有集中荷载或多支承管道系统，其自振频率可用合适的数值方法求得，如矩阵传递法、矩阵迭代或有限元法等。

$k_{w}$ ——地面粗糙度修正系数，对 A、B、C 和 D 类地面粗糙度分别取 1.28、1.00、0.54 和 0.26；

$B_{z}$ ——脉动风荷载的背景分量因子,按公式(F.5)计算:

$$
B _ {z} = k H ^ {\alpha_ {1}} \rho_ {z} \frac {\phi_ {1} (z)}{\mu_ {z}}\tag{……( F.5}
$$

式中：

$\phi_{1}(z)$ ——管道系统第1阶振型系数,振型系数指在某一振型下一点的水平相对位移,当水平风力按均布荷载计算时,可保守地取1.0;

H ——管道系统总高度,单位为米(m);

$\rho_{z}$ ——脉动风荷载竖直方向相关系数,按公式(F.6)计算:

$$
\rho_ {z} = \frac {1 0 \sqrt {H + 6 0 e ^ {- H / 6 0} - 6 0}}{H}\tag{……( F.6}
$$

$k, \alpha_{1}$ ——系数，按表 F.5 取值。

表 F.5 系数 $k$ 和 $\alpha_{1}$

<table><tr><td>粗糙度类别</td><td>A</td><td>B</td><td>C</td><td>D</td></tr><tr><td>k</td><td>1.276</td><td>0.910</td><td>0.404</td><td>0.155</td></tr><tr><td> $\alpha_1$ </td><td>0.186</td><td>0.218</td><td>0.292</td><td>0.376</td></tr></table>

对于远海海面和海岛的管道系统,风压高度变化系数除按 A 类粗糙度类别由表 F.2 确定外,还需用表 F.6 给出的修正系数进行修正。

表 F.6 远海海面和海岛的修正系数 $\eta$

<table><tr><td>距海岸距离km</td><td> $\eta$ </td></tr><tr><td>&lt;40</td><td>1.0</td></tr><tr><td>40~60</td><td>1.0~1.1</td></tr><tr><td>60~100</td><td>1.1~1.2</td></tr></table>

## F.2 水平地震力和地震弯矩的计算

地震将对管系产生与地面平行和垂直的两个方向上的作用力，本附录仅考虑地震引起的水平惯性力对管系的影响。与地面平行的地震作用力方向需选择使管系中应力水平最大的方向。本附录仅给出地震作用时，管道所受惯性力的一般计算方法，设计也可用更精确的方法进行计算。当求得管道上的分布惯性力后，可按照6.7.4.2和6.7.5.4对管道和管道组件进行强度校核，并按算得的支承反力保证支吊架有足够的强度。

当发生地震时,作用于管道上,对应于管道基本自振周期的水平分布力可按公式(F.7)计算:

$$
Q _ {k} = \alpha_ {1} \cdot \eta_ {1 k} \cdot \Delta m _ {k} \cdot g\tag{……( F.7}
$$

式中：

$Q_{k}$ ——管道质量作为离散分布，在 k 处的集中力，单位为牛顿(N)。

$\alpha_{1}$ ——对应于管道基本自振周期的地震影响系数 $\alpha$ ，地震影响系数 $\alpha$ 按图F.4确定，但不小于 $0.2\alpha_{\mathrm{max}}$ 。

![](images/896f0db63181f9166752da8661a0261a5cc3d4f828326cce21952e76ebbe04c7.jpg)  
图 F.4 地震影响系数曲线

$\alpha_{max}$ ——地震影响系数的最大值,见表 F.7。

表 F.7 对应于设防烈度的 $\alpha_{max}$

<table><tr><td>设防烈度</td><td>6</td><td>7</td><td>8</td><td>9</td></tr><tr><td> $\alpha_{\max}$ </td><td>0.04</td><td>0.08(0.12)</td><td>0.16(0.24)</td><td>0.32</td></tr><tr><td colspan="5">注:括号中数值分别用于设计基础地震加速度为0.15g和0.3g的地区。</td></tr></table>

$T_{g}$ ——各类场地土的特征周期,见表 F.8。

表 F.8 各类场地土的特征周期 $T_{g}$

<table><tr><td rowspan="2">设计地震分组</td><td colspan="5">场地土类别</td></tr><tr><td> $I_0$ </td><td> $I_1$ </td><td>II</td><td>III</td><td>IV</td></tr><tr><td>第一组</td><td>0.20</td><td>0.25</td><td>0.35</td><td>0.45</td><td>0.65</td></tr><tr><td>第二组</td><td>0.25</td><td>0.30</td><td>0.40</td><td>0.55</td><td>0.75</td></tr><tr><td>第三组</td><td>0.30</td><td>0.35</td><td>0.45</td><td>0.65</td><td>0.90</td></tr></table>

$\gamma$ ——曲线下降段的衰减指数,按公式(F.8)计算:

$$
\gamma = 0. 9 + \frac {0 . 0 5 - \xi}{0 . 3 + 6 \xi}\tag{……( F.8}
$$

式中：

$\xi$ ——阻尼比；

$\eta_{1}$ ——直线下降段斜率的调整系数,按公式(F.9)计算,当 $\eta_{1}$ 小于 0 时,取 0:

$$
\eta_ {1} = 0. 0 2 + \frac {0 . 0 5 - \xi}{4 + 3 2 \xi}\tag{……( F.9}
$$

式中：

$\xi$ ——阻尼比；

$\eta_{2}$ ——阻尼调整系数,按公式(F.10)计算,当 $\eta_{2}$ 小于 0.55 时,取 0.55:

$$
\eta_ {2} = 1 + \frac {0 . 0 5 - \xi}{0 . 0 8 + 1 . 6 \xi}\tag{……( F.10}
$$

式中：

$\xi$ ——阻尼比；

$\eta_{1k}$ ——管道上 k 处的基本振型参与系数, 按公式(F.11)计算:

$$
\eta_ {1 k} = \frac {\chi_ {k} \sum_ {i = 1} ^ {n} \Delta m _ {i} \chi_ {i}}{\sum_ {i = 1} ^ {n} \Delta m _ {i} \chi_ {i} ^ {2}}\tag{……( F.11}
$$

式中：

$\chi, \chi_{k}$ ——在地震荷载作用下，管道上某处或 k 处对应于所求振型的水平位移，单位为毫米(mm)； $\Delta m_{k}$ ——管道质量作为离散分布，第 k 段的质量，单位为千克(kg)。

地震荷载作用于管道的弯矩可按照以上所述的水平分布力进行计算。一般，对于管道在地震作用下的受激振动，需考虑高阶振型的影响，可按公式(F.12)近似计算考虑高阶振型影响后的地震弯矩，也可按更详细的振型分析结果对弯矩进行组合：

$$
M _ {\mathrm{h}} = 1. 2 5 M _ {\mathrm{b}}\tag{……( F.12}
$$

式中：

$M_{h}$ ——考虑高阶振型影响后的地震弯矩,单位为牛顿毫米(N·mm);

$M_{b}$ ——对应于基本振型的地震弯矩,单位为牛顿毫米(N·mm)。

# 附录 G

# (资料性)

# 管道布置

## G.1 管道布置基本原则

管道布置设计是将工艺管道及附属公用管道按一定的规则进行空间定位的过程。本附录仅从安全角度对管道布置设计给出一些指导性的实践经验。管道布置的基本原则如下。

a）满足管道及仪表控制流程设计的要求。

b) 满足有关的规范、标准的要求。

c) 管道布置统筹规划，做到安全可靠、经济合理、整齐美观。

d) 满足施工、操作和维修等方面的要求。

e）在确定进、出装置的管道方位与敷设方式时，做到内外协调。

f) 厂区内的全厂性管道的敷设，与厂区内的装置(单元)、道路、建筑物、构筑物等协调，避免管道包围装置(单元)，减少管道与铁路、道路的交叉。

g）永久性的地上、地下管道不穿越或跨越与其无关的工艺装置、系统单元或储罐组，在跨越罐区泵房的易燃气体、液化烃和易燃液体的管道上不设置阀门及易发生泄漏的管道附件。

h）管道布置满足管道柔性及设备、机泵管口允许的作用力和力矩要求，且使管道短，弯头数量少。

i) 当管道内介质流向自下而上时，管道布置时尽量做到逐步向上；当管道内介质流向自上而下时，管道布置时尽量做到逐步向下；否则需根据操作检修要求设置放空或放净，管道布置需减少死区。

j）管道布置中需能承受各种动力荷载，控制管道的振动，如风荷载、地震引起的水平力、压力脉动、机器共振等，在地震区设计的管道需满足国家现行抗震标准规定。

k）管道布置和支承点设置需同时考虑所能承受外部或内部的动力荷载，支承可靠，不发生管道与其支承件脱离、管道扭曲、下垂或立管不垂直等现象。

1) 管道的净空高度、净距及埋设深度满足现行有关标准的要求。

m）阀门布置在容易接近、便于操作和检修的地方，成排管道上的阀门集中布置，并设置操作平台及梯子，尽量减少阀门延伸杆或链轮操作，如要采用，不能阻挡操作通道。

n）管道布置不妨碍设备、机泵及其内部构件的安装、检修。

o）安全喷淋洗眼器根据腐蚀性介质或有毒介质的性质、操作特点和防护要求等设置，其服务半径范围不大于 $15 \, m$ 。

p）软管站需根据需要设置，站内可包括蒸汽、新鲜水、装置空气和氮气等，其服务半径的范围一般为 $15 \, m \sim 20 \, m$ 。

q）金属管道除与阀门、仪表、设备等需要用法兰或螺纹连接者外，尽量采用焊接连接。

## G.2 易燃介质和有毒介质管道的设计原则

易燃介质和有毒介质管道的设计原则如下。

a）管道不穿越与其无关的建(构)筑物。

b) 管道尽量架空或沿地面敷设, 当采用埋地敷设时, 需采取有效的安全措施防止气体或液体的积聚。

c) 在急性毒性类别 1 和类别 2 介质的生产区和使用区内,需设置安全喷淋洗眼器。

d) 设置在安全隔墙或隔板内急性毒性类别 1 和类别 2 介质管道上的手动阀门需采用阀门延伸

杆，且引至隔墙或隔板外操作。

e) 急性毒性类别 1 和类别 2、易燃气体类别 1 及易燃液体类别 1 介质采取密闭循环取样，取样口不设在有振动的设备或管道上，否则需采取减振措施，采样管道不引入化验室。

f) 易燃介质管道不安装在通风不良的厂房内、室内的吊顶内及建(构)筑物封闭的夹层内。

g）有毒介质、有腐蚀性介质管道，若布置在人行通道上方时，不设置阀门及易发生泄漏的管道附件，如不可避免，则需设置保护罩防止泄漏。

h) 氧气管道与易燃介质管道共架敷设时,需布置在外侧,且平行布置时,净距不小于 500 mm,交叉布置时,净距不小于 250 mm;当管道采用焊接连接结构,并无阀门时,其平行净距可取上述净距的 50%。

i) 除管道和仪表流程图上指定的要求外，对于紧急处理及防火需要开或关的阀门，需位于安全和方便操作的地方。

j) 进出装置的易燃介质的管道，在装置边界处需设隔断阀和8字盲板，在隔断阀处设平台，长度等于或大于 $8\mathrm{m}$ 的平台需在两个方向设梯子。

k）隔断设备用的阀门与急性毒性类别1和类别2介质的设备相连接时，管道上的阀门需与设备管口直接相连，且该阀门不使用链轮操作。

1) 特殊易燃介质管道如氢气、氧气、乙炔气等的管道布置满足现行有关标准的要求。

## G.3 蒸汽管道的设计原则

装置的蒸汽管道需架空敷设，尽量避免管沟敷设和埋地敷设。由工厂系统进入装置的主蒸汽管道，一般布置在管廊的上层。蒸汽管道的布置原则如下。

a）蒸汽支管从主管的顶部引出，支管上的切断阀安装在靠近主管的水平管段上，以避免存液。

b) 蒸汽主管进入装置界区的切断阀上游和主管末端设排液设施，排液设施需根据不同情况设放净阀、分液包及疏水阀。

c) 水平敷设的蒸汽主管上的排液设施的间隔距离如下：

1）在装置内，饱和蒸汽不大于 $80 \, m$ ，过热蒸汽不大于 $160 \, m$ ；

2）在装置外，顺坡时不大于 $300 \, m$ ，逆坡时不大于 $200 \, m$ 。

d) 不从有独立用汽要求的蒸汽管道上接出支管作其他用途。

e) 蒸汽支管的低点,需根据不同情况设排液阀或(和)疏水阀。

f) 在蒸汽管道的 $\pi$ 型补偿器上，不引出支管；在靠近 $\pi$ 型补偿器两侧的直管上引出支管时，支管不妨碍主管的位移；因主管热胀而产生的支管引出点的位移，不使支管承受过大的应力。

g）凡饱和蒸汽主管进入装置，在装置侧的边界附近设蒸汽分水器，在分水器下部设经常疏水措施，过热蒸汽主管进入装置一般可不设分水器。

h）多根蒸汽伴热管需成组布置并设分配管，分配管的蒸汽需就近从主管引出。

i) 直接排至大气的蒸汽放空管，在该管下端的弯头附近开一个 $\phi 6\mathrm{mm}\sim \phi 10\mathrm{mm}$ 的排液孔，并引至安全位置。

j）连续排放或经常排放的乏汽管道，排放口远离操作区布置。

## G.4 低温管道的设计原则

低温管道的设计原则如下：

a）低温介质管道的布置在满足管道柔性下需使管道短、弯头数量少，且减少液袋；

b) 低温介质管道要考虑整个管道有足够的柔性,充分利用管道自然补偿,当无法自然补偿时,需设置补偿器;

c) 布置低温管道时,需避免管道振动;若有机械的振源,需采取消振措施,在接近振源处的管道需

设置弹性组件,以隔断振源;

d）低温管道采用保冷管道支吊架，支吊架需有防止产生“冷桥”的措施；

e) 低温介质管道上的阀门需安装在水平管道上，阀杆方向需垂直向上；

f) 低温管道的间距需根据保冷后的法兰、阀门、测量组件的厚度以及管道的位移确定；

g）低温介质管道上的法兰不与弯头或三通直接焊接。

## G.5 泄放管道的设计原则

## G.5.1 放净与放空管道设计原则

G.5.1.1 管道系统中的高点或低点需根据操作、检修的要求，设置放空或放净。

G.5.1.2 为了尽量减少滞留在管道内介质的危害程度,如水锤、真空破裂、腐蚀及不能控制的化学反应,需在管道低点设置放净,高点设置放空。

G.5.1.3 管道需要完全放净时，管道需设置坡度，并设置放净点。下列介质管道，需要考虑完全放净：

a）多功能的管线；

b) 管道拆除时,会产生有害及危险介质;

c) 管道中的液体会产生聚合或固体沉淀；

d) 由于间歇生产,液体存在于管道内将影响液体的纯度;

e) 可能会产生气体冷凝液的管道；

f) 有可能增加液体残留量的两相流介质。

G.5.1.4 管道系统进行水压试验、吹扫、清洗时，需在管道高点设置放空。水压试验后或停工检修可在残存液体处设置放净。

G.5.1.5 全厂性管道的放净设置原则如下：

a）管廊上公用工程管道的末端及蒸汽管道的低点需设置放净；

b) 自燃点高出操作温度不足 $10^{\circ}$ C 的易燃液体管道的低点不设置放净；

c) 急性毒性类别 1 和类别 2 介质管道的低点不设置放净；

d) 腐蚀性介质的低点不设置放净；

e) 不产生凝结液的气体管道的低点不设置放净。

G.5.1.6 急性毒性类别 1 介质管道的放空或放净需设置双阀，并排入密闭回收系统。

G.5.1.7 除急性毒性类别 1 和类别 2 介质外,有毒气体的排放口按环保的要求,有毒液体不排入下水道。

G.5.1.8 急性毒性类别 2 介质的管道的放空或放净需设置双阀, 当设置单阀时, 需加盲板或法兰盖。

G.5.1.9 高压管道的放空或放净需设置双阀，当设置单阀时，需加盲板或法兰盖。

G.5.1.10 连续操作的易燃气体管道低点的放净需设置双阀，排出的液体需排放至密闭系统。易燃气体管道仅在开停工时使用的放净，可只设一道阀门并加丝堵、管帽或法兰盖。

G.5.1.11 管道放空或放净上的阀门需靠近主管，对易自聚、易冻结、易凝固或含固体介质的管道上的放净需垂直排放。

G.5.1.12 振动管道上公称直径小于或等于 40 mm 的放空、放净根部接口处需采取加强措施。

## G.5.2 泄压排放和火炬系统设计

G.5.2.1 直接向大气排放的非易燃气体放空管的高度设置原则如下：

a）设备或管道上的放空管口高出临近操作平台 2.2 m 以上；

b) 紧靠建筑物、构筑物或其内部布置的设备或管道的放空口，需高出建筑物或构筑物顶 2.2 m 以上。

G.5.2.2 易燃性气体排放管道的设计原则满足 SH 3009—2013 中 7.2。

G.5.2.3 受工艺条件或介质特性所限,无法排入火炬或装置处理系统的易燃气体,当通过排气筒、放空管直接向大气排放时,排气筒、放空管的高度设置原则如下:

a）连续排放的排气筒顶或放空管口需高出20 m范围内的平台或建筑物顶3.5 m以上，位于排放口水平20 m以外斜上45°的范围内不布置平台或建筑物；

b）间歇排放的排气筒顶或放空管口需高出 10 m 范围内的平台或建筑物顶 3.5 m 以上，位于排放口水平 10 m 以外斜上 $45^{\circ}$ 的范围内不布置平台或建筑物；

c) 安全阀排放管口不朝向邻近设备或有人通过的地方, 排放管口需高出 8 m 范围内的平台或建筑物顶 3 m 以上。

G.5.2.4 有毒气体放空口的位置设置原则满足 GB/T 3840 中的相关条款。

G.5.2.5 设备和管道上易燃气体安全泄压装置允许向大气排放时,其排放管口设置原则如下:

a）排放管口不朝向临近设备或有人通过的地区；

b) 排放管口的高度需高出以安全泄压装置为中心, 半径为 8 m 的范围内的操作平台或建筑物顶 3 m 以上。

G.5.2.6 安全泄压装置出口管道的布置,需考虑由于泄压排放引起的反作用力,并合理设置支架。

G.5.2.7 排入火炬的易燃气体不携带易燃液体。火炬的辐射热不可影响人身及设备的安全。距火炬筒 30 m 范围内，不设置易燃气体放空。

G.5.2.8 易燃气体放空管道内的凝结液需密闭回收,不随地排放。

G.5.2.9 将混合后可能发生化学反应，并形成爆炸性混合物的几种气体不混合排放。

G.5.2.10 火炬排放总管的热补偿需采用自然补偿，如因工艺和空间条件的限制，全厂火炬总管公称直径大于或等于 DN400 时，可采用金属波纹膨胀节进行热补偿，且在管道的适当位置需采取轴向限位和导向措施。

G.5.2.11 排放管道凝结液的凝固点等于或高于该地区最冷月平均温度时，需有防止凝结液在波纹膨胀节处聚集的措施。

G.5.2.12 金属波纹膨胀节的补偿量至少是热补偿管段的全温度范围位移量的 1.15 倍。

## G.6 埋地管道的设计原则

G.6.1 一般规定

G.6.1.1 本章节指工厂界区内埋地管道布置的设计原则。埋地管道分为直埋敷设和管沟敷设。

G.6.1.2 工厂界区内埋地敷设的管道对人员和设备存在潜在的危险和不安全因素，埋地管道布置需妥善解决防冻、防凝结、吹扫、排液、防外腐蚀及承受外荷载等问题，并遵守有关国家及当地的规定。

G.6.1.3 管道只有在不可能在地上架空敷设时,才采用埋地敷设,并满足下列要求:

a）输送介质无腐蚀性、无毒和无爆炸危险的液体、气体管道可直埋敷设；

b）无法在地上架空敷设，而又无法直埋敷设的管道可在管沟内敷设；

c) 因工艺要求无法架空的易燃介质、有毒介质、有腐蚀性介质的管道，需要埋地敷设时，需采取防止腐蚀、泄漏监测报警、泄漏介质的收集等的安全保护措施；

d) 除特殊需要外，急性毒性类别1和类别2介质管道需架空敷设；当工艺要求埋地敷设时，需有监测泄漏、防止腐蚀、收集有害流体等的安全措施。

## G.6.2 埋地管道设计原则

埋地管道的设计原则如下：

a）埋地管道的走向、敷设，埋地管道与连接系统的相互影响；

b）材料、施工规范和质量控制；

c) 运行程序和控制；

d) 防腐蚀；

e) 外部影响的减轻及管道的防护。

## G.6.3 埋地管道的走向规划

所有埋地管道的走向需进行详细规划，并经建设单位(使用单位)确定同意。在规划图纸中包括：

a）埋地管道的走向、定位尺寸及埋设标高；

b）埋地部分的其他设施，如电缆沟等，也包括将来计划实施的埋地设施；

c）划定埋地管道建设区域内地上部分所有道路及其他地上设施。

## G.6.4 直埋管道的设计要求

G.6.4.1 工厂界区内直埋管道的埋设深度需根据最大冻土深度、地下水位和管道不受损坏等原则确定，管道埋设深度如下：

a）无混凝土铺砌的区域，管道的管顶距地面不小于0.5 m；

b) 室内或室外有混凝土铺砌的区域,管道的管顶距地面不小于 0.3 m;

c) 机械车辆的通行区域,管道的管顶距地面不小于 0.7 m;

d) 易燃、有毒等介质管道埋设深度按有关规范执行。

G.6.4.2 直埋管道的外护套管(简称“套管”)设置原则如下:

a）直埋管道穿越车行道路时，需加设套管；套管顶面到路面不小于0.3 m；

b) 穿越厂区铁路的管道需设套管,套管顶面至铁轨底的距离不小于 1.2 m;

c）输送易燃介质的直埋管道不穿越埋地敷设的电缆沟，否则需设套管，当管道介质温度超过60℃时，在套管内需充填隔热材料，使套管外壁温度不超过60℃；

d) 套管需具备一定的刚度,能承受所有外表面的荷载;

e) 带有套管的直埋管道,布置时需有足够的柔性,使内管有热胀冷缩的余地;

f) 套管与输送管道最小净距为 100 mm，套管两端需进行密封，防止水及其他外来物的侵入。

G.6.4.3 大直径薄壁管道深埋时,需满足在土壤压力下的稳定性及刚度要求。

G.6.4.4 管道埋深需在冰冻线以下。当无法实现时，要有可靠的防冻措施。

## G.6.5 管沟内管道布置

G.6.5.1 无法架空而又无法直埋敷设的管道可在不通行管沟内布置。不通行管沟分为全封闭式管沟和敞开式管沟。

G.6.5.2 全封闭式管沟适用于不需经常检查和检修的管道，敞开式管沟适用于需要经常检查和检修的管道，在无可靠的通风条件及无安全措施时，不可在通行管沟内布置窒息性及易燃介质管道，其设置原则如下：

a）易燃介质的管道不布置在全封闭式管沟内，若布置在管沟内，需采取防止易燃介质在管沟内积聚的措施，并在进出装置及厂房处设密封隔断；

b) 在敞开式管沟内,不敷设密度比环境空气大的易燃气体管道,当不可避免时,需在管沟内填满细砂,并定期检查管道使用情况。

G.6.5.3 距散发比空气重的易燃气体设备 30 m 以内的管沟，需采取防止易燃气体窜入和积聚的措施。

G.6.5.4 埋地管道布置设计需考虑管道内介质能全部排净，管道需有一定的坡度，并在低点及高点设置放净及放空。

## G.6.6 埋地管道标记及记录

G.6.6.1 竣工后的埋地管道采用建设单位(使用单位)认可的方法进行地上识别标记。标记内容一般包括介质名称、公称直径、建设单位(使用单位)名称、日期等。

G.6.6.2 埋地管道在管道安装工程竣工后，向建设单位(使用单位)提交安装质量文件及埋地管道安装竣工图，图纸上要正确表示出管道的走向、坐标、标高等。

## G.6.7 直埋管道防腐蚀及阴极保护

G.6.7.1 外表面防腐蚀处理原则如下：

a）为了避免土壤中水和地下污染物对直埋管道的外表面腐蚀，外表面需进行防腐绝缘层处理；

b) 外表面绝缘防腐蚀等级需根据土壤的腐蚀性程度确定。直埋管道穿越道路、铁路以及改变埋设深度时的弯管处，防腐蚀等级为特加强级。

G.6.7.2 直埋管道的阴极保护原则如下：

a）长距离直埋钢质管道除采用绝缘涂层保护外，一般需同时采用阴极保护来降低管道涂层薄弱处产生局部腐蚀的风险；

b) 依据土壤不同的腐蚀环境条件,被保护直埋管道具体状况和技术要求,一般由阴极保护系统设计制造商确定选择牺牲阳极保护或强制电流阴极保护方式;

c) 在工厂较为复杂的地下环境,为防止地下直流杂散电流的腐蚀,可采用排流保护法,使管道上的杂散电流不经土壤而经过导线单向地流向电源负极,从而保护管道表面不受腐蚀;

d) 直埋管道采用绝缘法兰、螺栓、垫片和地上管道绝缘隔断。当局部采用钢套管时，套管间设绝缘支撑进行电绝缘，套管两端采用牢固的非导电材料密封。

## G.7 地上管道的防腐要求

## G.7.1 一般规定

对于地上管道，除奥氏体不锈钢、镀锌、塑料管道外，均需通过喷涂防腐涂料进行防腐。

## G.7.2 防腐涂料的选用

防腐涂料的选用原则如下：

a）与被涂物的使用条件相适应；

b) 与被涂物表面的材质相适应；

c) 底漆与面漆正确配套；

d) 经济合理；

e) 具备施工条件。

## G.8 管道的隔热要求

## G.8.1 一般原则

下列情况下需对管道进行保温：

a）管道外表面温度高于 $50^{\circ}C$ ，为减少管道在操作中的热量损失；

b）工艺生产有要求，以避免、限制或延迟管道内介质的凝固、冻结，维持正常生产；

c) 寒冷或严寒地区,为了减少管道内介质的冻结而带来的不利影响;

d) 表面温度等于或高于 $60^{\circ}$ C 的不保温管道，需要经常维护又无法采用其他措施防止烫伤的部位，需设防烫保温。

## G.8.2 管道的保温

下列管道需采用伴管或夹套管保温伴热：

a）需从外部补偿管内介质热损失，以维持被输送介质温度的管道；

b）在输送过程中，由于热损失而产生凝液，并可能导致腐蚀或影响正常操作的气体管道；

c) 在操作过程中,由于介质压力突然下降而自冷,可能冻结导致堵塞的管道;

d) 在切换操作或停运期间，管内介质由于热损失造成温度下降，介质不能放净、吹扫而可能凝固的管道；

e）在输送过程中，由于热损失可能引起管内介质析出结晶的管道；

f) 由于热损失可能导致输送介质黏度增高,系统阻力增加,输送量下降,达不到工艺最小允许量的管道;

g）输送介质的凝固点等于或高于环境温度的管道。

## G.8.3 管道的保冷

下列情况下需对管道进行保冷：

a) 需减少冷介质在生产或输送过程中的温升或气化(包括突然减压而气化产生结冰);

b) 需减少冷介质在生产或输送过程中的冷量损失,或规定允许冷损失量;

c) 需防止在环境温度下,管道外表面凝露。

## G.9 管道静电接地要求

G.9.1 对爆炸、火灾危险场所内可能产生静电危险的设备和管道，均需采取静电接地措施。

G.9.2 在聚烯烃树脂处理系统、输送系统和料仓区需设置静电接地系统，不可出现不接地的孤立导体。

G.9.3 易燃气体、易燃液体、易燃固体的管道需设静电接地。接地连接点设置原则如下：

a) 装置区中各个相对独立的建(构)筑物内的管道,可通过与工艺设备金属外壳的连接,进行静电接地;

b）管道泵及泵入口永久过滤器、缓冲器等处设置接地连接点；

c) 易燃液体、液化烃的装卸栈台和码头的管道设置接地连接点；

d) 管网在进出装置区处、不同爆炸危险环境的边界、管道分岔处的管道需进行接地，对于长距离的无分支管道，需在始端、末端以及每隔 $100\mathrm{m}$ 与接地体可靠连接；

e) 平行管道净距小于 $100 \, mm$ 时，需每隔 $20 \, m$ 加跨接线；当管道交叉且净距小于 $100 \, mm$ 时，需加跨接线；

f) 当工艺管道与伴热管之间有隔离块时(防止局部过热和接触腐蚀)，伴热管利用金属丝捆扎连接外，尚需使伴热管进汽口及回水口与工艺管道等电位连接，见图 G.1。

![](images/c88d3c620384ee302619dea2f7da6c6be75a0ffd7271ffcc3c26e574d0bfe07d.jpg)  
图G.1 工艺管道与伴热管之间有隔热垫的伴管结构示意图

g）对金属管道中间的非导体管段(如聚氯乙烯管)，除需做屏蔽保护外，两端的金属管需分别与接地干线相连，或用 $6 \, mm^{2}$ 多股铜芯绝缘电线跨接后接地；

h）非导体管段上的金属件需接地。

G.9.4 除非另有规定,当金属法兰采用金属的螺栓或卡子紧固时,一般可不必另装静电连接线,但需保证至少有两个螺栓或卡子间具有良好的导电接触面。

G.9.5 每组专设的静电接地体,其对地电阻值,一般情况小于 $100 \Omega$ 。在山区等土壤电阻率较高的场所,其对地电阻值也不大于 $1000 \Omega$ 。

G.9.6 管道静电接地的设计,尚需满足项目的特殊要求及现行有关标准规范的相关条款。

## 附录 H

(资料性)

## 国际通用石油化工阀门标准

表 H.1 所示为常用工业阀门标准与国际通用石油化工阀门标准对照表。表中左列或右列用“—”表示者，其相对的产品标准为各自依据相应通用标准(ASME B16.34, GB/T 12224)制定的阀门标准，无直接对应关系。

表 H.1 常用工业阀门标准与国际通用石油化工阀门标准对照表

<table><tr><td>国内阀门标准</td><td>国外阀门标准</td></tr><tr><td colspan="2">阀门通用标准 基本参数类标准</td></tr><tr><td>GB/T 12224</td><td>ASME B16.34</td></tr><tr><td colspan="2">常用闸阀产品标准</td></tr><tr><td>GB/T 12224</td><td>ASME B16.34</td></tr><tr><td>GB/T 12234</td><td>API 600</td></tr><tr><td>GB/T 12224</td><td>API 603</td></tr><tr><td>GB/T 19672</td><td rowspan="2">API 6D</td></tr><tr><td>GB/T 20173</td></tr><tr><td>GB/T 8464</td><td>—</td></tr><tr><td>GB/T 12232</td><td>—</td></tr><tr><td>GB/T 24924</td><td>AWWA C209</td></tr><tr><td>JB/T 8691</td><td>—</td></tr><tr><td>JB/T 10673</td><td>—</td></tr><tr><td colspan="2">常用截止阀、截止止回阀、升降式止回阀产品标准</td></tr><tr><td>GB/T 12224</td><td>ASME B16.34</td></tr><tr><td rowspan="2">GB/T 12235</td><td>API 600</td></tr><tr><td>BS 1873</td></tr><tr><td>GB/T 12233</td><td>—</td></tr><tr><td colspan="2">常用旋启式止回阀、对夹式止回阀、轴流式止回阀产品标准</td></tr><tr><td>GB/T 12224</td><td>ASME B16.34</td></tr><tr><td rowspan="2">GB/T 12236</td><td>API 600</td></tr><tr><td>BS 1868</td></tr><tr><td>GB/T 13932</td><td>—</td></tr><tr><td>GB/T 12236</td><td rowspan="2">API 594</td></tr><tr><td>JB/T 8937</td></tr><tr><td>GB/T 21387</td><td>—</td></tr><tr><td colspan="2">常用球阀产品标准</td></tr><tr><td rowspan="2">GB/T 12237</td><td>API 608</td></tr><tr><td>BS 5351</td></tr><tr><td>GB/T 19672</td><td>API 6D</td></tr><tr><td>GB/T 21385</td><td>—</td></tr><tr><td>GB/T 26146</td><td>—</td></tr><tr><td colspan="2">常用蝶阀产品标准</td></tr><tr><td>—</td><td>API 609</td></tr><tr><td>GB/T 12238</td><td>AWWA C504</td></tr><tr><td>GB/T 26144</td><td>—</td></tr><tr><td>JB/T 8527</td><td>—</td></tr><tr><td colspan="2">常用旋塞阀产品标准</td></tr><tr><td>GB/T 12240</td><td>API 593</td></tr><tr><td>GB/T 22130</td><td>API 599</td></tr><tr><td>JB/T 11152</td><td>—</td></tr><tr><td colspan="2">常用低温阀产品标准</td></tr><tr><td>GB/T 24925</td><td>BS 6364</td></tr><tr><td colspan="2">常用小口径、螺纹、承插端阀门产品标准</td></tr><tr><td>GB/T 28776</td><td rowspan="2">API 602</td></tr><tr><td>JB/T 7746</td></tr><tr><td>GB/T 8464</td><td>—</td></tr><tr><td colspan="2">常用阀门检验、试验标准</td></tr><tr><td>GB/T 13927</td><td>ISO 5208</td></tr><tr><td rowspan="2">GB/T 26479</td><td>API 607</td></tr><tr><td>ISO 10497</td></tr><tr><td>GB/T 26480</td><td>API 598</td></tr><tr><td>—</td><td>ASME B16.104(FCI70-2-98)</td></tr><tr><td>—</td><td>API 6FA</td></tr><tr><td>—</td><td>API 6FB</td></tr><tr><td>SY/T 6746</td><td>API 6FC</td></tr><tr><td>GB/T 26482</td><td>API 6FD</td></tr><tr><td>—</td><td>ISO 15848-1</td></tr><tr><td>GB/T 26481</td><td>ISO 15848-2</td></tr><tr><td>—</td><td>API 622</td></tr><tr><td>—</td><td>API 624</td></tr><tr><td>—</td><td>API 641</td></tr><tr><td colspan="2">常用阀门材料检验、试验标准</td></tr><tr><td>JB/T 7927</td><td>MSS SP55</td></tr><tr><td>JB/T 6440</td><td>MSS SP54(ASME B16.34附录I)</td></tr><tr><td>JB/T 6439</td><td>ASTM E709(ASME B16.34附录II)</td></tr><tr><td>JB/T 6902</td><td>ASTM E165(ASME B16.34附录III)</td></tr><tr><td>JB/T 6903</td><td>ASTM A388, ASTM A609(ASME B16.34附录IV)</td></tr><tr><td>GB/T 20972.1~GB/T 20972.3</td><td>NACE MR0175</td></tr><tr><td colspan="2">注:“—”表示暂无适用标准。</td></tr></table>

## 附录 I

(资料性)

## 低泄漏阀门阀杆型式试验及产品检验

本附录表 I.1 列出了低泄漏阀杆型式试验及产品检验技术参数, 用户单位或设计单位可参照表 I.2 提出低泄漏阀门的阀杆密封通用技术方法。

表 I.1 低泄漏阀杆型式试验及产品检验技术参数一览表

<table><tr><td rowspan="2">阀门类别</td><td colspan="4">低泄漏阀杆型式试验(GB/T 40079)</td><td rowspan="2">低泄漏阀门产品检验(GB/T 26481)</td></tr><tr><td>试验气体及检漏方法</td><td>密封等级及泄漏率</td><td>试验压力</td><td>试验条件(机械循环/温度循环次数,温度循环等级)</td></tr><tr><td rowspan="6">切断阀</td><td rowspan="3">氦He真空压力法或正压累积法(定量)</td><td>AH, $10^{-5}$ [mg/(s·m)],真空压力法</td><td rowspan="12">阀门公称压力及相应温度的压力额定值</td><td rowspan="6">CO1,机械循环205次/温度循环2次;CO2,机械循环1500次/温度循环3次;CO3,机械循环2500次/温度循环4次;温度循环可选择下列5个等级:常温( $-29°C~+40°C$ );常温~ $+200°C$ ;常温~ $+400°C$ ;常温~ $-196°C$ ;常温~ $-46°C$ </td><td rowspan="12">试验压力:0.6MPa;试验气体:氦气;检漏方法:吸气法;常温,机械循环5次;密封等级及泄漏率:A级: $\leqslant 50\times 10^{-6}$ ;B级: $\leqslant 100\times 10^{-6}$ ;C级: $\leqslant 200\times 10^{-6}$ </td></tr><tr><td>BH, $10^{-4}$ [mg/(s·m)],真空压力法或正压累积法</td></tr><tr><td>CH, $10^{-2}$ [mg/(s·m)],真空压力法或正压累积法</td></tr><tr><td rowspan="3">甲烷CH4吸气法(半定量)</td><td>AM, $\leqslant 50\times 10^{-6}$ </td></tr><tr><td>BM, $\leqslant 100\times 10^{-6}$ </td></tr><tr><td>CM, $\leqslant 500\times 10^{-6}$ </td></tr><tr><td rowspan="6">调节阀</td><td rowspan="3">氦He真空压力法或正压累积法(定量)</td><td>AH, $10^{-5}$ [mg/(s·m)],真空压力法</td><td rowspan="6">CC1,机械循环20000次/温度循环2次;CC2,机械循环60000次/温度循环3次;CC3,机械循环100000次/温度循环4次;温度循环可选择下列5个等级:常温( $-29°C~+40°C$ );常温~ $+200°C$ ;常温~ $+400°C$ ;常温~ $-196°C$ ;常温~ $-46°C$ </td></tr><tr><td>BH, $10^{-4}$ [mg/(s·m)],真空压力法或正压累积法</td></tr><tr><td>CH, $10^{-2}$ [mg/(s·m)],真空压力法或正压累积法</td></tr><tr><td rowspan="3">甲烷CH4吸气法(半定量)</td><td>AM, $\leqslant 50\times 10^{-5}$ </td></tr><tr><td>BM, $\leqslant 100\times 10^{-6}$ </td></tr><tr><td>CM, $\leqslant 500\times 10^{-6}$ </td></tr></table>

表 I.2 低泄漏阀门阀杆密封通用技术方法

<table><tr><td>阀门类别</td><td>阀杆密封类别</td><td>低泄漏阀杆型式试验(GB/T 40079)</td><td>低泄漏阀门产品检验(GB/T 26481)</td></tr><tr><td rowspan="3">切断阀</td><td>填料,升杆</td><td>CO1-CM,或CH</td><td>C级</td></tr><tr><td>填料,1/4旋转</td><td>CO1-BM,或BH</td><td>B级</td></tr><tr><td>波纹管</td><td>CO1-AM,或AH</td><td>A级</td></tr><tr><td rowspan="3">调节阀</td><td>填料,升杆</td><td>CC1-CM,或CH</td><td>C级</td></tr><tr><td>填料,1/4旋转</td><td>CC1-BM,或BH</td><td>B级</td></tr><tr><td>波纹管</td><td>CC1-AM,或AH</td><td>A级</td></tr><tr><td colspan="4">注1:试验气体采用氦气与甲烷,两者无对比换算关系,检漏方法采用真空压力法或正压累积法(定量)与吸气法(半定量),两者也无对比换算关系。前者为稀有气体、定量检漏、灵敏度高,但与工作介质及环保法规无直接对应关系;后者为可燃气体,与工作介质及环保法规对应度较好,但对检验测试机构的安全防护要求较高,一般不用于产品检测要求。注2:表I.2所列为低泄漏阀杆型式试验通用技术方法,用户可根据实际用途选择低泄漏阀杆型式试验的试验条件,包括机械循环/温度循环次数,温度循环等级。通用的温度循环等级为常温~200°C或常温~260°C。</td></tr></table>

## 附录 J

(资料性)

## 标准带颈对焊法兰考虑外加轴向力和弯矩时允许超压值

Class 系列标准的带颈对焊法兰,允许超出法兰压力-温度额定值的外加轴向力和外加弯矩需满足公式(J.1)的要求。

$$
P _ {\mathrm{D}} + \frac {1 6 M _ {\mathrm{E}} + 4 F _ {\mathrm{E}} G}{\pi G ^ {3}} \leqslant (1 + F _ {\mathrm{M}}) P _ {\mathrm{R}}\tag{……( J.1}
$$

式中：

$F_{E}$ ——外加轴向力,单位为牛顿(N);

$F_{M}$ ——外加弯矩系数,详见表 J.1;

G ——垫片反力荷载作用处的直径,当垫片基本密封宽度小于或等于6 mm时,G取垫片密封面的平均值;当垫片基本密封宽度大于6 mm时,G取垫片接触面的外径减去2倍的垫片有效密封宽度或连接接触面密封宽度,单位为毫米(mm);

$M_{E}$ ——外加弯矩,单位为牛顿毫米(N·mm);

$P_{D}$ ——设计压力,单位为兆帕(MPa);

$P_{R}$ ——设计温度下的法兰压力等级。

表 J.1 外加弯矩系数 $F_{\mathrm{M}}$

<table><tr><td rowspan="2">公称尺寸DN</td><td colspan="6">法兰标准和压力等级</td></tr><tr><td>HG/T 20615Class 150</td><td>HG/T 20615Class 300</td><td>HG/T 20615Class 600</td><td>HG/T 20615Class 900</td><td>HG/T 20615Class 1 500</td><td>HG/T 20615Class 2 500</td></tr><tr><td>15</td><td>23</td><td>11.5</td><td>5.7</td><td>7.1</td><td>4.2</td><td>2.5</td></tr><tr><td>20</td><td>15.3</td><td>9.1</td><td>4.4</td><td>4.3</td><td>2.5</td><td>1.5</td></tr><tr><td>25</td><td>13.9</td><td>7.8</td><td>3.7</td><td>3.9</td><td>2.3</td><td>1.4</td></tr><tr><td>40</td><td>5.5</td><td>5.1</td><td>2.4</td><td>2.7</td><td>1.5</td><td>1</td></tr><tr><td>50</td><td>5.6</td><td>4.3</td><td>2.1</td><td>2.7</td><td>1.6</td><td>1</td></tr><tr><td>65</td><td>4</td><td>3.8</td><td>1.8</td><td>2.4</td><td>0.73</td><td>0.98</td></tr><tr><td>80</td><td>2.5</td><td>3</td><td>1.4</td><td>1.4</td><td>1</td><td>0.75</td></tr><tr><td>100</td><td>3.3</td><td>1.8</td><td>1.3</td><td>1.3</td><td>0.84</td><td>0.66</td></tr><tr><td>125</td><td>3.4</td><td>1.1</td><td>1.1</td><td>1.1</td><td>0.75</td><td>0.64</td></tr><tr><td>150</td><td>2.3</td><td>1.2</td><td>1.2</td><td>1</td><td>0.66</td><td>0.59</td></tr><tr><td>200</td><td>1.2</td><td>0.94</td><td>0.85</td><td>0.8</td><td>0.54</td><td>0.57</td></tr><tr><td>250</td><td>1.9</td><td>1.2</td><td>1</td><td>0.59</td><td>0.47</td><td>0.64</td></tr><tr><td>300</td><td>1.2</td><td>1.1</td><td>0.84</td><td>0.61</td><td>0.53</td><td>0.5</td></tr><tr><td>350</td><td>1.4</td><td>1.2</td><td>0.9</td><td>0.54</td><td>0.6</td><td>—</td></tr><tr><td>400</td><td>1.4</td><td>1.1</td><td>0.79</td><td>0.41</td><td>0.52</td><td>—</td></tr><tr><td>450</td><td>1.4</td><td>0.98</td><td>0.66</td><td>0.46</td><td>0.44</td><td>—</td></tr><tr><td>500</td><td>1.5</td><td>0.72</td><td>0.65</td><td>0.32</td><td>0.42</td><td>—</td></tr><tr><td>600</td><td>1.3</td><td>0.78</td><td>0.51</td><td>0.37</td><td>0.38</td><td>—</td></tr><tr><td>650</td><td>0.9</td><td>0.5</td><td>0.33</td><td>0.34</td><td>—</td><td>—</td></tr><tr><td>700</td><td>0.85</td><td>0.42</td><td>0.28</td><td>0.38</td><td>—</td><td>—</td></tr><tr><td>750</td><td>0.74</td><td>0.43</td><td>0.22</td><td>0.26</td><td>—</td><td>—</td></tr><tr><td>800</td><td>1.1</td><td>0.44</td><td>0.21</td><td>0.29</td><td>—</td><td>—</td></tr><tr><td>850</td><td>1.1</td><td>0.49</td><td>0.25</td><td>0.32</td><td>—</td><td>—</td></tr><tr><td>900</td><td>0.9</td><td>0.5</td><td>0.22</td><td>0.23</td><td>—</td><td>—</td></tr><tr><td>950</td><td>0.76</td><td>0.25</td><td>0.2</td><td>0.21</td><td>—</td><td>—</td></tr><tr><td>1 000</td><td>0.79</td><td>0.29</td><td>0.22</td><td>0.16</td><td>—</td><td>—</td></tr><tr><td>1 050</td><td>0.72</td><td>0.22</td><td>0.2</td><td>0.2</td><td>—</td><td>—</td></tr><tr><td>1 100</td><td>0.66</td><td>0.24</td><td>0.23</td><td>0.13</td><td>—</td><td>—</td></tr><tr><td>1 150</td><td>0.62</td><td>0.21</td><td>0.17</td><td>0.15</td><td>—</td><td>—</td></tr><tr><td>1 200</td><td>0.64</td><td>0.23</td><td>0.15</td><td>0.1</td><td>—</td><td>—</td></tr><tr><td>1 250</td><td>0.92</td><td>0.25</td><td>0.14</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 300</td><td>0.82</td><td>0.2</td><td>0.18</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 350</td><td>0.72</td><td>0.22</td><td>0.13</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 400</td><td>0.75</td><td>0.17</td><td>0.2</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 450</td><td>0.66</td><td>0.18</td><td>0.14</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 500</td><td>0.68</td><td>0.16</td><td>0.11</td><td>—</td><td>—</td><td>—</td></tr><tr><td rowspan="2">公称尺寸DN</td><td colspan="6">法兰标准和压力等级</td></tr><tr><td>HG/T 20623BClass 150</td><td>HG/T 20623BClass 300</td><td>HG/T 20623BClass 600</td><td>HG/T 20623BClass 900</td><td>HG/T 20623BClass 1 500</td><td>HG/T 20623BClass 2 500</td></tr><tr><td>650</td><td>0.47</td><td>0.55</td><td>0.16</td><td>0.14</td><td>—</td><td>—</td></tr><tr><td>700</td><td>0.44</td><td>0.53</td><td>0.2</td><td>0.18</td><td>—</td><td>—</td></tr><tr><td>750</td><td>0.35</td><td>0.57</td><td>0.15</td><td>0.22</td><td>—</td><td>—</td></tr><tr><td>800</td><td>0.37</td><td>0.55</td><td>0.16</td><td>0.13</td><td>—</td><td>—</td></tr><tr><td>850</td><td>0.36</td><td>0.46</td><td>0.14</td><td>0.16</td><td>—</td><td>—</td></tr><tr><td>900</td><td>0.36</td><td>0.43</td><td>0.18</td><td>0.15</td><td>—</td><td>—</td></tr><tr><td>950</td><td>0.42</td><td>0.29</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 000</td><td>0.41</td><td>0.25</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 050</td><td>0.41</td><td>0.22</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 100</td><td>0.39</td><td>0.2</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 150</td><td>0.29</td><td>0.16</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 200</td><td>0.3</td><td>0.27</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 250</td><td>0.3</td><td>0.11</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 300</td><td>0.28</td><td>0.11</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 350</td><td>0.21</td><td>0.25</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 400</td><td>0.23</td><td>0.12</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 450</td><td>0.12</td><td>0.09</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>1 500</td><td>0.13</td><td>0.03</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td colspan="7">如果外加荷载为持久荷载,且工作温度高于垫片的松弛温度(一般金属温度在230°C以上),设计者应考虑降低 $F_{M}$ 允许值</td></tr><tr><td colspan="7">注:“—”表示暂无适用数据。</td></tr></table>

## 附录 K

(资料性)

## 支管直接焊于主管的补强计算示例

下面给出了支管直接焊于主管的补强计算示例。

示例 1：在真空下操作的某管道，外径 $D=508\ mm$ ，壁厚 $T=6.3\ mm$ ，两连接法兰之间的距离 $L=15\ 000\ mm$ ，材料为 20 号无缝钢管，取腐蚀裕量 $C_{2}=1\ mm$ ，在常温下操作。试问所选壁厚是否合适？

解: 因 $L/D=\frac{15\ 000}{508}=29.5, D/T_{e}=\frac{508}{6.3-1}=95.8$ ，故可由公式(2)直接计算许用外压：

$$
[ P ] = \frac {2 . 2}{3} E \left(\frac {T _ {\mathrm{e}}}{D}\right) ^ {3} = \frac {2 . 2}{3} \times 2. 0 3 \times 1 0 ^ {5} \left(\frac {6 . 3 - 1}{5 0 8}\right) ^ {3} = 0. 1 6 9 (\mathrm{MPa})
$$

其中，由表 C.2 查得， $t=20\ ^{\circ}C$ 时 $E=2.03\times10^{5}\ MPa$ 。

故所选壁厚合适。

示例 2：在真空下操作的某管道，从连接法兰到异径管连接线的大端直管外径为 $D=508\ mm$ ，壁厚 $T=6.3\ mm$ ，大端直管长 $6\ 000\ mm$ ；从异径管小端连接线到小端直管连接法兰的长度为 $6\ 000\ mm$ ，小端直管外径 $D=324\ mm$ ，壁厚 $T=4\ mm$ ，与大、小直管焊接相连的异径管壁厚 $T=6.3\ mm$ ，异径管的轴向长度为 $508\ mm$ ，直管材料都为 20 号无缝钢管，异径管系由 Q235-B 钢板卷制，取腐蚀裕量 $C_{2}=1\ mm$ ，在常温下操作。试问大端直管、小端直管、异径管的所选壁厚是否合适？

解: 据 6.6.1.1、6.6.1.3, 包括异径管在内的真空管道计算长度:

$$
L = 6 0 0 0 + 5 0 8 + 6 0 0 0 = 1 2 5 0 8 (\mathrm{mm})
$$

对于大端直管， $L / D = \frac{12508}{508} = 24.6, D / T_{\mathrm{e}} = \frac{508}{6.3 - 1} = 95.8$

对于小端直管， $L/D=\frac{12\ 508}{324}=38.6$ ， $D/T_{e}=\frac{324}{4-1}=108$

对于大端直管，据 GB/T 150.3—2024 中图 6-2，可由 L/D=24.6, $D/T_{e}=95.8$ 得 A=0.00012，并据表 C.2, $t=20^{\circ}C$ 时得 $E=2.03\times10^{5}MPa$ ，因此，大端直管的许用外压：

$$
[ P ] = \frac {2 A E}{3 (D / T _ {\mathrm{e}})} = \frac {2 \times 0 . 0 0 0 1 2 \times 2 . 0 3 \times 1 0 ^ {5}}{3 \times 9 5 . 8} = 0. 1 6 9 (\mathrm{MPa})
$$

对于小端直管，和大端直管相同，可由 $L/D=38.6, D/T_{e}=108$ 得 A=0.00010，并由 $E=2.03\times10^{5}$ MPa，故小端直管的许用外压：

$$
[ P ] = \frac {2 A E}{3 (D / T _ {\mathrm{e}})} = \frac {2 \times 0 . 0 0 0 1 0 \times 2 . 0 3 \times 1 0 ^ {5}}{3 \times 1 0 8} = 0. 1 2 5 (\mathrm{MPa})
$$

因异径管等于大端直管厚度,故可得和大端直管相同的许用外压。

由上计算可知，大端、小端直管以及异径管在所选厚度时都能满足所受真空要求。

示例 3：外径 $D_{h}=219\ mm$ 、壁厚 $\overline{T}_{h}=8\ mm$ 的油品主管上有一垂直支管，支管外径 $D_{b}=114\ mm$ ，壁厚 $\overline{T}_{b}=6.3\ mm$ ，主管和支管材料都是 15CrMo 无缝钢管，见图 K.1，设计压力 P=2 MPa，设计温度 $t=200\ ^{\circ}C$ ，接管处填角焊缝符合 7.4.8 和图 23 a) 规定的最小尺寸要求，取腐蚀裕量 $C_{2}=2.5\ mm$ 。试问该管件是否需要另加补强？

![](images/b17b012c548835139b748a56d7bd3192d6d33e5d7f62438aa12680337e8bdd25.jpg)  
图K.1 例3的附图

解:由表 B.1, S=120 MPa; 由表 B.3, $\Phi=1.0$

$$
T _ {\mathrm{h}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{h}} = 0. 8 7 5 \times 8 = 7 (\mathrm{mm})
$$

$$
T _ {\mathrm{b}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{b}} = 0. 8 7 5 \times 6. 3 = 5. 5 (\mathrm{mm})
$$

$$
t _ {\mathrm{h}} = \frac {P D _ {\mathrm{h}}}{2 (S \phi + P Y)} = \frac {2 \times 2 1 9}{2 \times (1 2 0 \times 1 . 0 + 2 \times 0 . 4)} = 1. 8 1 (\mathrm{mm})
$$

$$
t _ {\mathrm{b}} = \frac {P D _ {\mathrm{b}}}{2 (S \phi + P Y)} = \frac {2 \times 1 1 4}{2 \times (1 2 0 \times 1 . 0 + 2 \times 0 . 4)} = 0. 9 4 (\mathrm{mm})
$$

$t_{h}$ 、 $t_{b}$ 式中的Y值据表27，Y=0.4。

由 6.6.6.1:

$$
d _ {1} = \left(D _ {\mathrm{b}} - 2 T _ {\mathrm{eb}}\right) / \sin \beta = [ 1 1 4 - 2 (5. 5 - 2. 5) ] / \sin 9 0 ^ {\circ} = 1 0 8 (\mathrm{mm})
$$

$d_{2}$ 取下列两式中的较大值：

$$
d _ {2} = d _ {1} = 1 0 8 (\mathrm{mm})
$$

$$
d _ {2} = T _ {\mathrm{eb}} + T _ {\mathrm{eh}} + \frac {d _ {1}}{2} = (5. 5 - 2. 5) + (7 - 2. 5) + \frac {1 0 8}{2} = 6 1. 5 (\mathrm{mm})
$$

$$
d _ {2} = 1 0 8 (\mathrm{mm}),
$$

$L_{4}$ 取下列两式中的较小值：

$$
L _ {4} = 2. 5 T _ {\mathrm{eb}} = 2. 5 \times (7 - 2. 5) = 1 1. 2 5 (\mathrm{mm})
$$

$$
L _ {4} = 2. 5 T _ {\mathrm{eh}} = 2. 5 \times (5. 5 - 2. 5) = 7. 5 (\mathrm{mm})
$$

由图 K.1, 焊缝厚度 $t_{c}$ 取下列两式中的较小值:

$$
t _ {\mathrm{c}} = 0. 7 T _ {\mathrm{b}} = 0. 7 \times 6. 3 = 4. 4 (\mathrm{mm})
$$

$$
t _ {\mathrm{c}} = 6. 4 (\mathrm{mm})
$$

由公式(15)，所需补强面积：

$$
A _ {1} = t _ {\mathrm{h}} d _ {1} (2 - \sin \beta) = 1. 8 1 \times 1 0 8 (2 - \sin 9 0 ^ {\circ}) = 1 9 5. 4 8 (\mathrm{mm} ^ {2})
$$

由公式(17)，主管的多余截面积：

$$
A _ {2} = (2 d _ {2} - d _ {1}) \left(T _ {\mathrm{eh}} - t _ {\mathrm{h}}\right) = (2 \times 1 0 8 - 1 0 8) \times (7 - 2. 5 - 1. 8 1) = 2 9 0. 5 2 (\mathrm{mm} ^ {2})
$$

由公式(18)，支管的多余截面积：

$$
A _ {3} = 2 L _ {4} \left(T _ {\mathrm{eb}} - t _ {\mathrm{b}}\right) / \sin \beta = 2 \times 7. 5 (5. 5 - 2. 5 - 0. 9 4) / \sin 9 0 ^ {\circ} = 3 0. 9 (\mathrm{mm} ^ {2})
$$

焊缝截面积：

$$
A _ {5} = 2 \times 0. 5 \left(\frac {t _ {\mathrm{c}}}{0 . 7 0 7}\right) ^ {2} = 2 \times 0. 5 \left(\frac {4 . 4}{0 . 7 0 7}\right) ^ {2} = 3 8. 7 3 (\mathrm{mm} ^ {2})
$$

由公式(21)，总的补强面积：

$$
A _ {2} + A _ {3} + A _ {5} = 2 9 0. 5 2 + 3 0. 9 + 3 8. 7 3 = 3 6 0. 1 5 \left(\mathrm{mm} ^ {2}\right) > 1 9 5. 4 8 \left(\mathrm{mm} ^ {2}\right) = A _ {1}
$$

因此，该接管开孔已满足补强要求，不需另加补强。

示例 4：外径 $D_{h}=324\ mm$ 、壁厚 $\overline{T}_{h}=17.5\ mm$ 的主管上有一垂直支管，支管外径 $D_{b}=219\ mm$ ，壁厚 $\overline{T}_{b}=$

12.5 mm，主管和支管材料都是 ASTM B241 6061-T6 无缝铝合金管，在连接处用从 ASTM B241 6063-T6 无缝铝管上切取的 $D_{r}=350\ mm$ 、 $T_{r}=17.5\ mm$ 的补强圈，见图 K.2。设计温度 $t=-196\ ^{\circ}C$ ，填角焊缝符合图 23 c) 的最小尺寸要求，规定取腐蚀裕量 $C_{2}=0$ 。试问该管件的最大允许设计内压为多少？

![](images/45530e81c56e6185d3b9515e8aebbe6775e10bd20f37b5b9497a32b849426ff9.jpg)  
图K.2 例4的附图

解:由表 B.1, 对于主管和支管, S=55 MPa, 对补强圈, S=55 MPa; 由表 B.3, $\Phi=1.0$ 。

$$
T _ {\mathrm{h}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{h}} = 0. 8 7 5 \times 1 7. 5 = 1 5. 3 (\mathrm{mm})
$$

$$
T _ {\mathrm{b}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{b}} = 0. 8 7 5 \times 1 2. 5 = 1 0. 9 (\mathrm{mm})
$$

$$
t _ {\mathrm{h}} = \frac {P D _ {\mathrm{h}}}{2 (S \Phi + P Y)} = \frac {3 2 4 P}{2 (5 5 \times 1 + 0 . 4 P)}
$$

$$
t _ {\mathrm{b}} = \frac {P D _ {\mathrm{b}}}{2 (S \Phi + P Y)} = \frac {2 1 9 P}{2 (5 5 \times 1 + 0 . 4 P)}
$$

$t_{h}$ 、 $t_{b}$ 式中的Y值据表27,Y=0.4。

采用符号 $q = \frac{P}{110 + 0.8P}$ ，则可得：

$$
t _ {\mathrm{h}} = 3 2 4 q
$$

$$
t _ {\mathrm{b}} = 2 1 9 q
$$

由6.6.6.1：

$$
d _ {1} = \left(D _ {\mathrm{b}} - 2 T _ {\mathrm{eb}}\right) / \sin \beta = (2 1 9 - 2 \times 1 0. 9) / \sin 9 0 ^ {\circ} = 1 9 7. 2 (\mathrm{mm})
$$

$d_{2}$ 取下列两式中的较大值：

$$
d _ {2} = d _ {1} = 1 9 7. 2 (\mathrm{mm})
$$

$$
d _ {2} = T _ {\mathrm{eb}} + T _ {\mathrm{eh}} + \frac {d _ {1}}{2} = 1 0. 9 + 1 5. 3 + \frac {1 9 7 . 2}{2} = 1 2 4. 8 (\mathrm{mm})
$$

故 $d_{2} = 197.2(\mathrm{mm})$ 。

$L_{4}$ 取下列两式中的较小值：

$$
L _ {4} = 2. 5 T _ {\mathrm{eh}} = 2. 5 \times 1 5. 3 = 3 8. 3 (\mathrm{mm})
$$

$$
L _ {4} = 2. 5 T _ {\mathrm{eb}} + T = 2. 5 \times 1 0. 9 + 1 5. 3 = 4 2. 6 (\mathrm{mm})
$$

故 $L_{4}=38.3(\mathrm{mm})$ 。

由图 K.2, 支管对主管的焊缝厚度 $t_{c}$ 取下列两式中的较小值:

$$
t _ {\mathrm{c}} = 0. 7 \overline {{{T}}} _ {\mathrm{b}} = 0. 7 \times 1 2. 5 = 8. 8 (\mathrm{mm})
$$

$$
t _ {\mathrm{c}} = 6. 4 (\mathrm{mm})
$$

故 $t_{c}=6.4(\mathrm{mm})$ 。

补强圈对主管的焊缝厚度 $t_{c}=0.5T_{r}=0.5\times17.5=8.8(mm)$ 。

由公式(15)，所需补强面积：

$$
A _ {1} = t _ {\mathrm{h}} d _ {1} (2 - \sin \beta) = 3 2 4 q \times 1 9 7. 2 (2 - \sin 9 0 ^ {\circ}) = 6 3 8 9 2. 8 q (\mathrm{mm} ^ {2})
$$

由公式(17)，主管的多余截面积：

$$
A _ {2} = \left(2 d _ {2} - d _ {1}\right) \left(T _ {\mathrm{eh}} - t _ {\mathrm{h}}\right) = 1 9 7. 2 (1 5. 3 - 3 2 4 q) = 3 0 1 7. 2 - 6 3 8 9 2. 8 q \left(\mathrm{mm} ^ {2}\right)
$$

由公式(18)，支管的多余截面积：

$$
A _ {3} = 2 L _ {4} \left(T _ {\mathrm{eb}} - t _ {\mathrm{b}}\right) / \sin \beta = 2 \times 3 8. 3 (1 0. 9 - 2 1 9 q) \sin 9 0 ^ {\circ} = 8 3 4. 9 - 1 6 7 7 5. 4 q \left(\mathrm{mm} ^ {2}\right),
$$

补强圈截面积取公式(19)、公式(20)中的较小值：

$$
A _ {4} = \left(D _ {\mathrm{r}} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) \times 0. 8 7 5 T _ {\mathrm{r}} = \left(3 5 0 - \frac {2 1 9}{\sin 9 0 ^ {\circ}}\right) \times 0. 8 7 5 \times 1 7. 5 = 2 0 0 6 (\mathrm{mm} ^ {2})
$$

$$
A _ {4} = \left(2 d _ {2} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) \times 0. 8 7 5 T _ {\mathrm{r}} = \left(2 \times 1 9 7. 2 - \frac {2 1 9}{\sin 9 0 ^ {\circ}}\right) \times 0. 8 7 5 \times 1 7. 5 = 2 6 8 6 (\mathrm{mm} ^ {2})
$$

故 $A_{4}=2\ 006\ (mm^{2})$ 。

焊缝截面积：

$$
A _ {5} = 2 \times 0. 5 \left(\frac {t _ {\mathrm{c}}}{0 . 7 0 7}\right) ^ {2} + 2 \times 0. 5 \left(\frac {t _ {\mathrm{c}}}{0 . 7 0 7}\right) ^ {2} = \left(\frac {6 . 4}{0 . 7 0 7}\right) ^ {2} + \left(\frac {8 . 8}{0 . 7 0 7}\right) ^ {2} = 2 3 6. 9 (\mathrm{mm} ^ {2})
$$

由公式(21)，由 $A_{2}+A_{3}+A_{4}+A_{5}=A_{1}$ 可得：

(3 017.2-63 892.8q)+(834.9-16 775.4q)+2 006+236.9=63 892.8q

可解得 q=0.042，以此代入符号 q 的表示式，可解得：

最大允许设计内压 P=4.78 MPa。

示例 5：外径 $D_{h}=406\ mm$ 、壁厚 $\overline{T}_{h}=12.5\ mm$ 的油品主管上有一沿主管 $60^{\circ}$ 轴向倾斜的支管，支管外径 $D_{b}=168\ mm$ ，壁厚 $\overline{T}_{b}=7.1\ mm$ ，材料都为 15CrMo 无缝管，在连接处用 16MnR 板材所制的 $D_{r}=300\ mm$ 、 $T_{r}=12\ mm$ 的补强圈，见图 K.3。设计温度 $t=370\ ^{\circ}C$ ，设计压力 P=3.5 MPa，支管对主管、补强圈对主管的填角焊缝焊脚尺寸都是 9 mm，规定取腐蚀裕量 $C_{2}=2.5\ mm$ ，试问该管件是否满足补强设计？

![](images/b85afdcbe2363827d147174a578234d1117572c23c35b286863d5a5667885642.jpg)  
图K.3 例5的附图

解:由表 B.1, 对主管和支管, S=109 MPa, 对补强圈, S=117 MPa, 据本部分 6.6.6.2.3 b) 的规定, 在计算补强圈面积 $A_{4}$ 时可不予关注。

由表 B.3 查得, $\Phi=1.0$

$$
\begin{array}{r l} & T _ {\mathrm{h}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{h}} = 0. 8 7 5 \times 1 2. 5 = 1 0. 9 (\mathrm{mm}) \\ & T _ {\mathrm{b}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{b}} = 0. 8 7 5 \times 7. 1 = 6. 2 (\mathrm{mm}) \\ & t _ {\mathrm{h}} = \frac {P D _ {\mathrm{h}}}{2 (S \Phi + P Y)} = \frac {3 . 5 \times 4 0 6}{2 (1 0 9 \times 1 + 3 . 5 \times 0 . 4)} = 6. 5 (\mathrm{mm}) \\ & t _ {\mathrm{b}} = \frac {P D _ {\mathrm{b}}}{2 (S \Phi + P Y)} = \frac {3 . 5 \times 1 6 8}{2 (1 0 9 \times 1 + 3 . 5 \times 0 . 4)} = 2. 7 (\mathrm{mm}) \end{array}
$$

$t_{h}$ 、 $t_{b}$ 式中的 Y 值据表 27, Y=0.4。

由 6.6.6.1:

$$
d _ {1} = \left(D _ {\mathrm{b}} - 2 T _ {\mathrm{eb}}\right) / \sin \beta = [ 1 6 8 - 2 (6. 2 - 2. 5) ] / \sin 6 0 ^ {\circ} = 1 8 5. 5 (\mathrm{mm})
$$

$d_{2}$ 取下列两式中的较大值：

$$
d _ {2} = d _ {1} = 1 8 5. 5 (\mathrm{mm})
$$

$$
d _ {2} = T _ {\mathrm{eb}} + T _ {\mathrm{eh}} + \frac {d _ {1}}{2} = (6. 2 - 2. 5) + (1 0. 9 - 2. 5) + 1 8 5. 5 / 2 = 1 0 4. 9 (\mathrm{mm})
$$

故 $d_{2}=185.5(\mathrm{mm})$ 。

$L_{4}$ 取下列两式中的较小值：

$$
L _ {4} = 2. 5 T _ {\mathrm{eh}} = 2. 5 (1 0. 9 - 2. 5) = 2 1. 0 (\mathrm{mm})
$$

$$
L _ {4} = 2. 5 T _ {\mathrm{eb}} + T _ {\mathrm{r}} = 2. 5 (6. 2 - 2. 5) + 1 2 = 2 1. 3 (\mathrm{mm})
$$

故 $L_{4}=21.0(\mathrm{mm})$ 。

由公式(15)，所需补强面积 $A_{1} = t_{\mathrm{h}}d_{1}(2 - \sin \beta) = 6.4\times 185.5(2 - \sin 60^{\circ}) = 1346.6(\mathrm{mm}^{2})$ 。

由公式(17)，主管的多余截面积 $A_{2} = (2d_{2} - d_{1})(T_{\mathrm{eh}} - t_{\mathrm{h}}) = 185.5(8.4 - 6.5) = 352.45(\mathrm{mm}^2)$ 。

由公式(18)，支管的多余截面积：

$$
A _ {3} = 2 L _ {4} \left(T _ {\mathrm{eb}} - t _ {\mathrm{b}}\right) / \sin \beta = 2 \times 2 1. 0 (3. 7 - 2. 7) / \sin 6 0 ^ {\circ} = 4 8. 5 1 (\mathrm{mm} ^ {2})
$$

补强圈截面积取公式(19)、公式(20)中的较小值：

$$
A _ {4} = \left(D _ {\mathrm{r}} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) T _ {\mathrm{r}} = \left(3 0 0 - \frac {1 6 8}{\sin 6 0 ^ {\circ}}\right) \times 1 2 = 1 2 7 1. 4 1 (\mathrm{mm} ^ {2})
$$

$$
A _ {4} = \left(2 d _ {2} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) T _ {\mathrm{r}} = \left(2 \times 1 8 5. 5 - \frac {1 6 8}{\sin 6 0 ^ {\circ}}\right) \times 1 2 = 2 1 2 3. 4 1 (\mathrm{mm} ^ {2})
$$

故 $A_{4}=1\ 271.41(\mathrm{mm}^{2})$ 。

焊缝截面积 $A_{5}=4\times0.5\times9^{2}=162(mm^{2})$

由公式(21)，总的补强面积：

$$
A _ {2} + A _ {3} + A _ {4} + A _ {5} = 3 5 2. 4 5 + 4 8. 5 1 + 1 2 7 1. 4 1 + 1 6 2 = 1 8 3 4. 3 7 \left(\mathrm{mm} ^ {2}\right) > 1 3 4 6. 6 \left(\mathrm{mm} ^ {2}\right) = A _ {1}
$$

因此，该管件满足补强设计。

示例 6：外径 $D_{h}=219\ mm$ 、壁厚 $\overline{T}_{h}=8\ mm$ 的主管上有一垂直支管，支管外径 $D_{b}=114\ mm$ 、壁厚 $\overline{T}_{b}=6.3\ mm$ ，主管和支管都是 15CrMo 无缝管，见图 K.4。设计压力 P=2.5 MPa, $t=200\ ^{\circ}C$ ，假设包括主管和支管在内的管系在服役寿命期内所有除承受压力所需之外的多余厚度全部腐蚀殆尽（其中对主管取 $C_{2}=4.8\ mm$ ，对支管取 $C_{2}=3.8\ mm$ ），即按公式(19)、公式(20)算得的 $A_{2}=A_{3}=0$ 。试问该管件要求多厚的补强圈？

![](images/301aa93cb9ab9d4abd99771319edeb9ba2b95a598648be6b7c1bbdcc78bb0824.jpg)  
图K.4 例6的附图

解:由表 B.1 查得, S=121 MPa, 由表 B.3, 查得 $\Phi=1.0$ 。

$$
T _ {\mathrm{h}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{h}} = 0. 8 7 5 \times 8 = 7 (\mathrm{mm})
$$

$$
T _ {\mathrm{b}} = 0. 8 7 5 \overline {{T}} _ {\mathrm{b}} = 0. 8 7 5 \times 6. 3 = 5. 5 (\mathrm{mm})
$$

$$
t _ {\mathrm{h}} = \frac {P D _ {\mathrm{h}}}{2 (S \Phi + P Y)} = \frac {2 . 5 \times 2 1 9}{2 \times (1 2 1 \times 1 + 2 . 5 \times 0 . 4)} = 2. 3 (\mathrm{mm})
$$

$$
t _ {\mathrm{b}} = \frac {P D _ {\mathrm{b}}}{2 (S \Phi + P Y)} = \frac {2 . 5 \times 1 1 4}{2 \times (1 2 1 \times 1 + 2 . 5 \times 0 . 4)} = 1. 2 (\mathrm{mm})
$$

$t_{h}$ 、 $t_{b}$ 式中的 Y 值据表 27, Y=0.4。

由6.6.6.1：

$$
d _ {1} = \left(D _ {\mathrm{b}} - 2 T _ {\mathrm{eb}}\right) / \sin \beta = [ 1 1 4 - 2 (5. 5 - 3. 8) ] / \sin 9 0 ^ {\circ} = 1 1 0. 6 (\mathrm{mm})
$$

$d_{2}$ 取下列两式中的较大值：

$$
d _ {2} = d _ {1} = 1 1 0. 6 (\mathrm{mm})
$$

$$
d _ {2} = T _ {\mathrm{eb}} + T _ {\mathrm{eh}} + \frac {d _ {1}}{2} = (5. 5 - 3. 8) + (7 - 4. 8) + \frac {1 1 0 . 6}{2} = 5 9. 2 (\mathrm{mm})
$$

故 $d_{2}=110.6(\mathrm{mm})$ 。

$L_{4}$ 取下列两式中的较小值：

$$
L _ {4} = 2. 5 T _ {\mathrm{eh}} = 2. 5 \times (7 - 4. 8) = 5. 5 (\mathrm{mm})
$$

$$
L _ {4} = 2. 5 T _ {\mathrm{eb}} = 2. 5 \times (5. 5 - 3. 8) = 4. 2 5 (\mathrm{mm})
$$

故 $L_{4}=4.25(\mathrm{mm})$ 。

初定 $L_{4}$ 值时, 暂未考虑设置补强圈。

试取补强圈直径 $D_{r}=160\ mm$ ，并假设该补强圈是由主管材料切割制成。

故 $T_{\mathrm{r}} = T_{\mathrm{h}} = 0.875\overline{T}_{\mathrm{h}} = 0.875\times 8 = 7(\mathrm{mm})$ 。

由于考虑了设置补强圈,故重新确定补强区高度 $L_{4}, L_{4}$ 取下列两式中的较小值:

$$
L _ {4} = 2. 5 T _ {\mathrm{eh}} = 2. 5 \times (7 - 4. 8) = 5. 5 (\mathrm{mm})
$$

$$
L _ {4} = 2. 5 T _ {\mathrm{eb}} + T _ {\mathrm{r}} = 2. 5 \times (5. 5 - 3. 8) + 7 = 1 1. 2 5 (\mathrm{mm})
$$

故 $L_{4}=5.5(\mathrm{mm})$ 。

由于 $T_{\mathrm{r}} = 7 \mathrm{~mm}$ ，而 $L_{4} = 5.5 \mathrm{~mm}$ ，所以计算补强圈截面积时其厚度只能按 $L_{4}$ 计算。

由公式(15)，所需补强面积 $A_{1} = t_{\mathrm{h}}d_{1}(2 - \sin \beta) = 2.3\times 110.6 = 254.38(\mathrm{mm}^{2})$ 。

由公式(19)、公式(20)，补强圈截面积取该两式中的较小值：

$$
A _ {4} = \left(D _ {\mathrm{r}} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) L _ {4} = \left(1 6 0 - \frac {1 1 4}{\sin 9 0 ^ {\circ}}\right) \times 5. 5 = 2 5 3 (\mathrm{mm} ^ {2})
$$

$$
A _ {4} = \left(2 d _ {2} - \frac {D _ {\mathrm{b}}}{\sin \beta}\right) L _ {4} = \left(2 \times 1 1 0. 6 - \frac {1 1 4}{\sin 9 0 ^ {\circ}}\right) \times 5. 5 = 5 8 9. 6 (\mathrm{mm} ^ {2})
$$

故 $A_{4}=253(\mathrm{mm}^{2})$ 。

由于 $L_{4}<T_{r}$ ，所以在计算焊缝面积 $A_{5}$ 时，只计及补强圈对主管的连接焊缝，而不计及支管对主管的连接焊缝。焊脚尺寸为：

$$
\frac {0 . 5 T _ {\mathrm{r}}}{0 . 7 0 7} = \frac {0 . 5 \times 8}{0 . 7 0 7} = 5. 7 (\mathrm{mm})
$$

焊缝截面积：

$$
A _ {5} = 2 \times 0. 5 \times 5. 7 ^ {2} = 3 2. 5 (\mathrm{mm} ^ {2})
$$

$$
A _ {4} + A _ {5} = 2 5 3 + 3 2. 5 = 2 8 5. 5 \left(\mathrm{mm} ^ {2}\right) > 2 5 4. 3 8 \left(\mathrm{mm} ^ {2}\right) = A _ {1}
$$

由此，设置由 $D_{\mathrm{b}} = 219~\mathrm{mm}, T_{\mathrm{h}} = 8~\mathrm{mm}$ 无缝主管上切割制成的补强圈是能够满足本管件的补强要求的。

示例 7：外径 $D_{h}=219\ mm$ 、壁厚 $\overline{T}_{h}=8\ mm$ 的油品主管上有一垂直锻制承插焊管接头， $D_{b}=38\ mm$ ，Sch80，支管的焊缝都符合图 23 的焊缝尺寸要求，主管材料为 20 号无缝钢管，设计压力 P=2.8 MPa， $t=230\ ^{\circ}C$ ，规定取腐蚀裕量 $C_{2}=2.5\ mm$ 。试问此管件是否需要附加补强？

解: 在主管和支管按内压计算能满足强度的前提下, 对此承插焊管接头, 按照 6.6.6.3 不需补强的条件 a), 不必进行补强计算, 也不必采用补强。

# 附录 L

(资料性)

# 压力面积法补强计算

## L.1 符号

下列符号适用于本附录：

$A_{s}$ ——补强范围内三通纵断面上的承载面积,单位为平方毫米 $(\mathrm{mm}^{2})$ ;

$A_{p}$ ——补强范围内三通纵断面上的承压面积,单位为平方毫米 $(\mathrm{mm}^{2})$ ;

$D_{b}$ ——三通支管外直径,单位为毫米(mm);

$D_{h}$ ——三通主管外直径,单位为毫米(mm);

$L_{4}$ ——三通主管外侧补强范围高度, $L_{4}=\sqrt{(D_{b}-T_{eb})T_{eb}}$ ,单位为毫米(mm);

$L_{6}$ ——三通主管外侧补强范围宽度, $L_{6}=\sqrt{(D_{h}-T_{eh})T_{eh}}$ ,单位为毫米(mm);

P ——设计压力,单位为兆帕(MPa);

S ——设计温度下三通材料的许用应力,单位为兆帕(MPa);

$T_{eb}$ ——支管有效厚度,单位为毫米(mm);

$T_{eh}$ ——主管有效厚度,单位为毫米(mm)。

## L.2 补强计算

整体成型三通的补强计算的步骤如下,其他异形组件的开孔补强计算也可参照压力面积法进行补强计算(参见 EN 13480.3):

a）参照图 L.1 画出三通纵断面图，求出承压面积 $A_{p}$ 和承载面积 $A_{s}$ 。

b) 强度条件需符合公式(L.1)的要求：

……( L.1 )

![](images/5b088aee8bbc6380b9271c401ea54187c3ddd59f387d989c143bb3a978e03197.jpg)  
图 L.1 三通补强计算示意图

## L.3 支管连接的压力面积法

支管连接的基本型式以相邻接管、斜接支管、横向支管、偏置支管、Y型三通等其他异型组件的补强计算可参见EN13480.3。

## 附录 M

(规范性)

柔性系数和应力增大系数

M.1 表 M.1 列出了管道组件及其连接接头的柔性系数和应力增大系数。

表 M.1 柔性系数和应力增大系数

<table><tr><td colspan="2">名称</td><td>计算公式</td><td>简图</td></tr><tr><td colspan="4">第1项:对焊弯头或弯管a,c,d,e</td></tr><tr><td colspan="2">尺寸系数h</td><td> $TR_1/R^2$ </td><td rowspan="6"><img src="images/7db8cc2ffd9e0e7c651122a129cd2c0240ebdefd04d1b43d0d0512ca16791b6a.jpg"/></td></tr><tr><td rowspan="2">柔性系数</td><td>平面内, $k_i$ </td><td>1.65/h</td></tr><tr><td>平面外, $k_o$ </td><td>1.65/h</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_i$ </td><td>0.9/ $h^{2/3}$ </td></tr><tr><td>平面外, $i_o$ </td><td>0.75/ $h^{2/3}$ </td></tr><tr><td>扭转, $i_t$ </td><td>1</td></tr><tr><td colspan="4">第2项:窄间距斜接弯头[s&lt;R(1+tanθ)]a,c,e</td></tr><tr><td colspan="2">尺寸系数h</td><td> $sT\cot\theta/(2R^2)$ </td><td rowspan="6"><img src="images/945a377284aa824ef493e562bd1185216bdd5a66c1715bae6433f9194ecf1276.jpg"/></td></tr><tr><td rowspan="2">柔性系数</td><td>平面内, $k_i$ </td><td>1.52/ $h^{5/6}$ </td></tr><tr><td>平面外, $k_o$ </td><td>1.52/ $h^{5/6}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_i$ </td><td>0.9/ $h^{2/3}$ </td></tr><tr><td>平面外, $i_o$ </td><td>0.9/ $h^{2/3}$ </td></tr><tr><td>扭转, $i_t$ </td><td>1</td></tr><tr><td colspan="4">第3项:宽间距斜接弯头[s≥R(1+tanθ)]a,e,f</td></tr><tr><td colspan="2">尺寸系数h</td><td> $T(1+\cot\theta)/(2R)$ </td><td rowspan="6"><img src="images/d676c5e92d62fda7ba6592fc50054c5b6afb7aac5584bd527f4f51d900a1acf9.jpg"/></td></tr><tr><td rowspan="2">柔性系数</td><td>平面内, $k_i$ </td><td>1.52/ $h^{5/6}$ </td></tr><tr><td>平面外, $k_o$ </td><td>1.52/ $h^{5/6}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_i$ </td><td>0.9/ $h^{2/3}$ </td></tr><tr><td>平面外, $i_o$ </td><td>0.9/ $\hat{h}^{2/3}$ </td></tr><tr><td>扭转, $i_t$ </td><td>1</td></tr><tr><td colspan="4">第4项:标准对焊三通(GB/T 12459) $^{\text{b,g,h}}$ </td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{\text{ir}}$ </td><td> $0.18(R/T)^{0.8}(d/D)^{5}$ </td><td rowspan="12"><img src="images/2d10d45fc9e5c9fb30e26cda8f7685079de25a506635725f3e32a0ecafb69c9e.jpg"/><img src="images/8a6816573797e4767d9a7fe59afa40e6f339d6c754e599cada68c8dbf4425c06.jpg"/></td></tr><tr><td>平面外, $k_{\text{or}}$ </td><td>1</td></tr><tr><td>扭转, $k_{\text{tr}}$ </td><td> $0.08(R/T)^{0.91}(d/D)^{5.7}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{\text{ib}}$ </td><td> $[1.91(d/D)-4.32(d/D)^{2}+2.7(d/D)^{3}]$  $(R/T)^{0.77}(d/D)^{0.47}(t/T)$ </td></tr><tr><td>平面外, $k_{\text{ob}}$ </td><td> $[0.34(d/D)-0.49(d/D)^{2}+0.18(d/D)^{3}]$  $(R/T)^{1.46}(t/T)$ </td></tr><tr><td>扭转, $k_{\text{tb}}$ </td><td> $[1.08(d/D)-2.44(d/D)^{2}+1.52(d/D)^{3}]$  $(R/T)^{0.77}(d/D)^{1.61}(t/T)$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{\text{ir}}$ </td><td> $0.98(R/T)^{0.35}(d/D)^{0.72}(t/T)^{-0.52}$ </td></tr><tr><td>平面外, $i_{\text{or}}$ </td><td> $0.61(R/T)^{0.29}(d/D)^{1.95}(t/T)^{-0.53}$ </td></tr><tr><td>扭转, $i_{\text{tr}}$ </td><td> $0.34(R/T)^{2/3}(d/D)(t/T)^{-0.5}$ </td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{\text{ib}}$ </td><td> $0.33(R/T)^{2/3}(d/D)^{0.18}(t/T)^{0.7}$ </td></tr><tr><td>平面外, $i_{\text{ob}}$ </td><td> $0.42(R/T)^{2/3}(d/D)^{0.37}(t/T)^{0.37}$ </td></tr><tr><td>扭转, $i_{\text{tb}}$ </td><td> $0.42(R/T)^{2/3}(d/D)^{1.1}(t/T)^{1.1}$ </td></tr><tr><td colspan="4">第5项:带补强焊制三通(当 $t_p>1.5T$ ,则 $t_p=1.5T)^{\text{b,h}}$ </td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{\text{ir}}$ </td><td> $0.21[R/(T+0.5t_p)]^{0.97}(t/T)^{-0.65}(d/D)^{6.2}$ </td><td rowspan="12"><img src="images/4e291e87d0ed55e81d9f784736467f4718f5e2a58c85d097754517829f97a80e.jpg"/></td></tr><tr><td>平面外, $k_{\text{or}}$ </td><td>1</td></tr><tr><td>扭转, $k_{\text{tr}}$ </td><td> $0.12[R/(T+0.5t_p)]^{1.39}(t/T)^{-0.74}$  $(d/D)^{8.5}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{\text{ib}}$ </td><td> $[1.29(d/D)-2.73(d/D)^{2}+1.62(d/D)^{3}]$  $[R/(T+0.5t_p)]^{1.2}(t/T)^{0.56}(d/D)^{0.33}$ </td></tr><tr><td>平面外, $k_{\text{ob}}$ </td><td> $[0.84(d/D)-1.27(d/D)^{2}+0.5(d/D)^{3}]$  $[R/(T+0.5t_p)]^{1.69}(t/T)^{0.68}(d/D)^{0.21}$ </td></tr><tr><td>扭转, $k_{\text{tb}}$ </td><td> $1.1[R/(T+0.5t_p)]^{0.5}(d/D)^{5.42}$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{\text{ir}}$ </td><td> $[R/(T+0.5t_p)]^{0.45}(d/D)^{1.0}$  $(t/T)^{-0.34}\geqslant1.5$ </td></tr><tr><td>平面外, $i_{\text{or}}$ </td><td> $[1.29(d/D)-2.87(d/D)^{2}+2.39(d/D)^{3}]$  $(t/T)^{-0.25}[R/(T+0.5t_p)]^{0.35}$ </td></tr><tr><td>扭转, $i_{\text{tr}}$ </td><td> $0.36[R/(T+0.5t_p)]^{2/3}(t/T)^{-0.6}(d/D)^{1.4}$ </td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{\text{ib}}$ </td><td> $[3.33(d/D)-5.49(d/D)^{2}+2.94(d/D)^{3}]$  $(TR^{2/3})(T+0.5t_p)]^{-5/3}(t/T)^{0.3}$ </td></tr><tr><td>平面外, $i_{\text{ob}}$ </td><td> $[2.86(d/D)+2.4(d/D)^{2}-4.34(d/D)^{3}](TR^{2/3})$  $(T+0.5t_p)]^{-5/3}(t/T)^{0.3}$ (当 $t/T<0.85$ ,则 $t/T=0.85$ )</td></tr><tr><td>扭转, $i_{\text{tb}}$ </td><td> $0.642(d/D)^{2}(TR^{2/3})(T+0.5t_p)^{-5/3}(t/T)^{0.3}$ </td></tr><tr><td colspan="4">第6项:不带补强焊制三通b,h,i</td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{\text{ir}}$ </td><td> $1.23(R/T)^{0.47}(t/T)^{-0.47}(d/D)^{5.3}$ </td><td rowspan="12"><img src="images/fe9612dd7c4a6867d487ca0119452b0aeb016f54bdb2917a5689444304381f3e.jpg"/><img src="images/0ec95c612e697433d560da3bd7829fb8bb8b214022fee01aa90f7fcfaf6656ec.jpg"/>-<img src="images/68a8437ee0faa75c715ed076faf106f57b42abf10092c0995a05f5d24d8dad9c.jpg"/></td></tr><tr><td>平面外, $k_{\text{or}}$ </td><td>1</td></tr><tr><td>扭转, $k_{\text{tr}}$ </td><td> $(R/T)^{0.78}(t/T)^{-0.8}(d/D)^{7.8}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{\text{ib}}$ </td><td> $[3.15(d/D)-6.4(d/D)^{2}+4(d/D)^{3}]$  $(R/T)^{0.83}(t/T)^{0.49}(d/D)^{-0.2}$ </td></tr><tr><td>平面外, $k_{\text{ob}}$ </td><td> $[2.05(d/D)-2.94(d/D)^{2}+1.1(d/D)^{3}]$  $(R/T)^{1.4}(t/T)^{0.6}(d/D)^{0.12}$ </td></tr><tr><td>扭转, $k_{\text{tb}}$ </td><td> $0.95(R/T)^{0.83}(d/D)^{5.42}$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{\text{ir}}$ </td><td> $1.2(d/D)^{1.0}(R/T)^{0.4}(t/T)^{-0.35}\geqslant1.5$ </td></tr><tr><td>平面外, $i_{\text{or}}$ </td><td> $[(d/D)-2.7(d/D)^{2}+2.62(d/D)^{3}](R/T)^{0.43}(t/T)^{-0.7}$ (当 $d/D<0.5$ ,则 $d/D=0.5$ ;当 $t/T<0.5$ ,则 $t/T=0.5$ )</td></tr><tr><td>扭转, $i_{\text{tr}}$ </td><td> $1.2(R/T)^{0.46}(t/T)^{-0.45}(d/D)^{1.37}$ (当 $t/T<0.15$ ,则 $t/T=0.15$ )</td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{\text{ib}}$ </td><td> $[0.038+1.45(d/D)-2.39(d/D)^{2}+1.34(d/D)^{3}]$  $(R/T)^{0.76}(t/T)^{0.74}$ (当 $t/T<1$ ,则 $t/T=1$ )</td></tr><tr><td>平面外, $i_{\text{ob}}$ </td><td> $[0.038+2(d/D)+2(d/D)^{2}-3.1(d/D)^{3}]$  $(R/T)^{2/3}(t/T)$ (当 $t/T<0.6$ ,则 $t/T=0.6$ )</td></tr><tr><td>扭转, $i_{\text{tb}}$ </td><td> $0.45(R/T)^{0.8}(t/T)^{0.29}(d/D)^{2}$ </td></tr><tr><td colspan="4">第7项:挤压成型对焊三通( $r_x\geqslant0.05d_o$ 且 $T<T_c<1.5T)^{b,h,j}$ </td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{\text{ir}}$ </td><td> $0.18(R/T)^{0.8}(d/D)^{5}$ </td><td rowspan="12"><img src="images/4388cf5c2b43ef411e9fdde42850190f305b76b1e1d8cc09bb09e1ce0d6c8110.jpg"/></td></tr><tr><td>平面外, $k_{\text{or}}$ </td><td>1</td></tr><tr><td>扭转, $k_{\text{tr}}$ </td><td> $0.08(R/T)^{0.91}(d/D)^{5.7}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{\text{ib}}$ </td><td> $[1.91(d/D)-4.32(d/D)^{2}+2.7(d/D)^{3}]$  $(R/T)^{0.77}(d/D)^{0.47}(t/T)$ </td></tr><tr><td>平面外, $k_{\text{ob}}$ </td><td> $[0.34(d/D)-0.49(d/D)^{2}+0.18(d/D)^{3}]$  $(R/T)^{1.46}(t/T)$ </td></tr><tr><td>扭转, $k_{\text{tb}}$ </td><td> $[1.08(d/D)-2.44(d/D)^{2}+1.52(d/D)^{3}]$  $(R/T)^{0.77}(d/D)^{1.79}(t/T)$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{\text{ir}}$ </td><td> $1.45(1+r_x/R)^{-2/3}(R/T)^{0.35}(d/D)^{0.72}(t/T)^{-0.52}$ </td></tr><tr><td>平面外, $i_{\text{or}}$ </td><td> $0.58(1+r_x/R)^{-2/3}(R/T)^{2/3}(d/D)^{2.69}$ </td></tr><tr><td>扭转, $i_{\text{tr}}$ </td><td> $0.55(1+r_x/R)^{-2/3}(R/T)^{2/3}(d/D)(t/T)^{-0.5}$ </td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{\text{ib}}$ </td><td> $0.56(1+r_x/R)^{-2/3}(R/T)^{2/3}(d/D)^{0.68}$ </td></tr><tr><td>平面外, $i_{\text{ob}}$ </td><td> $0.85(1+r_x/R)^{-2/3}(R/T)^{2/3}(d/D)^{0.5}$ </td></tr><tr><td>扭转, $i_{\text{tb}}$ </td><td> $0.71(1+r_x/R)^{-2/3}(R/T)^{2/3}(d/D)^{2}$ </td></tr><tr><td colspan="4">第8项:嵌入式支管(当没有给出 $r_x$ 时, $r_x=0)^{b,g,h}$ </td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{ir}$ </td><td> $0.18(R/T)^{0.84}(d/D)^5$ </td><td rowspan="12"><img src="images/4691d1c5393d841066a9df1c604523c9d6540b54c9a59219f0459c3eea91c210.jpg"/>-<img src="images/63a70686d7fd1e42ea1c8f2834055ccdb3eb5f69bf6182c9f81d96831d0e402e.jpg"/></td></tr><tr><td>平面外, $k_{or}$ </td><td>1</td></tr><tr><td>扭转, $k_{tr}$ </td><td> $0.1(R/T)^{0.91}(d/D)^{5.7}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{ib}$ </td><td> $[2.36(d/D)-5.33(d/D)^2+3.33(d/D)^3](R/T)^{0.77}(d/D)^{0.47}(t/T)$ </td></tr><tr><td>平面外, $k_{ob}$ </td><td> $(1+r_x/R)[0.67(d/D)-0.97(d/D)^2+0.36(d/D)^3](R/T)^{1.46}(t/T)$ </td></tr><tr><td>扭转, $k_{tb}$ </td><td> $[1.05(d/D)-2.36(d/D)^2+1.49(d/D)^3](R/T)^{0.77}(d/D)^{1.61}(t/T)$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{ir}$ </td><td> $(R/T)^{0.35}(d/D)^{0.72}(t/T)^{-0.52}$ </td></tr><tr><td>平面外, $i_{or}$ </td><td> $0.72(R/T)^{0.29}(d/D)^{1.95}(t/T)^{-0.53}$ </td></tr><tr><td>扭转, $i_{tr}$ </td><td> $0.36(R/T)^{2/3}(d/D)(t/T)^{-0.5}$ </td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{ib}$ </td><td> $0.35(R/T)^{2/3}(d/D)^{0.18}(t/T)^{0.7}$ </td></tr><tr><td>平面外, $i_{ob}$ </td><td> $0.48(R/T)^{2/3}(d/D)^{0.37}(t/T)^{0.37}$ </td></tr><tr><td>扭转, $i_{tb}$ </td><td> $0.44(R/T)^{2/3}(d/D)^{1.1}(t/T)^{1.1}$ </td></tr><tr><td colspan="4">第9项:整体补强支管座b,h,k</td></tr><tr><td rowspan="3">主管柔性系数</td><td>平面内, $k_{ir}$ </td><td> $0.5(R/T)^{0.5}(d/D)^5$ </td><td rowspan="12"><img src="images/bedfcc513a09b867bf182a582e13c9c44c3d1909fdc7f1d8b7d42b5da3218914.jpg"/><img src="images/77799e3d6dfb5409349acdf00f131e35cea10fd9588b35691d7d76ecc57e1c66.jpg"/></td></tr><tr><td>平面外, $k_{or}$ </td><td>1</td></tr><tr><td>扭转, $k_{tr}$ </td><td> $0.1(R/T)(d/D)^{5.7}$ </td></tr><tr><td rowspan="3">支管柔性系数</td><td>平面内, $k_{ib}$ </td><td> $[0.55(d/D)-1.13(d/D)^2+0.69(d/D)^3](R/T)(t/T)$ </td></tr><tr><td>平面外, $k_{ob}$ </td><td> $[1.03(d/D)-1.55(d/D)^2+0.59(d/D)^3](R/T)^{1.4}(t/T)(d/D)^{0.33}$ </td></tr><tr><td>扭转, $k_{tb}$ </td><td> $[0.37(d/D)-0.75(d/D)^2+0.46(d/D)^3](R/T)(t/T)(d/D)^{1.2}$ </td></tr><tr><td rowspan="3">主管应力增大系数</td><td>平面内, $i_{ir}$ </td><td> $(R/T)^{0.43}(d/D)^{0.5}\geqslant1.5$ </td></tr><tr><td>平面外, $i_{or}$ </td><td> $[0.02+0.88(d/D)-2.56(d/D)^2+2.58(d/D)^3](R/T)^{0.43}$ </td></tr><tr><td>扭转, $i_{tr}$ </td><td> $1.3(R/T)^{0.45}(d/D)^{1.37}$ </td></tr><tr><td rowspan="3">支管应力增大系数</td><td>平面内, $i_{ib}$ </td><td> $[0.08+1.28(d/D)-2.35(d/D)^2+1.45(d/D)^3](R/T)^{0.81}(t/T)(r/r_p)$ </td></tr><tr><td>平面外, $i_{ob}$ </td><td> $[1.83(d/D)-1.07(d/D)^3](R/T)^{0.82}(t/T)(r/r_p)^{1.18}$ </td></tr><tr><td>扭转, $i_{tb}$ </td><td> $0.77(R/T)^{2/3}(t/T)(d/D)^2(r/r_p)$ </td></tr><tr><td colspan="4">第10项:同心或偏心异径管 $^{1}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td> $0.6+0.003(\alpha T_2/T_1)^{0.8}(D_2/T_2)^{0.25}(D_2/r_2)$ </td><td rowspan="3"><img src="images/67c1ae766f6fed66698400f21c2a9cefdc25d4107826e24cec5703ea1572e8fb.jpg"/></td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td> $0.6+0.003(\alpha T_2/T_1)^{0.8}(D_2/T_2)^{0.25}(D_2/r_2)$ </td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td> $0.3+0.0015(\alpha T_2/T_1)^{0.8}(D_2/T_2)^{0.25}(D_2/r_2)$ </td></tr><tr><td colspan="4">第11项:对焊接头( $T\geqslant6$ mm, $\delta_{\max}\leqslant1.5$ mm,且 $\delta_{\text{avg}}/T\leqslant0.13$ ) $^{\mathrm{m}}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td>1.0</td><td rowspan="3"><img src="images/682824b83a1c621755eb3772c54f42f9f66439f271174e299955e70472522082.jpg"/></td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td>1.0</td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td>1.0</td></tr><tr><td colspan="4">第12项:对焊接头( $T\geqslant6$ mm, $\delta_{\max}\leqslant3$ mm,且 $\delta_{\text{avg}}/T$ =任何值或 $T<6$ mm, $\delta_{\max}\leqslant1.5$ mm,且 $\delta_{\text{avg}}/T\leqslant0.33$ ) $^{\mathrm{m}}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td>最大1.9或 $0.9+2.7(\delta_{\text{avg}}/T)$ 但不小于1.0</td><td rowspan="3"><img src="images/bd8a002cd40bddb5224814118908020f8b51721e49fe6f56733235a51d958f32.jpg"/></td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td>最大1.9或 $0.9+2.7(\delta_{\text{avg}}/T)$ 但不小于1.0</td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td> $0.45+1.35(\delta_{\text{avg}}/T)$ 但不小于1.0</td></tr><tr><td colspan="4">第13项:填角焊接头、承插焊法兰或承插焊管件 $^{\mathrm{n}}$ </td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td>1.3</td><td rowspan="3"><img src="images/26e71c8e3e0cc43f3769c5c487c3ea8fc4bd70170c883b86e35a8fa95fe1fb6b.jpg"/></td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td>1.3</td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td>1.3</td></tr><tr><td colspan="4">第14项:锥形过渡段</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td>最大1.9或 $1.3+0.0036(D_{\mathrm{o}}/T)+3.6(\delta/T)$ </td><td rowspan="3"><img src="images/013c8a39069ab16c1ceb1872d99bde09dc9de873b07ebe5a37a5e67d32d69230.jpg"/></td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td>最大1.9或 $1.3+0.0036(D_{\mathrm{o}}/T)+3.6(\delta/T)$ </td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td>1.3</td></tr><tr><td colspan="4">第15项:带颈对焊法兰</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{\mathrm{i}}$ </td><td>1.0</td><td rowspan="3">—</td></tr><tr><td>平面外, $i_{\mathrm{o}}$ </td><td>1.0</td></tr><tr><td>扭转, $i_{\mathrm{t}}$ </td><td>1.0</td></tr><tr><td colspan="4">第16项:单边平焊法兰</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{i}$ </td><td>1.3</td><td rowspan="3">—</td></tr><tr><td>平面外, $i_{o}$ </td><td>1.3</td></tr><tr><td>扭转, $i_{t}$ </td><td>1.3</td></tr><tr><td colspan="4">第17项:双边平焊法兰</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{i}$ </td><td>1.2</td><td rowspan="3">—</td></tr><tr><td>平面外, $i_{o}$ </td><td>1.2</td></tr><tr><td>扭转, $i_{t}$ </td><td>1.2</td></tr><tr><td colspan="4">第18项:松套法兰</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{i}$ </td><td>1.6</td><td rowspan="3">—</td></tr><tr><td>平面外, $i_{o}$ </td><td>1.6</td></tr><tr><td>扭转, $i_{t}$ </td><td>1.6</td></tr><tr><td colspan="4">第19项:螺纹管接头或螺纹法兰</td></tr><tr><td rowspan="3">应力增大系数</td><td>平面内, $i_{i}$ </td><td>2.3</td><td rowspan="3">—</td></tr><tr><td>平面外, $i_{o}$ </td><td>2.3</td></tr><tr><td>扭转, $i_{t}$ </td><td>2.3</td></tr><tr><td colspan="4">注1:应力增大系数和柔性系数是用于缺少更适用数据的情况。对于 $D/T\leqslant100$ ,已证实表中值是有效的。表M.1中未列出的其他管道元件,如阀门、过滤器、偏心异径管、异径弯头、活接头及非标元件等,可根据其重要几何参数与表M.1所列管件相比类似的元件来选择合适的应力增大系数,之间的关系可使用工程判断进行确定,同时通过有限元分析或其他有文献记录的测试结果进行补充确定。注2:柔性系数和应力增大系数均不小于1.0。注3:应力增大系数可在没有柔性系数情况下使用。注4:表中的柔性系数和应力增大系数来源于针对延展性铁基材料的疲劳试验和有限元数值模拟,应用于某些非铁基材料(比如铜合金或者铝合金)在非低周场合使用时需加以分析。注5:波纹直管、波纹弯管或褶皱弯管依据GB/T 12777或其他类似标准进行设计。注6:当仅需一个应力增大系数时,使用最高的平面内或平面外应力增大系数。柔性系数按规定方向使用。对于第10项~第19项,平面内或平面外方向相互正交且与管道轴向正交。注7:计算时若需要持续应力或力矩系数,对于第1项~第3项及第10项~第19项所列组件,持续应力或力矩系数可以取相应组件的应力增大系数。对于第4项~第9项所列管件,持续应力或力矩系数取下列a)与b)或a)与c)中的较小值:a) $0.75i$ ;b) $(t/T)\sqrt{i}$ (当 $t/T>1$ 时);c) $\sqrt{i}$ (当 $t/T\leqslant1$ 时)。持续应力或弯矩系数与相连管道的截面模量一起使用,且不小于1.0。当 $D_{0}/T$ 大于50时,持续应力或力矩系数除以 $(1.3-0.006D_{0}/T)$ 。</td></tr><tr><td colspan="4">注8:表中符号如下: $B$  ——斜接弯管斜接段中心线处的间距,单位为毫米(mm); $b$  ——支管脚标,对应图M.1中三通支管端; $C_{x}$  ——承插焊最小焊脚高度,单位为毫米(mm); $D$  ——所连接管道的平均直径,由( $D_{o}-T$ )计算而得,单位为毫米(mm); $d$  ——所连接支管的平均直径,由( $d_{o}-t$ )计算而得,单位为毫米(mm); $d'$  ——图M.4a)、b)、c)的有效支管直径,单位为毫米(mm); $D_{1}$  ——异径管大端所连接主管的外径,单位为毫米(mm); $D_{2}$  ——异径管小端所连接主管的外径,单位为毫米(mm); $D_{i}$  ——所连接主管的内径,由( $D_{o}-2T$ )计算而得,单位为毫米(mm); $d_{i}$  ——所连接支管的内径,由( $d_{o}-2t$ )计算而得,单位为毫米(mm); $D_{o}$  ——所连接管道的外径,单位为毫米(mm); $d_{o}$  ——所连接支管的外径,单位为毫米(mm); $E$  ——弹性模量,单位为兆帕(MPa); $h$  ——弯头或弯管柔性系数; $i$  ——应力增大系数; $k$  ——柔性系数; $I_{b}$  ——所连接支管的惯性矩,单位为四次方毫米( $mm^{4}$ ); $I_{r}$  ——所连接主管的惯性矩,单位为四次方毫米( $mm^{4}$ ); $L_{1}$  ——图M.4a)、b)、c)中支管有效补强高度,单位为毫米(mm); $L_{2}$  ——第10项简图中异径管靠近小端处圆柱段的长度,单位为毫米(mm); $M_{i}$  ——平面内力矩,单位为牛顿·毫米(N·mm); $M_{o}$  ——平面外力矩,单位为牛顿·毫米(N·mm); $M_{t}$  ——扭矩,单位为牛顿·毫米(N·mm); $N_{c}$  ——第4项~第9项中的三通主管端相邻的法兰或者其他刚性件的数量(1或2); $P$  ——内压(表压),单位为兆帕(MPa); $R$  ——所连接管道的平均半径,由( $D_{o}-T$ )/2计算而得,单位为毫米(mm); $r$  ——所连接支管的平均半径,由( $d_{o}-t$ )/2计算而得,单位为毫米(mm); $R_{1}$  ——焊接弯头或弯管的弯曲半径,单位为毫米(mm); $r_{2}$  ——第10项简图中异径管大小端过渡半径或图M.4中支管补强部位过渡半径,单位为毫米(mm); $r_{i}$  ——图M.4中支管内径,单位为毫米(mm); $r_{x}$  ——在主管和支管轴线的平面内,外轮廓转角处的曲率半径,单位为毫米(mm); $r_{p}$  ——第9项简图及图M.4中到管件外边缘的半径,单位为毫米(mm); $s$  ——斜接弯管斜接段中心线处的间距,单位为毫米(mm); $T$  ——第1项简图中所连接管道的名义壁厚或管件的平均壁厚,单位为毫米(mm);第2项和第3项简图中斜接弯头管道的名义壁厚,单位为毫米(mm);第4项和第7项简图中三通连接主管的名义壁厚,单位为毫米(mm);第5项、第6项、第8项、第9项简图中三通主管的名义壁厚,单位为毫米(mm);第11项~第14项简图中焊接接头管道的名义壁厚,单位为毫米(mm); $t$  ——所连接支管的名义壁厚,单位为毫米(mm); $t'$  ——图M.4a)、b)、c)的有效支管壁厚,单位为毫米(mm); $T_{1}$  ——异径管大端所连接管道的名义壁厚,单位为毫米(mm);</td></tr><tr><td colspan="4"> $T_{2}$ ——异径管小端所连接管道的名义壁厚,单位为毫米(mm); $T_{c}$ ——三通圆角部(主管与支管相交处)厚度,单位为毫米(mm); $t_{n}$ ——图M.4a)、b)中支管局部厚度,单位为毫米(mm);y——图M.4c)中支管台补强部位的长度,单位为毫米(mm);α——异径管锥角,单位为度(°);δ——对接焊口的错边量,单位为毫米(mm);θ——斜接弯管一条焊缝方向改变的角度的一半,单位为度(°); $\theta_{\text{nb}}$ ——支管平面内转角,单位为度(°); $\theta_{\text{ob}}$ ——支管平面外转角,单位为度(°); $\theta_{\text{tb}}$ ——支管扭转角,单位为度(°); $\theta_{\text{ir}}$ ——主管平面内转角,单位为度(°); $\theta_{\text{or}}$ ——主管平面外转角,单位为度(°); $\theta_{\text{tr}}$ ——主管扭转角,单位为度(°)。注9:“—”表示暂无需要。</td></tr><tr><td colspan="4">a对于弯管和弯头,应力增大系数和柔性系数应用于其有效弧长,即第1项~第3项简图中的粗中心线所示,可从表M.1中公式计算出尺寸系数h后,从图M.2直接查取。b对于第4项~第9项中的三通,如图M.1和图M.6所示,对主管端,应力增大系数应用于交叉点,对支管端,应力增大系数应用位置符合下列规定:a)当 $d_{o}/D_{o}>0.5$ 时,交叉点;b)当 $d_{o}/D_{o}\leqslant0.5$ 时,支管中心线与主管的外表面的交点。对所有 $d_{o}/D_{o}$ ,第4项~第9项中三通的柔性系数按图M.1和图M.6所示使用。c当法兰装在一端或两端时,表中的应力增大系数和柔性系数使用修正系数 $C_{f}$ 进行校正。 $C_{f}$ 根据表M.1中公式计算出尺寸系数h后从图M.3查取。d当弯头为90°且弯头壁厚等于相连管道的壁厚,柔性系数 $k_{i}$ 和 $k_{o}$ 按1.3/h计算,同时用图M.3中的相应修正系数 $C_{f}$ 进行校正。e对于直径大、管壁薄的弯头或弯管,内压对柔性系数和应力增大系数有显著影响,表中的值修正如下: $k/\left[1+6\left(\frac{P}{E}\right)\left(\frac{R}{T}\right)^{7/3}\left(\frac{R_{1}}{R}\right)^{1/3}\right]$  $i/\left[1+3.25\left(\frac{P}{E}\right)\left(\frac{R}{T}\right)^{5/2}\left(\frac{R_{1}}{R}\right)^{2/3}\right]$ f含一个斜接点的情形。g对第4项标准对焊三通,表列应力增大系数是基于没有任何缺陷的三通,否则可参考第6项给出的公式进行计算。使用第4项给出的应力增大系数时,应满足以下规定:a)若 $r_{x}\geqslant(1/8)(d_{o})$ 且 $T_{c}\geqslant1.5T$ ,柔性系数和应力增大系数除以1.26;b)若t/T&lt;0.6,对所有分支管计算柔性系数和应力增大系数时均使用t/T=0.6。h满足以下条件时柔性系数和应力增大系数才能应用:a)除另有说明,支管轴线与主管外表面垂直,误差在5°以内;b)R/T≤50;c)d/D≤1;d)r/t≤50;</td></tr><tr><td colspan="2">e) 连接主管的壁厚和直径在支管中心线两侧至少保持两个主管直径;f) 对于第4项、第7项、第8项, $t/T \leqslant 1.2$ 且 $T_c/T \geqslant 1.1$ 。当表M.2中柔性系数小于或等于1.0,与柔性系数相关的刚度均为刚性。当第4项~第9项中的三通主管一端或者两端与法兰或者其他刚性件相邻时,柔性系数 $k_{\text{ib}}$ 、 $k_{\text{ob}}$ 及 $k_{\text{tb}}$ 需乘以表M.3中的系数 $c$ ,主管端与法兰或者其他刚性件相邻,指的是支管与法兰或刚性件间主管的直管段长度小于 $0.1D^{1.4}/T^{0.4}$ 。第4项、第5项、第7项~第9项中的应力增大系数 $i_{\text{ib}}$ 、 $i_{\text{ob}}$ 、 $i_{\text{tb}}$ 、 $i_{\text{ir}}$ 、 $i_{\text{or}}$ 、 $i_{\text{tr}}$ 和柔性系数 $k_{\text{ib}}$ 、 $k_{\text{ob}}$ 、 $k_{\text{tb}}$ 、 $k_{\text{ir}}$ 、 $k_{\text{or}}$ 、 $k_{\text{tr}}$ 不大于相应第6项及图M.4d)采用所连接主管和支管的尺寸及 $r_2=0$ 计算得出的应力增大系数和柔性系数。第5项~第9项中的应力增大系数 $i_{\text{ib}}$ 、 $i_{\text{ob}}$ 、 $i_{\text{tb}}$ 、 $i_{\text{ir}}$ 、 $i_{\text{or}}$ 、 $i_{\text{tr}}$ 和柔性系数 $k_{\text{ib}}$ 、 $k_{\text{ob}}$ 、k $_{\text{tb}}$ 、 $k_{\text{ir}}$ 、 $k_{\text{or}}$ 、 $k_{\text{tr}}$ 不小于相应第4项采用 $T_c=1.1T$ 计算得出的应力增大系数和柔性系数。第4项~第9项中若 $i_{\text{ob}} < i_{\text{ib}}$ ,则 $i_{\text{ob}} = i_{\text{ib}}$ ;若 $i_{\text{ir}} < i_{\text{or}}$ ,则 $i_{\text{ir}} = i_{\text{or}}$ 。当支管轴线与主管轴线在同一平面内且垂直于主管外表面45°以内、同时满足 $D/T < 50$ 及 $d/D \leqslant 0.6$ 时,第5项、第6项、第8项、第9项中的应力增大系数 $i_{\text{ib}}$ 、 $i_{\text{ob}}$ 、 $i_{\text{ir}}$ 、 $i_{\text{or}}$ 、 $i_{\text{tr}}$ 可直接使用;在缺少更多可用数据时, $i_{\text{tb}}$ 可按 $i_{\text{ob}}$ 取值。当第6项中 $t/T \leqslant 0.85$ , $d/D < 1$ ,且 $D/T \geqslant 25$ 时,应力增大系数 $i_{\text{ob}}$ 需乘以 $[0.75(t/T) - 0.89(t/T)^2 + 0.18](D/T)^{0.34}$ 或1.0的较大值。当第5项中 $t/T \leqslant 0.85$ , $d/D < 1$ ,且 $D/T \geqslant 25$ 时,应力增大系数 $i_{\text{ob}}$ 需乘以 $[1.07(t/T) - 1.08(t/T)^2 + 0.026](D/T)^{0.34}$ 或1.0的较大值。支管连接端额定压力要大于或等于相连的主管。支管连接端应力增大系数使用所连接管道的截面模量。截面模量按下列公式计算:a) 对主管: $Z = \left( \frac{\pi}{32} \right) \left( \frac{D_o^4 - D_i^4}{D_o} \right)$ b) 对支管: $Z_b = \left( \frac{\pi}{32} \right) \left( \frac{d_o^4 - d_i^4}{d_o} \right)$ 几何形状符合图M.4,当外径 $r_2$ 已知且 $r_2$ 不小于 $T/2$ , $t/2$ , $(r_p - r_1)/2$ ,或 $(t+y)/2$ 中的最小值时,主管端和支管端平面内、平面外和扭转应力增大系数可用公式计算值乘以0.7。对于图M.4a)、b)、c)执行以下规定。a) 在计算柔性系数和应力增大系数时,使用 $t'/T$ 和 $d'/D$ 分别代替 $t/T$ 和 $d/D$ 。b) 应力增大系数 $i_{\text{ib}}$ 、 $i_{\text{ob}}$ 、 $i_{\text{tb}}$ 和柔性系数 $k_{\text{ib}}$ 、 $k_{\text{ob}}$ 、 $k_{\text{tb}}$ 还需乘以 $(t/t') (d/d')^2$ 。c) 对于图M.4a)、b), $t'$ 计算符合下列规定:1) 当 $L_1 \geqslant 0.5(2r t_n)^{1/2}$ 时 $t'=t_n$ ;2) 当 $L_1 < 0.5(2r t_n)^{1/2}$ 时 $t'=t$ 。d) 对于图M.4c), $t'$ 计算符合下列规定:1) 当 $\theta_n \leqslant 30^\circ$ 时 $t'=t+(2/3)y$ ;2) 当 $\theta_n >30^\circ$ 时 $t'=t+0.385L_1$ 。e) 由下式计算 $d'$ : $d'=d-t+t'$ f) 应力增大系数 $i_{\text{ib}}$ 、 $i_{\text{ob}}$ 、 $i_{\text{ir}}$ 和 $i_{\text{tr}}$ 不小于1.5。j 若 $r_x$ 未知,则 $r_x = 0.05d_o$ ;若 $r_x \geqslant r$ ,则 $r_x = r$ ;当 $t/T < 0.6$ 时,计算柔性系数和应力增大系数时 $t/T = 0.6$ 。k 若 $r/r_p$ 不可得,则 $r/r_p = 0.85$ 。若 $r/r_p < 0.6$ ,则 $r/r_p = 0.6$ 。对于等径支管台,当 $D/T < 40$ , $i_{\text{ob}}$ 可乘以0.75。若焊脚高度及管件实际尺寸已知, $r_p$ 可以取沿主管外表面在纵向平面内从支管中心线到支管台角焊缝趾部的距离;当 $d/D >0.8$ ,支管台几何尺寸因制造商而差异显着,可从制造商处获得更多数据; $D/T < 40$ 的试验结果不能推广到 $D/T >40$ 的支管台。</td><td colspan="2"></td></tr><tr><td colspan="4">满足以下条件时,柔性系数和应力增大系数才可以应用:a)  $5^{\circ}<\alpha<60^{\circ}$ ;b)  $5\( <D_{2}/T_{2}<80$ ;c) 整个异径管壁厚不小于 $T_{1}$ ,小端圆柱部分除外,但其壁厚不小于 $T_{2}$ ;d)  $0.08\( <r_{2}/D_{2}<0.7$ ;e)  $1\( <T_{1}/T_{2}<2.12$ ;f) 若 $L_{2}<(D_{2}T_{2})^{0.5}$ ,应力增大系数需乘以 $[2-L_{2}/(D_{2}T_{2})^{0.5}]$ 。最大应力增大系数不能大于2.0,但也不能小于1.0。对于 $D_{2}/T_{2}\leqslant55$ 的异径管,可以模拟为异径管中间的直径和壁厚,为从 $D_{2},T_{2}$ 到 $D_{1},T_{1}$ 的渐变值,或具有其他更适用的几何形状。对于 $D_{2}/T_{2}>55$ 的异径管,在搭建梁模型时需考虑增加一定柔性,以更准确地表示异径管的刚度;对于偏心异径管,第10项简图中所示的尺寸均取在 $\alpha$ 最大的圆周位置。若 $r_{2}$ 未知,则 $r_{2}=0.1D_{1}$ ;若 $L_{2}$ 未知,则 $L_{2}=0.1D_{2}$ ;若 $\alpha$ 未知,则 $\alpha$ 取 $60(D_{1}/D_{2}-1)$ 或60。m应力增大系数适用于壁厚在0.875T和1.10T之间,轴向距离为 $(D_{o}T)^{0.5}$ 的环向对接焊口, $D_{o}$ 和T分别为公称外径和公称壁厚, $\delta_{avg}$ 是错边量的平均值。n承插焊法兰或管件的填角焊接头的应力增大系数基于以下规定:a) 承插管件和管子符合GB/T 14383,或大于DN50的承插管件、法兰及其他管件满足相应标准的制造要求;b) 焊接满足第13项简图中的要求;c) 管道壁厚大于SCH40或STD中的小值;d) 焊接尺寸 $C_{x}$ 满足相应规范的要求;对于壁厚小于Sch40或Std中的小值的管道,除另有说明外,所有方向的应力增大系数等于2.1;角焊缝采用图M.5 b)和d)所示的凹面角焊缝且焊缝趾部无咬边平滑过渡,可提高焊缝的抗疲劳性能。对于大直径承插焊法兰或平焊法兰,焊角小于相应规范的要求时,可能会产生应力增大系数未计及到的应力。</td></tr></table>

表 M.2 力矩-转角之间的关系

<table><tr><td>力矩(图M.1)</td><td>柔性系数(k)</td><td colspan="2">刚度N·mm/rad</td></tr><tr><td> $M_{i3}$ (支管端)</td><td> $k_{ib}$ </td><td> $M_{ib}/\theta_{ib}$ </td><td> $(E)(I_b)/(k_{ib}d)$ </td></tr><tr><td> $M_{o3}$ (支管端)</td><td> $k_{ob}$ </td><td> $M_{ob}/\theta_{ob}$ </td><td> $(E)(I_b)/(k_{ob}d)$ </td></tr><tr><td> $M_{t3}$ (支管端)</td><td> $k_{tb}$ </td><td> $M_{tb}/\theta_{tb}$ </td><td> $(E)(I_b)/(k_{tb}d)$ </td></tr><tr><td> $M_{i1,2}$ (主管端1,2)</td><td> $k_{ir}$ </td><td> $M_{ir}/\theta_{ir}$ </td><td> $(E)(I_r)/(k_{ir}D)$ </td></tr><tr><td> $M_{o1,2}$ (主管端1,2)</td><td> $k_{or}$ </td><td> $M_{or}/\theta_{or}$ </td><td> $(E)(I_r)/(k_{or}D)$ </td></tr><tr><td> $M_{t1,2}$ (主管端1,2)</td><td> $k_{tr}$ </td><td> $M_{tr}/\theta_{tr}$ </td><td> $(E)(I_r)/(k_{tr}D)$ </td></tr><tr><td colspan="4">注1:表中力矩-转角的关系是针对表M.1中第4项~第9项,是通过将力矩分别独立作用于主管或分支管而得出。模型要适应主管和分支管力矩-转角的相互作用。注2:表中符号见表M.1注8。</td></tr></table>

表 M.3 法兰端部型式修正系数

<table><tr><td>柔性系数</td><td>柔性系数修正系数(c)</td></tr><tr><td> $k_{\text{ib}}$ </td><td> $1-0.032N_{\text{c}}^{1.345}(D/T)^{0.431}(d/D)^{0.903}$ </td></tr><tr><td> $k_{\text{ob}}$ </td><td> $1-0.07N_{\text{c}}^{0.61}(D/T)^{0.44}(d/D)^{0.339}$ </td></tr><tr><td> $k_{\text{tb}}$ </td><td> $1-0.003N_{\text{c}}^{3.962}(D/T)^{0.548}(d/D)^{0.693}$ </td></tr></table>

M.2 三通和弯头平面内和平面外弯矩和扭矩的方向, 见图 M.1。

![](images/de504b93003649e06175a945ad16d795548987fcfcd5be2fe338fc20e344e035.jpg)  
注：图中符号见表 M.1 中注 8。

图M.1 平面内和平面外弯矩和扭矩

M.3 弯头、弯管、斜接弯头或斜接弯管的尺寸系数 h 与柔性系数及应力增大系数的关系，见图 M.2。

![](images/bdcd6f81a5ff50be923e5d1989ba03833d5b4f0e83647e534286011a1fc5d0de.jpg)  
图M.2 尺寸系数与柔性系数和应力增大系数的关系

M.4 修正系数 $C_{\mathrm{f}}$ ，见图M.3。

![](images/03833200850a271005f2ae69970be0190403f1529fb0013f2d1f03d810ba7431.jpg)  
图M.3 修正系数 $C_{\mathrm{f}}$

M.5 支管接头尺寸, 见图 M.4。

![](images/300cf8bf8b69a5d5238dc29eb6558cbd955d7c34b083b5b4d2dbda09252b0fec.jpg)  
注：图中符号见表 M.1 注 8。

图M.4 支管接头尺寸

M.6 角焊尺寸, 见图 M.5。

![](images/11950cf1f2798f4d23b8c5d7955a3c324748a4899e1692fbf469540b94ab79dc.jpg)  
b) 凹性等边角焊

a）凸性等边角焊  
![](images/b3d0ec58e37fcf48ac08c3807f541f6afeb163bcd915ae9ccbbae67922a0888a.jpg)  
c) 凸性不等边角焊

![](images/df382bd712c8ede51a32a1602a01542f0710871bf5b5fc6437602b77d3813a33.jpg)  
d) 凹性不等边角焊  
标引符号说明：

$X_{1}$ 、 $X_{2}$ ——焊脚尺寸。

图M.5 角焊尺寸

M.7 三通主管端和支管端柔性单元的位置, 见图 M.6。

![](images/8687fe531c3aea5abd9fd892818690fc568a9efdbd7af55cd686bb6df1c2cd25.jpg)  
支管柔性单元位置

![](images/8fadf0d4be53e179e50d7af00609f8799be2437617ae3d3858e2f394a0f54eee.jpg)  
图M.6 柔性单元的位置  
主管柔性单元位置

## 附录 N

## （资料性） 管系中阀门开、关时的动载分析

## N.1 阀门快速关闭

N.1.1 如管系有“水锤”现象存在，则需保证该管系中的管道和管道组件能安全地承受正常操作压力加上短时压力的升高值。同时需保证管道具有足够的强度以抵御非平衡力的作用。对压力波造成的管道振动，设计人员也需在管道结构布置时适当加以考虑。

N.1.2 下列方法仅考虑阀门刚关闭时管系中的压力升高，并假定由此产生的管系中的应力是管系所经历的最大应力。该方法未计及压力波对管系产生的振动，其计算结果是偏保守的。按公式(N.1)计算：

a）当满足以下不等式时会出现“水锤”现象：

$$
T <   \frac {2 L}{v _ {\mathrm{s}}}\tag{……( N.1}
$$

式中：

T ——阀门的有效关闭时间,单位为秒(s);

L ——管系的长度,单位为米(m);

$v_{s}$ ——管道中流体的声速,单位为米每秒(m/s),将管道视为完全刚性时,可按公式(N.2)算得:

$$
v _ {\mathrm{s}} = \sqrt {\frac {E _ {\mathrm{o}}}{\rho}} \times 1 0 ^ {3}\tag{N.2}
$$

$E_{0}$ ——流体的体积弹性模量,单位为兆帕(MPa);

ρ ——管道中流体的密度,单位为千克每立方米 $\left(\mathrm{kg}/\mathrm{m}^{3}\right)$ ;

当考虑管道所具有的弹性时, $v_{s}$ 按公式(N.3)计算:

$$
v _ {\mathrm{s}} = \sqrt {\frac {1}{\rho \left(\frac {1}{E _ {\mathrm{o}}} + \frac {D}{T _ {\mathrm{e}} E}\right)}} \times 1 0 ^ {3}\tag{N.3}
$$

D ——管外径, 见 6.6.1.1, 单位为毫米(mm);

$T_{e}$ ——有效壁厚, 见 6.6.1.1, 单位为毫米(mm);

E ——钢管在操作温度下的弹性模量,单位为兆帕(MPa)。

b) 压力升高值 $\Delta p$ ，单位为兆帕(MPa)，可按公式(N.4)计算：

$$
\Delta p = v _ {\mathrm{s}} \cdot v \cdot \rho \times 1 0 ^ {- 6}\tag{N.4}
$$

式中：

v——管道中流体的实际流速,单位为米每秒(m/s)。

c) 对一段直管道, 最大非平衡力 $F(N)$ 可按公式 (N.5)、公式 (N.6) 计算:

对刚性管道：

$$
F = \frac {\pi \cdot D ^ {2} \cdot V _ {\mathrm{m}} \cdot L}{2 \cdot V _ {\mathrm{a}} \cdot \lambda} \cdot \Delta p\tag{……( N.5}
$$

对柔性管道：

$$
F = \frac {\pi \cdot D ^ {2} \cdot V _ {\mathrm{m}} \cdot L}{V _ {\mathrm{a}} \cdot \lambda} \cdot \Delta p\tag{N.6}
$$

式中：

$V_{m}$ ——阀门关闭过程中的最高速率,单位为平方米每秒 $\left(\mathrm{m}^{2}/\mathrm{s}\right)$ ;

$V_{a}$ ——阀门关闭过程中的平均速率，用总关闭时间除阀门面积而得，单位为平方米每秒 $(\mathrm{m}^{2}/\mathrm{s})$ ; $\lambda$ ——压力波的波长[见公式(N.7)]，单位为米(m)。

$$
\lambda = v _ {\mathrm{s}} \cdot T\tag{N.7}
$$

## N.2 泄放阀的打开

当安全泄放阀开启时,气体的排放会对与阀门相连的管道产生一反作用力,该反作用力将对管道的强度有很大的影响。

泄放阀开启的影响可看作是与阀门连接的接管对管道产生的一个局部作用力,设计者需在管道设计和支吊架的布置时考虑这个因素。如在管道或封头上安装有多个泄放阀,则需考虑多个泄放阀开启时的联合影响。

在设计中,考虑泄放阀开启的影响时,可认为管道中的物料向大气中排放,从而采用较简单的静态分析方法,再以一动态荷载系数来计及其动态效应。

向通风管或大气中排放物料时的持续反作用力(N)按公式(N.8)计算：

$$
F _ {\mathrm{r}} = M v _ {\mathrm{e}} + (p _ {\mathrm{e}} - p _ {\mathrm{a}}) A\tag{N.8}
$$

式中：

M ——物料排放时的质量流速,单位为千克每秒(kg/s);

$v_{e}$ ——物料在泄放阀的出口速率,单位为米每秒(m/s);

$p_{e}$ ——泄放阀出口处的压力,单位为兆帕(MPa);

$p_{a}$ ——大气压力,单位为兆帕(MPa);

A ——泄放阀出口处的物料流动面积,单位为平方毫米 $\left(\mathrm{mm}^{2}\right)$ 。

为了计及泄放阀开启瞬间所具有的动态效应,首先按公式(N.9)计算泄放阀的固有周期 $T(\mathrm{s})$ :

$$
T = \frac {2 \pi}{\sqrt {3}} \sqrt {\frac {m _ {\mathrm{v}} \cdot h ^ {3}}{1 0 0 0 \times E J}}\tag{N.9}
$$

式中：

$m_{v}$ ——泄放阀组件(包括法兰等)的质量,单位为千克(kg);

h ——主管表面至出口管中心线的距离(见图 N.1)，单位为毫米(mm)；

J ——泄放阀进口管的惯性矩,单位为四次方毫米 $\left(\mathrm{mm}^{4}\right)$ 。

![](images/7f6b271691dffa2e825cf9548061783dea7b4dcaa2552a4f225cb2ac6736fa43.jpg)

标引符号说明：

$a$ ——反作用力；

b ——阀门出口管的中心线；

c ——阀门的进口管；

d ——主管。

图 N.1 泄放阀的典型布置

然后，用泄放阀实际开启时间 $t$ （从阀门完全关闭到完全打开所用的时间)与泄放阀故有周期 $T$ 之比，从图N.2中查得动态荷载系数 $Z_{\mathrm{dlf}}$ 。

![](images/692183d48b0deded50f9de6af4ca283738cb3f5b5d415d14d3c629e266b0510c.jpg)  
图 N.2 动态荷载系数 $Z_{dlf}$

泄放阀开启瞬间的动态力(N), 可按公式(N.10)计算:

$$
F _ {\mathrm{d}} = F _ {\mathrm{r}} Z _ {\mathrm{dlf}}\tag{N.10}
$$

## 附录O

(资料性)

## 静设备管口许用荷载

## 0.1 概述

本附录给出了设计压力大于 0.1 MPa 且小于 35 MPa 的一般钢制压力容器及管壳式换热器(简称“一般设备”)的管口许用荷载,包括一般设备的接管及其补强板、接管所在处的壳体应能承受的除压力外的力和弯矩。

本附录中的一般设备不包括固定顶罐、浮顶罐、储气罐、料仓、箱形容器等类似设备，接管不包括非法线接管和非圆形接管。

## O.2 设计压力大于 0.1 MPa 且小于 10 MPa 的一般设备

O.2.1 对于半径 $R=1\ 000\ mm$ ，壳体有效厚度 $t=10\ mm$ 的一般设备，所有接管（与管道相连）及其补强板、接管所在处的壳体都需能够承受表 O.1 所列的力和弯矩（方向见图 O.1）。

表 O.1 设计压力大于 0.1 MPa 且小于 10 MPa 的设备管口许用荷载

<table><tr><td>NPS</td><td>P/N</td><td> $T_{L}/N$ </td><td> $T_{C}/N$ </td><td> $M_{L}/(N·m)$ </td><td> $M_{C}/(N·m)$ </td><td> $M_{T}/(N·m)$ </td></tr><tr><td>3&quot;</td><td>1 500</td><td>1 500</td><td>1 500</td><td>600</td><td>600</td><td>600</td></tr><tr><td>4&quot;</td><td>2 100</td><td>2 100</td><td>2 100</td><td>1 100</td><td>1 100</td><td>1 100</td></tr><tr><td>6&quot;</td><td>4 600</td><td>4 600</td><td>4 600</td><td>3 400</td><td>3 400</td><td>3 400</td></tr><tr><td>8&quot;</td><td>6 000</td><td>6 000</td><td>6 000</td><td>5 700</td><td>5 700</td><td>5 700</td></tr><tr><td>10&quot;</td><td>7 600</td><td>7 600</td><td>7 600</td><td>6 900</td><td>6 900</td><td>6 900</td></tr><tr><td>12&quot;</td><td>9 200</td><td>9 200</td><td>9 200</td><td>8 000</td><td>8 000</td><td>8 000</td></tr><tr><td>14&quot;</td><td>10 800</td><td>10 800</td><td>10 800</td><td>9 200</td><td>9 200</td><td>9 200</td></tr><tr><td>16&quot;</td><td>14 600</td><td>14 600</td><td>14 600</td><td>11 300</td><td>11 300</td><td>11 300</td></tr><tr><td>18&quot;</td><td>18 500</td><td>18 500</td><td>18 500</td><td>13 500</td><td>13 500</td><td>13 500</td></tr><tr><td>20&quot;</td><td>22 300</td><td>22 300</td><td>22 300</td><td>15 600</td><td>15 600</td><td>15 600</td></tr><tr><td>24&quot;</td><td>30 000</td><td>30 000</td><td>30 000</td><td>20 000</td><td>20 000</td><td>20 000</td></tr></table>

O.2.2 对于材料为不锈钢的一般设备，表 O.1 所列数值应降至 75%。

O.2.3 对于不同直径和壁厚的一般设备,应对表 O.1 所列数值乘以系数 k 进行修正,k 按公式(O.1)计算:

$$
k = 1. 4 1 4 t ^ {1. 5} / \sqrt {D _ {\mathrm{i}}}\tag{……(0.1}
$$

式中：

k ——修正系数；

t ——接管所在处设备壳体有效厚度,单位为毫米(mm);

$D_{i}$ ——接管所在处设备壳体内径,单位为毫米(mm)。

## O.3 设计压力大于或等于 10 MPa 且小于 35 MPa 的一般设备

此类设备的所有接管(与管道相连)及其补强板、接管所在处的壳体都需能够承受表 O.2 所列的力

和弯矩(方向见图 O.1)。

表 O.2 设计压力大于或等于 10 MPa 且小于 35 MPa 的设备管口许用荷载

<table><tr><td>NPS</td><td> $P/N$ </td><td> $T_{L}/N$ </td><td> $T_{C}/N$ </td><td> $M_{L}/(N·m)$ </td><td> $M_{C}/(N·m)$ </td><td> $M_{T}/(N·m)$ </td></tr><tr><td>2&quot;</td><td>2 260</td><td>1 040</td><td>1 040</td><td>1 060</td><td>1 060</td><td>1 060</td></tr><tr><td>12-1/2&quot;</td><td>3 130</td><td>1 440</td><td>1 440</td><td>1 470</td><td>1 470</td><td>1 470</td></tr><tr><td>3&quot;</td><td>3 980</td><td>1 840</td><td>1 840</td><td>1 870</td><td>1 870</td><td>1 870</td></tr><tr><td>4&quot;</td><td>6 100</td><td>2 820</td><td>2 820</td><td>2 860</td><td>2 860</td><td>2 860</td></tr><tr><td>6&quot;</td><td>12 460</td><td>5 730</td><td>5 730</td><td>5 820</td><td>5 820</td><td>5 820</td></tr><tr><td>8&quot;</td><td>22 070</td><td>10 200</td><td>10 200</td><td>10 400</td><td>10 400</td><td>10 400</td></tr><tr><td>10&quot;</td><td>35 810</td><td>16 480</td><td>16 480</td><td>16 780</td><td>16 780</td><td>16 780</td></tr><tr><td>12&quot;</td><td>54 250</td><td>25 020</td><td>25 020</td><td>25 410</td><td>25 410</td><td>25 410</td></tr><tr><td>14&quot;</td><td>71 020</td><td>32 770</td><td>32 770</td><td>33 350</td><td>33 350</td><td>33 350</td></tr><tr><td>16&quot;</td><td>99 080</td><td>45 810</td><td>45 810</td><td>46 500</td><td>46 500</td><td>46 500</td></tr><tr><td>18&quot;</td><td>134 400</td><td>61 800</td><td>61 800</td><td>62 780</td><td>62 780</td><td>62 780</td></tr><tr><td>20&quot;</td><td>175 600</td><td>81 230</td><td>81 230</td><td>82 500</td><td>82 500</td><td>82 500</td></tr><tr><td>24&quot;</td><td>284 490</td><td>131 450</td><td>131 450</td><td>133 420</td><td>133 420</td><td>133 420</td></tr><tr><td>24&quot;以上</td><td> $882.5×10^{-6}D^{3}$ </td><td> $407.3×10^{-6}D^{3}$ </td><td> $407.3×10^{-6}D^{3}$ </td><td> $413.8×10^{-6}D^{3}$ </td><td> $413.8×10^{-6}D^{3}$ </td><td> $413.8×10^{-6}D^{3}$ </td></tr></table>

表 O.2 中的 D 按公式(O.2)进行计算：

$$
D = D _ {\mathrm{o}} + 7 6. 2
$$

……(0.2)

式中：

$D_{0}$ ——接管外径,单位为毫米(mm)。

![](images/3a05f667c3c5561ca0333f75fad2ee744bc7c863d965b4150e5f92327dc23461.jpg)  
图 0.1 设备管口承受的力和力矩方向

# 附录 P

(规范性)

# 金属波纹膨胀节

## P.1 基本要求

本附录规定了压力管道中的膨胀节设计、制造和安装的一般要求和设计计算的标准。膨胀节所有组件的详细设计应由制造商负责。

## P.2 对管道设计者的要求

## P.2.1 通则

管道设计者应提供膨胀节详细设计的设计工况以及对设置膨胀节的管道设计要求。设计者应结合合金元素的含量、制造方法和最终热处理条件来确定材料产生应力腐蚀裂纹的敏感性。

除膨胀节中流动介质的性能外,设计者还应确定其外部环境和由于波纹管在低温下操作,可能在其外壁产生冷凝或结冰。

宜给出波纹管的单层最小厚度。

应确认膨胀节检修维护的可达性。

需要从膨胀节制造商处获得的数据至少包括：

a）有效的承受轴向内压的面积；

b) 横向、轴向和扭转刚度；

c) 特定设计条件下的设计疲劳寿命；

d) 安装长度和质量；

e）在管道上附加支撑或约束的要求；

f) 材料合格证明；

g）最大试验压力；

h）设计计算书；

i) 总装配图。

## P.2.2 膨胀节设计条件

管道设计提出的膨胀节设计条件包括：

a）静态设计条件

本条件应包括正常操作状态下的压力、温度以及可能出现的压力、温度的波动上、下限。如果所给出的膨胀节组件设计温度不是介质温度，则该温度应通过适当的换热计算方法或试验的方法来核实，或通过对在同样条件下服役的相同设备的测量来获得。

## b) 循环设计条件

本条件应包括操作期内同时作用的压力、温度、所施加的端点位移、膨胀节本身的热膨胀所对应的循环数。

由短时工况引起的循环数(如开车、停车和非正常操作)应单独说明,并应叠加累积疲劳效应。

## c) 其他荷载

除以上条件之外的其他荷载也需说明，包括动力荷载(如风荷载、地震荷载、热冲击、振动等)和重力荷载(如绝热材料、雪、冰等产生的重力荷载)。

## d) 流体特性

同设计要求相关的流体介质特性应在设计条件中指定。如建设单位(使用单位)指定的介质类型、流体速率和方向、内部衬里等。

## e) 其他设计条件

影响膨胀节设计的其他条件应在设计条件中说明。如保护套的使用，内、外隔热层，限位装置，其他约束，膨胀节上的外加接管(如排气和排液管)等。

## P.2.3 管道设计要求

在进行管道布置、固定点位置和约束、导向件、支承件设计时，需避免在膨胀节上施加非预定的位移和力。例如，膨胀节通常不能抵抗扭矩。如膨胀节无自约束装置，管道上的固定和导向支承需能承受膨胀节的内压推力及柱失稳(由于管内流体压力)产生的荷载。

固定支吊架设计要求如下：

## a）主固定架

主固定架应能承受 P.2.2 中 b) 所列的力和力矩以及压力所产生的推力，该推力等于膨胀节上承受轴向压力的有效面积乘以最大工作压力。对于在压力试验时无附加约束的膨胀节，应计及试验期间由试验压力所产生的推力比正常操作时的推力大，主固定架应能承受该推力。

膨胀节上承受轴向压力的有效面积应由制造商推荐。当无资料时，该面积可根据波纹的中径计算而得。

## b) 中间固定架

中间固定架应能承受以下的力和力矩：

1）约束膨胀节发生压缩、伸长、偏移或转动（由计算得到的位移、转角产生）时所需要的力或力矩；

2）管道在最大伸缩位置间移动时，其支承上所产生的静摩擦力(计算位移是基于固定架和膨胀节之间的管道长度)；

3）流动介质所产生的操作荷载和瞬时动态荷载；

4）其他的管道力和力矩。

## P.3 对膨胀节制造商的要求

## P.3.1 制造总则

膨胀节制造商应根据本部分及工程设计要求进行膨胀节的详细设计以及整个膨胀节部件的制造和检验等,包括:

a）膨胀节装配件所包括的管子、法兰、管件、连接件、波纹管、管道的支承件或约束件等；

b) 对膨胀节装配件以外需外加的支承件和约束件及其设计数据；

c) 对那些与膨胀节一起提供,而与操作介质不接触的零部件确定其设计条件;

d）向管道设计者提供膨胀节的性能参数，如膨胀节的刚度、质量等；

e) 随产品附安装说明书。

## P.3.2 膨胀节设计

膨胀节的设计符合下列规定。

a）膨胀节的设计计算应符合 GB/T 12777 的规定。

b）在失稳压力下的安全系数不小于2.25，在极限断裂压力下的安全系数不小于3.00。

c) 按标准 GB/T 12777 计算波形膨胀节的应力时，应采用 6.2.4 规定的材料许用应力值来判定所设计的膨胀节的强度。同时，应采用第 5 章及其有关附录所规定的弹性模量值计算膨胀节的

刚度和补偿量。

d）约束压力推力的结构件材料亦应符合第5章的相关规定。

e) 由设计压力在波纹管、波纹管直边段和加强环中产生的环向膜应力及在波纹管中产生的子午向膜应力(包括紧固件中的拉应力)应不超过表 B.1 给出的许用应力。非表列材料的许用应力值按 6.2.4 的规定来确定。

f) 成型后退火的非加强型波纹管，在波纹管的子午向膜应力与弯曲应力之和应不超过表 B.1 许用应力的 1.5 倍。

g) 自约束型膨胀节的约束件(如拉杆、铰链、销轴等)和约束于管子或法兰的连接件中的应力应计算,其拉伸应力、压缩应力、挤压应力和剪切应力应不超过6.2.4所述的许用应力极限。约束件附着在管道上的情况,局部应力可使用GB/T 4732(所有部分)的准则进行评定。

h）管段、管件和法兰的压力设计应符合6.3、6.4、6.5和6.6的要求。

i) 疲劳分析应计及所有的设计循环工况，并应给出设计疲劳寿命的计算报告。

j) 波纹管组件的操作温度在蠕变范围内时，应计及蠕变—疲劳相互作用的有害影响。

k）设计温度低于 $425^{\circ}\mathrm{C}$ 的成型态奥氏体不锈钢波纹管设计疲劳寿命按GB/T12777的方法计算。

## P.3.3 膨胀节的制造、检验和压力试验

## P.3.3.1 制造技术方案

在管道系统中设置膨胀节时，确保管道系统中安装的膨胀节具有足够的静载强度和疲劳强度。膨胀节的制造商应制定合适的制造技术方案，这些技术方案应包括P.3.3.2～P.3.3.4所述的内容。

## P.3.3.2 制造

为使膨胀节能满足相连管道的位移补偿要求,可考虑采用与管道不同的材料来制造膨胀节,但应保证膨胀节与管道的焊接质量。膨胀节的焊接满足以下要求。

a）应由取得资格的合格焊工或焊机操作工使用已评定的焊接工艺进行焊接操作；焊接工艺评定应符合NB/T47014的要求。

b) 膨胀节应采用整体液压成型的制造工艺,且仅可采用纵向焊接接头。

c) 波纹管上的纵向焊缝应全焊透。在波纹管成型前，焊缝厚度应不小于波纹管材料名义厚度的1.0倍，且不大于1.1倍。

d) 全角焊缝可用作波纹管组件与相邻管道组件的主焊缝。

e) 制造波纹管的管坯不应使用搭接焊。

f) 焊后热处理应符合以下规定：

1）当波纹管与管道组成件直接焊接，且管道组件材料类别为 Fe-4、Fe-5A、Fe-5B 时，该焊缝应按 7.6 的规定进行热处理，不应采用其免除热处理的规定；

2）当确认热处理对波纹管的性能有害时，波纹管不应直接与管道组成件焊接，管道组成件的焊缝坡口边应使用适当的填充金属堆焊隔离层，并符合NB/T47014的规定，堆焊隔离层的焊件应经热处理后再与波纹管焊接；

3）热处理的恒温时间应由管道组成件的厚度确定；

4）焊缝的检测应在热处理后进行。

## P.3.3.3 检验

以下是控制焊接质量的最低检验要求。

a）焊缝检验应符合第8章的要求。

b) 在波纹管成型前，纵焊缝应进行 100% 射线检测；如波纹管名义厚度小于或等于 2.4 mm，可采用单面焊，且应在内、外表面进行渗透检测代替射线检测；波纹管的纵向焊接接头质量系数取 1.0。

c) 波纹管成型后, 可及的内、外表面焊缝均应进行渗透检测; 波纹管与管道连接的环焊缝等也应进行 100% 渗透检测。

d) 射线检测结果的判定应符合 8.3.3.2.2 对纵缝的要求。渗透检测结果的判定标准是不存在有裂纹、咬边和未焊透。

## P.3.3.4 压力试验

膨胀节的压力试验符合下列规定。

a）制造商应按8.6的规定对每一个膨胀节进行压力试验，试验压力应按8.6.1.3和8.6.1.4确定，公式(55)中的 $S_{1}, S_{2}$ 宜按膨胀节所在管道的管道材料选取，试验压力至少应保持 $10\mathrm{min}$ 。

b) 能抵抗压力推力的膨胀节，在压力试验时，不应提供外加的轴向约束。如有必要，可施加模拟管道刚度的暂时约束。

c) 在压力试验时，除要检查泄漏和结构总体强度外，还应在压力试验前、压力试验时和压力试验后确认无波纹管屈曲现象。在进行内压的压力试验时，初始状态为对称的波纹管会发生变形，该变形可导致波纹管之间不平行或波纹管波距不一致，这时就认为屈曲已经产生。不准许出现以下情形的变形：

1）对于无加强的膨胀节，最大的波距与受压前的波距之比大于1.15；

2）对于有加强的膨胀节，最大的波距与受压前的波距之比大于1.20。对泄漏和变形的检测应在 $100\%$ 试验压力达到后、不低于2/3试验压力下进行。

d) 对于屈曲的检查应在最大试验压力时进行。为了安全，可在临时安装有参考尺寸的隔间通过远距离观察(通过望远镜或录像等)进行检查。泄漏检查应在 $100\%$ 试验压力到达之后且不低于2/3试验压力下进行。气压试验应遵照8.6.1.4的规定。

## P.4 安装

膨胀节的安装符合下列规定：

a）膨胀节安装时应使导流标志方向与介质流向一致；

b) 不应利用膨胀节的变形来调整或弥补管道的安装偏差；

c) 安装时需避免波纹管产生划痕、焊弧、焊接飞溅或凹陷等缺陷；

d) 膨胀节吊装时,不应将任何提升装置直接作用在波纹管或波纹管的外保护罩上,在吊装过程中,应避免波纹管和法兰密封面受到机械损伤;

e) 在所有导向支架和固定支架被正确安装完毕前,不应进行压力试验或对其抽真空;

f) 管道的固定支架安装完毕，并且管道得到正确的支承和导向，膨胀节上的运输固定装置应拆除，使膨胀节在以后的过程中随环境温度的变化进行补偿；

g）膨胀节安装除上述要求外，还应满足制造商的安装说明书的要求。

## 附录 Q

## （资料性） 位移载荷高循环作用下管道系统的疲劳分析

## Q.1 概述

本附录提供的方法适用于各种位移交变载荷产生的重要应力循环且总循环数超过 100 000 次时的管道系统的疲劳分析。对应用于非腐蚀环境的管道系统中的铁素体钢和奥氏体不锈钢部件，重要应力循环是指按 6.7.5.5 计算得到的位移应力范围超过 20.7 MPa 的应力循环。对于其他材料或应用于腐蚀环境的管道部件，所有位移交变载荷产生的应力循环均为重要应力循环，否则，需在设计文件中予以特别标示。

应用本附录的方法应获得建设单位(使用单位)的认可,并详细记录应用该方法时的数据和步骤。

本附录所提供的方法对于管道系统所承受的压力波动以及由此产生的效应没有考虑，但其引起的管道系统中各受压组件的应力循环而可能产生的疲劳失效在设计和制造中应予以考虑。当需要考虑压力波动引起的管道以及管道组件中的应力循环而进行疲劳强度评定时，可采用 GB/T 4732（所有部分）中所提供的疲劳分析方法。

无论是采用本附录的方法或 GB/T 4732(所有部分)的方法对管道系统进行疲劳分析和评定，均不能免除 6.7.5.5 对管道位移应力范围的强度校核，并在使用 6.7.5.5 中方法进行位移应力范围校核时，系数 f 应取 1.0。如使用本附录方法进行疲劳分析与校核，则按 6.7.5.5 中方法计算得到的 $S_{E}$ 应不大于公式(34)所确定的值 $S_{A}$ 。

## Q.2 符号

下列符号适用于本附录：

CF ——焊接接头疲劳曲线系数, 见表 Q.1;

$d_{t}$ ——定值热应力幅引起的疲劳损伤系数；

E ——操作温度下的弹性模量,单位为兆帕(MPa);

$E_{CSA}$ ——碳钢在常温(21℃)下的弹性模量,单位为兆帕(MPa);

$f_{E}$ ——环境因素修正系数；

$f_{1}$ ——焊接接头疲劳性能改善系数；

$f_{M,k}$ ——应力比修正系数；

$f_{t}$ ——材料和温度修正系数；

k ——疲劳强度壁厚指数,见表 Q.1;

m ——焊接接头疲劳曲线指数；

$N_{i}$ ——对应于载荷或应力循环 i 的循环次数；

$N_{ti}$ ——对应于载荷或应力循环 i 的许用循环次数；

q ——计算 $f_{1}$ 的指数；

$S_{Ei}$ ——对应于载荷或应力循环 i 的位移应力范围, 单位为兆帕(MPa);

$\sigma_{i,\max}$ ——对应于载荷或应力循环 i 计算得到的最大位移应力, 单位为兆帕(MPa);

$\sigma_{i,\min}$ ——对应于载荷或应力循环 i 计算得到的最小位移应力, 单位为兆帕(MPa);

$S_{yi}$ ——对应于载荷或应力循环 i，部件材料的屈服强度，单位为兆帕(MPa)；

$T_{E}$ ——部件在焊接接头处的有效厚度,单位为毫米(mm);

$\overline{T}$ ——部件在焊接接头处的名义厚度,单位为毫米(mm)。

## Q.3 设计步骤

Q.3.1 按建设单位(使用单位)或工艺计算确定的设计数据表建立包括所有位移载荷的 Load(载荷)-t (时间)坐标系[或确定管道系统中需要进行疲劳分析的危险点,在各点建立 S(应力)-t(时间)坐标系]。

Q.3.2 针对需进行疲劳分析的危险点,按载荷循环计算应力范围及其对应的循环次数。对于主应力方向恒定的场合可按以下方法进行。

a）对应每一工况中循环 i 的位移载荷，按 6.7.5.5 计算各位移应力峰值 $\sigma_{pi}$ 和位移应力谷值 $\sigma_{vj}$ ，并在坐标系中标记计算得到的应力值以及其对应发生的时间节点 $t_{i}$ 和 $t_{j}$ ，如图 Q.1。

b) 选取最大的应力峰值和最小的应力谷值, 计算该两应力的差值的绝对值 $S_{Ei} = \left| \sigma^{m} - \sigma^{n} \right|$ 。

注：对于非腐蚀环境的管道系统中的铁素体钢和奥氏体不锈钢部件，如计算得到的 $S_{Ei}$ 小于 20.7 MPa 的应力循环可不计入需进行疲劳分析的循环次数。

c) 删除时间点 $t_{m}$ 、 $t_{n}$ 以及对应的 $\sigma^{m}$ 、 $\sigma^{n}$ ，检查该工况中仍存在应力峰值或谷值，如有，返回 b); 如已没有应力峰值和应力谷值，则进入 Q.3.3。

![](images/2475b8f9d80e61fcf36fabd48101834e0f65ae7fb95ef0da81a9e116a0f71450.jpg)  
图 Q.1 应力循环次数的计数方法

Q.3.3 统计具有应力变化范围 $S_{Ei}$ 的循环次数 $N_{i}$ 。

Q.3.4 确定以下各计算系数的值：

a）焊接接头疲劳性能改善系数 $f_{1}$ 一般可取 1.0，但如对焊缝表面进行处理后也可按以下公式取值：

1）表面打磨：

$$
f _ {\mathrm{I}} = 1. 0 + 2. 5 \times 1 0 ^ {q}\tag{……(Q.1}
$$

$$
q = 0. 0 0 1 6 \cdot (S _ {\mathrm{E} i} \cdot T _ {\mathrm{E}} ^ {\mathrm{k}}) ^ {1. 6}\tag{……(Q.2}
$$

2）表面锤击平整成形：

$$
f _ {\mathrm{I}} = 1. 0 + 4. 0 \times 1 0 ^ {q}\tag{……(Q.3}
$$

b) 对于设计温度不超过 $93^{\circ}$ C 的碳钢钢管，环境因素修正系数 $f_{E}$ 可取为 1.0；对于其他材料或温度， $f_{E}$ 可取为 4.0。 $f_{E}$ 也可按设计文件规定取值。

c) 系数 CF、m、k 按表 Q.1 取值；但如由建设单位（使用单位）确认，并在设计文件中注明，则也可按表 Q.2 取值。表 Q.1 和表 Q.2 中数值的最高适用温度对碳素钢为 $371^{\circ}C$ ，对奥氏体不锈钢为 $427^{\circ}C$ ，对铝为 $204^{\circ}C$ 。对于设计温度超过以上规定或使用了其他材料，各系数的值由建设单位（使用单位）和设计者商定，并在设计文件中注明。

表 Q.1 材料系数 $(-3\sigma)$

<table><tr><td>材料</td><td>CF</td><td>m</td><td>k</td></tr><tr><td>铁素体钢、奥氏体不锈钢</td><td>14 137</td><td>3.13</td><td>0.222</td></tr><tr><td>铝、铝合金</td><td>2 303</td><td>3.61</td><td>0.222</td></tr></table>

表 Q.2 材料系数 $(-2\sigma)$

<table><tr><td>材料</td><td>CF</td><td>m</td><td>k</td></tr><tr><td>铁素体钢、奥氏体不锈钢</td><td>16 942</td><td>3.13</td><td>0.222</td></tr><tr><td>铝、铝合金</td><td>2 828</td><td>3.61</td><td>0.222</td></tr></table>

d) 应力比修正系数 $f_{M,k}$ 按公式(Q.4)取值：

$$
f _ {\mathrm{M}, \mathrm{k}} = \left\{ \begin{array}{l l} 1. 0, & (\sigma_ {i, \max} + \sigma_ {i, \min}) \leqslant S _ {\mathrm{yi}} \\ \left(1 - \frac {\sigma_ {i , \min}}{\sigma_ {i , \max}}\right) ^ {0. 2 7 7 8}, & (\sigma_ {i, \max} + \sigma_ {i, \min}) > S _ {\mathrm{yi}} \end{array} \right.\tag{……(Q.4}
$$

e) 材料和温度修正系数 $f_{t}=E/E_{CSA}$ ;

f) 部件的有效厚度 $T_{E}$ 按公式(Q.5)取值：

$$
T _ {\mathrm{E}} = \left\{ \begin{array}{l} 1 6, \overline {{T}} \leqslant 1 6 \mathrm{mm} \\ \overline {{T}}, 1 6 \mathrm{mm} <   \overline {{T}} <   1 5 0 \mathrm{mm} \\ 1 5 0, \overline {{T}} \geqslant 1 5 0 \mathrm{mm} \end{array} \right.\tag{……(Q.5}
$$

Q.3.5 对载荷或应力循环 i 计算许用循环次数 $N_{ti}$ 按公式(Q.6)计算：

$$
N _ {t i} = \frac {f _ {\mathrm{I}}}{f _ {\mathrm{E}}} \left(\frac {C F \cdot f _ {\mathrm{M} , \mathrm{k}} \cdot f _ {\mathrm{t}}}{S _ {\mathrm{Ei}} \cdot T _ {\mathrm{E}} ^ {\mathrm{k}}}\right) ^ {m}\tag{……( Q.6}
$$

Q.3.6 重复步骤 Q.3.2～Q.3.5，直至所有载荷或应力循环的许用循环次数 $N_{ti}$ 都已求得，然后，计算疲劳损伤系数 $d_{t}$ [按公式(Q.7)]：

$$
d _ {\mathrm{t}} = \sum \frac {N _ {i}}{N _ {\mathrm{ti}}}\tag{……(Q.7}
$$

该疲劳损伤系数 $d_{t}$ 不大于 1.0。如 $d_{t} > 1.0$ ，表示该危险点疲劳强度不合格。

Q.3.7 针对每一可能发生疲劳失效的危险点重复步骤 Q.3.2～Q.3.6 完成管道系统的疲劳分析。

## 附录 R

(资料性)

局部焊后热处理的温度控制范围、热电偶设置及隔热

## R.1 局部焊后热处理的温度控制范围

R.1.1 管道焊后热处理的温度控制范围

R.1.1.1 管道焊后热处理的温度控制范围包括均温带、加热带和隔热带(见图 R.1～图 R.4)。

![](images/9a49711d438f9d9ccce0b85f98725fc4de5791ae18e16ea4c97edf69ef7d5a2a.jpg)  
标引符号说明：  
W——焊缝宽度；SB——均温带宽度；HB——加热带宽度；GCB——隔热带宽度。

图 R.1 管道对接环缝的焊后热处理的温度控制带示意图  
![](images/b572927c80556063bc1e987159118b9b9dd6abe3291ffc09c20a58a175abe4fd.jpg)  
标引符号说明：  
$W_{b}$ ——支管连接焊缝的宽度； $SB_{b}$ ——支管均温带宽度； $HB_{b}$ ——支管加热带宽度； $GCB_{b}$ ——支管隔热带宽度；SB——均温带宽度；HB——加热带宽度；GCB——隔热带宽度。

图R.2 管道支管连接的焊后热处理的温度控制带示意图

![](images/97c22f1d906bc46ed0e77bb9de15a53ecdc612a063148d0f2bbe283a9c6bf4c1.jpg)  
标引符号说明：

$W_{n}$ ——管嘴连接焊缝的宽度；SB——均温带宽度； $SB_{n}$ ——管嘴上的均温带宽度； $L、L_{n}$ ——温度可能下降到均温带边缘温度一半时的最小距离；HB——加热带宽度； $HB_{n}$ ——管嘴上的加热带宽度；GCB——隔热带宽度； $GCB_{n}$ ——管嘴隔热带宽度；t——管道公称厚度； $t_{n}$ ——管嘴颈的公称厚度；R——主管管内半径； $R_{n}$ ——接管内半径。

图R.3 管嘴与管道连接焊缝的焊后热处理的温度控制带示意图

![](images/4fd969dfce40c7984d60feaf9a103884b59c417c43e5340ffcb2a27716944be4.jpg)

标引符号说明：

$W_{a}$ ——非承压件连接焊缝的宽度；SB——均温带宽度； $SB_{a}$ ——非承压件的均温带宽度；L——温度可能下降到均温带边缘温度一半时的最小距离；HB——加热带宽度； $HB_{a}$ ——非承压件上的加热带宽度；GCB——隔热带宽度； $GCB_{a}$ ——非承压件隔热带宽度；t——管道公称厚度； $t_{a}$ ——非承压件的公称厚度；R——主管管内半径。

## 图R.4 非承压件与管道连接焊缝的焊后热处理的温度控制带示意图

R.1.1.2 均温带指焊件达到规定温度的体积范围在其表面的区域，包括焊缝区、熔合区、热影响区及其相邻母材。均温带所示体积范围内任意一点温度均需要符合焊后热处理的规定，均温带宽度不小于3倍的环缝焊接处的最大壁厚。对于支管连接、管嘴或非承压件与管道连接的焊缝，均温带的宽度需从焊缝边缘各向外延伸不小于2倍的主管厚度。

R.1.1.3 加热带指为保证焊件获得规定的均温体积范围而实施加热的区域。加热带环绕包括均温带在内的主管及支管(管嘴或非承压件)的管道焊缝全圆周，并保证均温带所示体积范围的温度值。如不产生有害的温度梯度，在离开均温带较远处，可减少加热带的宽度或降低其温度。推荐的加热带宽度为下列三者中的较大者：

a）最小均温带宽度加 50 mm，即 SB+50 mm；

b) $SB + 4\sqrt{Rt}$ ;

$$
\frac {H _ {\mathrm{i}} \left[ \frac {D ^ {2} - d ^ {2}}{2} + (D) (\mathrm{SB}) \right]}{D} 。
$$

式中：

t ——管壁(主管、支管)厚度,单位为毫米(mm);

R ——管子(主管、支管)半径,单位为毫米(mm);

D ——管子(主管、支管)外径,单位为毫米(mm);

d ——管子(主管、支管)内径,单位为毫米(mm);

$H_{i}$ ——系数,按下列情况取值:

——对于小于或等于 DN150 的水平位置管道使用 1 个周向控制区, $H_{i}=5$ ;

——对于小于或等于 DN150 的水平位置管道使用 2 个周向控制区, $H_{i}=3$ ;

——对于大于 DN150 的水平位置管道且至少使用 2 个周向控制区, $H_{i}=3$ ;

——对于所有垂直位置的管道, $H_{i}=3$ 。

R.1.1.4 隔热带指为防止焊件均温范围和加热范围散热而在其表面铺设绝热材料的区域。隔热带需保证热能效率，并防止产生有害的温度梯度。最小隔热带宽度(GCB)推荐为 $HB+4\sqrt{Rt}$ 。

## R.1.2 加热带的温度

加热、保温和冷却期间，加热带边缘的温度不低于均温带边缘温度的一半。

## R.1.3 加热装置的布置

加热装置沿焊缝方向布置。对于水平位置的管道，加热装置中心需正对焊缝中心；对于垂直位置的管道，放置加热装置时需考虑焊缝中心以下部分温度较低的影响。

## R.2 热电偶设置

R.2.1 垂直位置的管道焊接接头进行局部焊后热处理时，需使用不少于2支热电偶，沿圆周均匀布置。其中，焊缝中心设置不少于1只温控热电偶，均温带边缘设置监控热电偶。

R.2.2 水平位置管道焊接接头进行局部焊后热处理时，需根据管道外径采取与分区加热相应的测温、控温方式安装热电偶，分区数量与热电偶的安装要求见表 R.1。每个温控区焊缝中心需设置不少于1只温控热电偶，均温带边缘设置监控热电偶。

表 R.1 水平位置管道焊后热处理时分区数量与控温热电偶的安装要求

<table><tr><td>管道公称直径mm</td><td>分区控温数量</td><td>周向上控温热电偶位置</td><td>说明</td></tr><tr><td> $\leqslant 250$ </td><td>1</td><td>12:00位置</td><td>适用于所有钢材</td></tr><tr><td> $250 < D \leqslant 500^a$ </td><td>2</td><td>12:00、6:00位置</td><td>适用于所有钢材</td></tr><tr><td> $500 < D \leqslant 750$ </td><td>3</td><td>12:00、4:00、8:00位置</td><td>适用于高合金钢</td></tr><tr><td>D&gt;750</td><td>4</td><td>12:00、3:00、6:00、9:00位置</td><td>适用于高合金钢</td></tr><tr><td colspan="4"> $^a$ 对于碳钢、低合金钢,管道外径上限不限。</td></tr></table>

R.2.3 异形焊接接头(如支管、管嘴、非承压件等)进行焊后热处理时,需采取措施使得焊件实际被加热的最高温度位于被热处理焊缝上。焊后热处理时,在焊缝中心设置不少于1只温控热电偶,在主管与支管上的均温带边缘设置监测热电偶。

R.2.4 必要时,可在加热带的边缘增设监测热电偶,以监测焊件的轴向温度梯度。条件允许的情况下可在管道内表面设置监测热电偶,以确保整个厚度上达到所需热处理温度。

## R.3 隔热

R.3.1 隔热层材料能在焊后热处理温度和保温时间内保持原有性能,不降低保温效果。保温厚度需根

据绝热材料的特性确定,一般不小于60 mm,隔热层外表面温度不高于60 ℃。

R.3.2 保温材料用整片包覆。当无法避免拼接时，相邻两块保温材料搭接宽度不大于 100 mm；多层铺设时，每两层之间的接缝需错开。

R.3.3 根据需要,可通过改变保温层厚度来调整管道加热部分不同区域的温差。

# 附录 S

(资料性)

## 管道封闭口装配错口偏差评估方法

## S.1 概述

本附录给出了对管道封闭口装配的错口偏差进行定量评估的基本方法，用于管道系统的首次安装，也用于管道的常规维护。

本附录基于封闭口两端管道的柔度，对管道封闭口错口偏差进行评估。

## S.2 管道错口偏差评估方法

S.2.1 应变敏感性管道最终封闭口的装配允许值见表 S.1，适用于与泵机、小型透平机、压缩机等传动机械，以及与需要进行管道应力分析的容器和储罐的接管相连接的管道系统。非应变敏感性管道最终封闭口的装配允许值见表 S.2。

S.2.2 管道封闭点安装时,如果横向和轴向的自由管段长度大于表 S.1 或表 S.2 给出的最小装配管道长度,则允许通过冷拉调整的方法进行对口。否则,该管道需重新装配或进行技术评估。

表 S.1 应变敏感管道的允许错口值

<table><tr><td rowspan="3">公称直径mm</td><td colspan="15">管道组对时的允许错口值mm</td></tr><tr><td>2.5</td><td>5</td><td>7.5</td><td>10</td><td>12.5</td><td>15</td><td>17.5</td><td>20</td><td>22.5</td><td>25</td><td>30</td><td>35</td><td>40</td><td>45</td><td>50</td></tr><tr><td colspan="15">应变敏感管道的最小管道总长m</td></tr><tr><td>15</td><td>1.7</td><td>2.4</td><td>2.9</td><td>3.4</td><td>3.7</td><td>4.1</td><td>4.4</td><td>4.8</td><td>5.0</td><td>5.3</td><td>5.8</td><td>6.3</td><td>6.7</td><td>7.1</td><td>7.5</td></tr><tr><td>20</td><td>1.9</td><td>2.7</td><td>3.2</td><td>3.7</td><td>4.2</td><td>4.6</td><td>5.0</td><td>5.3</td><td>5.6</td><td>5.9</td><td>6.5</td><td>7.0</td><td>7.5</td><td>8.0</td><td>8.4</td></tr><tr><td>25</td><td>2.1</td><td>3.0</td><td>3.6</td><td>4.2</td><td>4.7</td><td>5.2</td><td>5.5</td><td>5.9</td><td>6.3</td><td>6.6</td><td>7.3</td><td>7.8</td><td>8.4</td><td>8.9</td><td>9.4</td></tr><tr><td>40</td><td>2.5</td><td>3.6</td><td>4.4</td><td>5.0</td><td>5.6</td><td>6.2</td><td>6.7</td><td>7.1</td><td>7.6</td><td>8.0</td><td>8.7</td><td>9.4</td><td>10.1</td><td>10.7</td><td>11.3</td></tr><tr><td>50</td><td>2.8</td><td>3.1</td><td>4.9</td><td>5.6</td><td>6.3</td><td>6.9</td><td>7.5</td><td>8.0</td><td>8.4</td><td>8.9</td><td>9.8</td><td>10.5</td><td>11.3</td><td>11.9</td><td>12.6</td></tr><tr><td>65</td><td>3.1</td><td>4.4</td><td>5.4</td><td>6.2</td><td>6.9</td><td>7.6</td><td>8.2</td><td>8.8</td><td>9.3</td><td>9.8</td><td>10.7</td><td>11.6</td><td>12.4</td><td>13.2</td><td>13.9</td></tr><tr><td>75</td><td>3.4</td><td>4.8</td><td>5.9</td><td>7.1</td><td>7.7</td><td>8.4</td><td>9.1</td><td>9.7</td><td>10.3</td><td>10.8</td><td>11.9</td><td>12.8</td><td>13.7</td><td>14.5</td><td>15.3</td></tr><tr><td>100</td><td>3.9</td><td>5.5</td><td>6.7</td><td>7.8</td><td>8.7</td><td>9.5</td><td>10.3</td><td>11.0</td><td>11.6</td><td>12.3</td><td>13.4</td><td>14.5</td><td>15.5</td><td>16.5</td><td>17.3</td></tr><tr><td>150</td><td>4.7</td><td>6.6</td><td>8.1</td><td>9.4</td><td>10.5</td><td>11.5</td><td>12.5</td><td>13.3</td><td>14.1</td><td>14.9</td><td>16.3</td><td>17.6</td><td>18.8</td><td>20.0</td><td>21.1</td></tr><tr><td>200</td><td>5.4</td><td>7.6</td><td>9.3</td><td>10.7</td><td>12.1</td><td>13.2</td><td>14.2</td><td>15.2</td><td>16.1</td><td>17.0</td><td>18.6</td><td>20.1</td><td>21.5</td><td>22.8</td><td>24.0</td></tr><tr><td>250</td><td>6.0</td><td>8.5</td><td>10.4</td><td>12.0</td><td>13.4</td><td>14.7</td><td>15.8</td><td>16.9</td><td>18.0</td><td>19.0</td><td>20.8</td><td>22.4</td><td>24.0</td><td>25.5</td><td>26.8</td></tr><tr><td>300</td><td>6.5</td><td>9.2</td><td>11.3</td><td>13.0</td><td>14.6</td><td>16.0</td><td>17.3</td><td>18.5</td><td>19.6</td><td>20.6</td><td>22.6</td><td>24.4</td><td>26.1</td><td>27.7</td><td>29.2</td></tr><tr><td>350</td><td>6.8</td><td>9.7</td><td>11.9</td><td>13.7</td><td>15.3</td><td>16.8</td><td>18.1</td><td>19.4</td><td>20.5</td><td>21.6</td><td>23.7</td><td>25.6</td><td>27.4</td><td>29.0</td><td>30.5</td></tr><tr><td>400</td><td>7.3</td><td>10.3</td><td>12.7</td><td>14.6</td><td>16.4</td><td>17.9</td><td>19.4</td><td>20.7</td><td>21.9</td><td>23.1</td><td>25.3</td><td>27.4</td><td>29.3</td><td>31.1</td><td>32.6</td></tr><tr><td>450</td><td>7.8</td><td>11.0</td><td>13.4</td><td>15.5</td><td>17.3</td><td>19.0</td><td>20.5</td><td>21.9</td><td>23.3</td><td>24.5</td><td>26.9</td><td>29.0</td><td>31.1</td><td>32.9</td><td>34.7</td></tr><tr><td>500</td><td>8.2</td><td>11.6</td><td>14.2</td><td>16.4</td><td>18.3</td><td>20.0</td><td>21.6</td><td>23.1</td><td>24.5</td><td>25.9</td><td>28.3</td><td>30.5</td><td>32.6</td><td>34.7</td><td>36.6</td></tr><tr><td>550</td><td>8.6</td><td>12.1</td><td>14.8</td><td>17.2</td><td>19.2</td><td>21.0</td><td>22.7</td><td>24.3</td><td>25.7</td><td>27.1</td><td>29.7</td><td>32.0</td><td>34.4</td><td>36.3</td><td>38.4</td></tr><tr><td>600</td><td>9.0</td><td>12.7</td><td>15.5</td><td>17.9</td><td>20.0</td><td>21.9</td><td>23.7</td><td>25.3</td><td>26.9</td><td>28.3</td><td>31.1</td><td>33.5</td><td>36.0</td><td>38.1</td><td>39.9</td></tr><tr><td>650</td><td>9.3</td><td>13.2</td><td>16.2</td><td>18.7</td><td>20.8</td><td>22.8</td><td>24.7</td><td>26.4</td><td>28.0</td><td>29.5</td><td>32.3</td><td>34.7</td><td>37.2</td><td>39.6</td><td>41.8</td></tr><tr><td>700</td><td>9.7</td><td>13.7</td><td>16.8</td><td>19.4</td><td>21.6</td><td>23.7</td><td>25.6</td><td>27.4</td><td>29.0</td><td>30.5</td><td>33.5</td><td>36.3</td><td>38.7</td><td>41.1</td><td>43.3</td></tr><tr><td>750</td><td>10.0</td><td>14.2</td><td>17.3</td><td>20.0</td><td>22.4</td><td>24.5</td><td>26.5</td><td>28.3</td><td>30.1</td><td>31.7</td><td>34.7</td><td>37.5</td><td>39.9</td><td>42.4</td><td>44.8</td></tr><tr><td colspan="16">注:表中所示错口偏差值和最小装配管道长度可用内插法求得。</td></tr></table>

表 S.2 非应变敏感管道的允许错口值

<table><tr><td rowspan="3">公称直径mm</td><td colspan="15">管道组对时的允许错口值mm</td></tr><tr><td>2.5</td><td>5</td><td>7.5</td><td>10</td><td>12.5</td><td>15</td><td>17.5</td><td>20</td><td>22.5</td><td>25</td><td>30</td><td>35</td><td>40</td><td>45</td><td>50</td></tr><tr><td colspan="15">应变敏感管道的最小管道总长m</td></tr><tr><td>15</td><td>1.2</td><td>1.7</td><td>2.0</td><td>2.4</td><td>2.7</td><td>2.9</td><td>3.1</td><td>3.4</td><td>3.6</td><td>3.7</td><td>4.1</td><td>4.4</td><td>4.8</td><td>5.0</td><td>5.3</td></tr><tr><td>20</td><td>1.3</td><td>1.9</td><td>2.3</td><td>2.7</td><td>3.0</td><td>3.2</td><td>3.5</td><td>3.7</td><td>4.0</td><td>4.2</td><td>4.6</td><td>5.0</td><td>5.3</td><td>5.6</td><td>5.9</td></tr><tr><td>25</td><td>1.5</td><td>2.1</td><td>2.6</td><td>3.0</td><td>3.3</td><td>3.6</td><td>3.9</td><td>4.2</td><td>4.5</td><td>4.7</td><td>5.2</td><td>5.5</td><td>5.9</td><td>6.3</td><td>6.6</td></tr><tr><td>40</td><td>1.8</td><td>2.4</td><td>3.1</td><td>3.6</td><td>4.0</td><td>4.3</td><td>4.7</td><td>5.0</td><td>5.3</td><td>5.6</td><td>6.1</td><td>6.7</td><td>7.1</td><td>7.6</td><td>7.9</td></tr><tr><td>50</td><td>2.0</td><td>2.8</td><td>3.4</td><td>4.0</td><td>4.5</td><td>4.9</td><td>5.3</td><td>5.6</td><td>6.0</td><td>6.3</td><td>6.9</td><td>7.5</td><td>8.0</td><td>8.4</td><td>8.9</td></tr><tr><td>65</td><td>2.2</td><td>3.1</td><td>3.8</td><td>4.4</td><td>4.9</td><td>5.4</td><td>5.8</td><td>6.2</td><td>6.6</td><td>6.9</td><td>7.6</td><td>8.2</td><td>8.8</td><td>9.3</td><td>9.8</td></tr><tr><td>75</td><td>2.4</td><td>3.4</td><td>4.2</td><td>4.8</td><td>5.4</td><td>5.9</td><td>6.4</td><td>6.8</td><td>7.3</td><td>7.7</td><td>8.4</td><td>9.1</td><td>9.7</td><td>10.3</td><td>10.8</td></tr><tr><td>100</td><td>2.7</td><td>3.9</td><td>4.8</td><td>5.5</td><td>6.1</td><td>6.7</td><td>7.3</td><td>7.8</td><td>8.2</td><td>8.7</td><td>9.5</td><td>10.3</td><td>11.0</td><td>11.6</td><td>12.3</td></tr><tr><td>150</td><td>3.3</td><td>4.7</td><td>5.8</td><td>6.6</td><td>7.4</td><td>8.1</td><td>8.8</td><td>9.4</td><td>10.0</td><td>10.5</td><td>11.3</td><td>12.5</td><td>13.3</td><td>14.0</td><td>14.9</td></tr><tr><td>200</td><td>3.8</td><td>5.4</td><td>6.6</td><td>7.6</td><td>8.5</td><td>9.3</td><td>10.1</td><td>10.7</td><td>11.4</td><td>12.0</td><td>13.2</td><td>14.2</td><td>15.2</td><td>16.1</td><td>17.0</td></tr><tr><td>250</td><td>4.2</td><td>6.0</td><td>7.3</td><td>8.5</td><td>9.5</td><td>10.4</td><td>11.2</td><td>11.9</td><td>12.7</td><td>13.4</td><td>14.7</td><td>15.8</td><td>16.9</td><td>18.0</td><td>19.0</td></tr><tr><td>300</td><td>4.6</td><td>6.5</td><td>8.0</td><td>9.2</td><td>10.3</td><td>11.3</td><td>12.2</td><td>13.0</td><td>13.8</td><td>14.6</td><td>16.0</td><td>17.3</td><td>18.5</td><td>19.5</td><td>20.6</td></tr><tr><td>350</td><td>4.8</td><td>6.9</td><td>8.4</td><td>9.7</td><td>10.8</td><td>11.9</td><td>12.8</td><td>13.7</td><td>14.5</td><td>15.3</td><td>16.8</td><td>18.1</td><td>19.4</td><td>20.4</td><td>21.6</td></tr><tr><td>400</td><td>5.2</td><td>7.3</td><td>9.0</td><td>10.3</td><td>11.6</td><td>12.7</td><td>13.7</td><td>14.6</td><td>15.5</td><td>16.4</td><td>17.9</td><td>19.4</td><td>20.7</td><td>21.9</td><td>23.1</td></tr><tr><td>450</td><td>5.5</td><td>7.8</td><td>9.5</td><td>11.0</td><td>12.3</td><td>13.4</td><td>14.5</td><td>15.5</td><td>16.5</td><td>17.3</td><td>19.0</td><td>20.5</td><td>21.9</td><td>23.3</td><td>24.5</td></tr><tr><td>500</td><td>5.8</td><td>8.2</td><td>10.0</td><td>11.6</td><td>12.9</td><td>14.2</td><td>15.3</td><td>16.4</td><td>17.3</td><td>18.3</td><td>20.0</td><td>21.6</td><td>23.1</td><td>24.5</td><td>25.9</td></tr><tr><td>550</td><td>6.1</td><td>8.6</td><td>10.5</td><td>12.1</td><td>13.6</td><td>14.8</td><td>16.0</td><td>17.2</td><td>18.2</td><td>19.2</td><td>21.0</td><td>23.3</td><td>24.3</td><td>25.7</td><td>27.1</td></tr><tr><td>600</td><td>6.3</td><td>9.0</td><td>11.0</td><td>12.7</td><td>14.1</td><td>15.5</td><td>16.8</td><td>17.9</td><td>19.0</td><td>20.0</td><td>21.9</td><td>23.7</td><td>25.3</td><td>26.9</td><td>28.3</td></tr><tr><td>650</td><td>6.6</td><td>9.3</td><td>11.4</td><td>13.2</td><td>14.8</td><td>16.2</td><td>17.4</td><td>18.7</td><td>19.8</td><td>20.8</td><td>22.8</td><td>24.7</td><td>26.4</td><td>28.0</td><td>29.5</td></tr><tr><td>700</td><td>6.8</td><td>9.7</td><td>11.9</td><td>13.7</td><td>15.3</td><td>16.8</td><td>18.2</td><td>18.7</td><td>20.5</td><td>21.6</td><td>23.7</td><td>25.6</td><td>27.4</td><td>29.0</td><td>30.5</td></tr><tr><td>750</td><td>7.1</td><td>10.0</td><td>12.3</td><td>14.2</td><td>15.8</td><td>17.3</td><td>18.7</td><td>20.0</td><td>21.2</td><td>22.4</td><td>24.5</td><td>26.5</td><td>28.3</td><td>30.1</td><td>31.7</td></tr><tr><td colspan="16">注:表中所示错口偏差值和最小装配管道长度可用内插法求得。</td></tr></table>

## S.3 示例

图 S.1 所示为一条两个设备之间的管道系统，在最终封闭口处有 X、Y、Z 三个方向的错口偏差值，分别为 12.5 mm、20 mm、10 mm。在两设备之间的管道共有 8 个管段：

X 方向的管段: 2 个, 总长度 = 7(m) + 10(m) = 17(m);

Y 方向的管段: 2 个, 总长度= $2(\mathrm{~m})+3(\mathrm{~m})=5(\mathrm{~m})$ ;

Z 方向的管段: 4 个, 总长度 = 1(m) + 12(m) + 1.5(m) + 3(m) = 17.5(m);

垂直于错口 $\Delta X$ 方向的管段为 Y、Z 方向的管段 6 个 $(4+2)$ ，总长度 = 17.5(m) + 5(m) = 22.5(m)；

垂直于错口 $\Delta Y$ 方向的管段为 X、Z 方向的管段 6 个 $(2+4)$ ，总长度 =17(m) + 17.5(m) = 34.5(m)；

垂直于错口 $\Delta Z$ 方向的管段为 X、Y 方向的管段 4 个 $(2+2)$ ，总长度 = 17(m) + 5(m) = 22(m)。

![](images/fb1d0be7235804f98828d6dc2f66a340f54acd0d32b778237bd4d69b836ba092.jpg)  
图 S.1 示例图

该最终封闭口的错口偏差值分别按如下方法进行评估。

a）对于 $12.5\mathrm{mm}$ 的 $\Delta X$ 错口：

垂直于错口 $\Delta X$ 方向的有 6 个管段，它们的总长度是 22.5 m（6 个管段的总长）；在表 S.1 中查到 DN250 管道 $\Delta X$ 方向错口偏差值为 12.5 mm 时，给出的最小装配管道长度是 13.4 m。由于实际装配管道总长度大于此值，故 $\Delta X$ 方向错口偏差值 12.5 mm 是可以接受的。

b) 对于 $20 \mathrm{~mm}$ 的 $\Delta Y$ 错口：

垂直于错口 $\Delta Y$ 方向的有4个管段，它们的总长度是 $34.5\mathrm{m}$ （6个管段的总长）；在表S.1中查到DN250管道 $\Delta Y$ 方向错口偏差值为 $20~\mathrm{mm}$ 时，给出的最小装配管道长度是 $16.9\mathrm{mm}$ 。由于实际装配管道总长度大于此值，故 $\Delta Y$ 方向错口偏差值 $20~\mathrm{mm}$ 是可以接受的。

c) 对于 $10 \mathrm{~mm}$ 的 $\Delta Z$ 错口：

垂直于错口 $\Delta Z$ 方向的有 4 个管段，它们的总长度是 22 m（4 个管段的总长）；在表 S.1 中查到 DN250 管道 $\Delta Z$ 方向错口偏差值为 10 mm 时，给出的最小装配管道长度是 12 m。由于实际装配管道总长度大于此值，故 $\Delta Z$ 方向错口偏差值 10 mm 是可以接受的。

通过计算和比对，由于所有方向的错口偏差值都在允差范围之内，故这条管道可以通过冷拉对正。

## S.4 法兰接头偏转偏差评估方法

S.4.1 管道最终封闭口采用法兰连接装配时，除 S.2 所列的错口偏差外，还可能存在法兰接头偏转偏差，即由于两个法兰之间的不平行度而产生的外缘间隙，如图 S.2 所示。该偏转偏差将消耗部分螺栓的预紧载荷，降低垫片的预紧载荷。

S.4.2 管道最终封闭口采用法兰连接的装配要求见表 S.3。

![](images/e603593339c439085fb5f6508a3af8ff244d19cf31ee4e677e842c2cba0c7a43.jpg)  
图 S.2 法兰接头组对时的允许间隙

表 S.3 法兰接头组对时的允许间隙

<table><tr><td rowspan="3">最小轴向间距(L)mm</td><td colspan="11">DN</td></tr><tr><td>15</td><td>20</td><td>25</td><td>40</td><td>50</td><td>80</td><td>100</td><td>150</td><td>200</td><td>250</td><td>300</td></tr><tr><td colspan="11">允许间隙mm</td></tr><tr><td>250</td><td>2.3</td><td>2.1</td><td>1.8</td><td>1.5</td><td>1.4</td><td>1.2</td><td>1.1</td><td>0.94</td><td>0.89</td><td>0.84</td><td>0.84</td></tr><tr><td>350</td><td>3.3</td><td>2.9</td><td>2.5</td><td>2.1</td><td>2.0</td><td>1.7</td><td>1.6</td><td>1.3</td><td>1.2</td><td>1.2</td><td>1.2</td></tr><tr><td>450</td><td>4.2</td><td>3.7</td><td>3.3</td><td>2.7</td><td>2.5</td><td>2.2</td><td>2.0</td><td>1.7</td><td>1.6</td><td>1.5</td><td>1.5</td></tr><tr><td>550</td><td>5.2</td><td>4.6</td><td>4.0</td><td>3.3</td><td>3.1</td><td>2.6</td><td>2.5</td><td>2.1</td><td>1.9</td><td>1.8</td><td>1.8</td></tr><tr><td>650</td><td>6.1</td><td>5.4</td><td>4.7</td><td>3.8</td><td>3.7</td><td>3.1</td><td>2.9</td><td>2.4</td><td>2.3</td><td>2.2</td><td>2.2</td></tr><tr><td>750</td><td>7.0</td><td>6.2</td><td>5.4</td><td>4.4</td><td>4.2</td><td>3.6</td><td>3.4</td><td>2.8</td><td>2.6</td><td>2.5</td><td>2.5</td></tr><tr><td>850</td><td>8.0</td><td>7.1</td><td>6.2</td><td>5.0</td><td>4.8</td><td>4.1</td><td>3.8</td><td>3.2</td><td>3.0</td><td>2.8</td><td>2.8</td></tr><tr><td>950</td><td>8.9</td><td>7.9</td><td>6.9</td><td>5.6</td><td>5.4</td><td>4.6</td><td>4.3</td><td>3.5</td><td>3.4</td><td>3.2</td><td>3.2</td></tr><tr><td>1 050</td><td>9.9</td><td>8.7</td><td>7.6</td><td>6.2</td><td>6.0</td><td>5.1</td><td>4.7</td><td>3.9</td><td>3.7</td><td>3.5</td><td>3.5</td></tr><tr><td>1 150</td><td>10.8</td><td>9.6</td><td>8.4</td><td>6.8</td><td>6.5</td><td>5.5</td><td>5.2</td><td>4.3</td><td>4.0</td><td>3.8</td><td>3.8</td></tr><tr><td>1 250</td><td>11.8</td><td>10.4</td><td>9.1</td><td>7.4</td><td>7.1</td><td>6.0</td><td>5.6</td><td>4.6</td><td>4.4</td><td>4.2</td><td>4.2</td></tr><tr><td>1 350</td><td>12.7</td><td>11.3</td><td>9.8</td><td>8.0</td><td>7.7</td><td>6.5</td><td>5.9</td><td>5.0</td><td>4.8</td><td>4.5</td><td>4.5</td></tr><tr><td>1 450</td><td>13.7</td><td>12.1</td><td>10.5</td><td>8.6</td><td>8.2</td><td>7.0</td><td>6.5</td><td>5.4</td><td>5.1</td><td>4.9</td><td>4.9</td></tr><tr><td>1 550</td><td>14.6</td><td>12.9</td><td>11.3</td><td>9.2</td><td>8.8</td><td>7.5</td><td>7.0</td><td>5.8</td><td>5.4</td><td>5.2</td><td>5.2</td></tr><tr><td>1 650</td><td>15.6</td><td>13.8</td><td>12.0</td><td>9.8</td><td>9.4</td><td>8.0</td><td>7.4</td><td>6.1</td><td>5.8</td><td>5.5</td><td>5.5</td></tr><tr><td>1 750</td><td>16.6</td><td>14.6</td><td>12.8</td><td>10.4</td><td>9.9</td><td>8.4</td><td>7.8</td><td>6.5</td><td>6.1</td><td>5.8</td><td>5.8</td></tr><tr><td>1 850</td><td>17.5</td><td>15.5</td><td>13.5</td><td>10.9</td><td>10.5</td><td>8.9</td><td>8.3</td><td>6.9</td><td>6.5</td><td>6.2</td><td>6.2</td></tr><tr><td>1 950</td><td>18.5</td><td>16.3</td><td>14.2</td><td>11.6</td><td>11.1</td><td>9.4</td><td>8.8</td><td>7.3</td><td>6.9</td><td>6.5</td><td>6.5</td></tr><tr><td>2 050</td><td>19.5</td><td>17.2</td><td>15.0</td><td>12.1</td><td>11.6</td><td>9.9</td><td>9.2</td><td>7.6</td><td>7.2</td><td>6.9</td><td>6.8</td></tr><tr><td>2 150</td><td>20.4</td><td>18.0</td><td>15.7</td><td>12.8</td><td>12.2</td><td>10.3</td><td>9.7</td><td>8.0</td><td>7.5</td><td>7.2</td><td>7.2</td></tr><tr><td>2 250</td><td>21.4</td><td>18.9</td><td>16.4</td><td>13.3</td><td>12.8</td><td>10.8</td><td>10.1</td><td>8.4</td><td>7.9</td><td>7.5</td><td>7.5</td></tr><tr><td>2 350</td><td>22.4</td><td>19.7</td><td>17.2</td><td>13.9</td><td>13.4</td><td>11.3</td><td>10.6</td><td>8.7</td><td>8.3</td><td>7.8</td><td>7.8</td></tr><tr><td>2 450</td><td>23.4</td><td>20.6</td><td>17.9</td><td>14.5</td><td>13.9</td><td>11.8</td><td>11.0</td><td>9.0</td><td>8.6</td><td>8.2</td><td>8.2</td></tr><tr><td>2 550</td><td>24.4</td><td>21.4</td><td>18.7</td><td>15.1</td><td>14.5</td><td>12.3</td><td>11.5</td><td>9.5</td><td>9.0</td><td>8.5</td><td>8.5</td></tr><tr><td>2 650</td><td>25.5</td><td>22.4</td><td>19.4</td><td>15.7</td><td>15.1</td><td>12.8</td><td>11.9</td><td>9.9</td><td>9.3</td><td>8.9</td><td>8.9</td></tr><tr><td>2 750</td><td>26.4</td><td>23.2</td><td>20.1</td><td>16.3</td><td>15.6</td><td>13.2</td><td>12.3</td><td>10.3</td><td>9.7</td><td>9.2</td><td>9.2</td></tr><tr><td colspan="12">注:表中所示允许间隙值为扣除法兰凸台高度及密封垫厚度后,由两个法兰之间的不平行度而产生的外缘间隙。</td></tr></table>

## 附录 T

(资料性)

## 安全保护层分析

T.1 工业压力管道系统的安全运行,需多层次的安全防护。典型的安全保护层图如图 T.1 所示。每个安全保护层是独立的,由里层至外层,事故后果逐层升高。

T.2 图 T.1 中第 6 层是本部分定义为安全保护装置的物理(机械)保护装置。该层在自控仪表和人工干预失效时起防护作用, 是防止事故发生的最后一道屏障。

![](images/3b97b05f2cd76b7a40b946afb3ab761c5ea3095b0fd9109f79c2989ccff63214.jpg)  
图 T.1 典型的安全保护层图

# 附录 U

# (资料性)

# 安全泄放装置的计算

## U.1 符号

下列符号适用于本附录。

A ——满足泄放量要求的所需最小泄放面积,单位为平方毫米 $\left(\mathrm{mm}^{2}\right)$ 。

$A_{r}$ ——容器受热面积,单位为平方米 $(m^{2})$ 。

C ——气体特性系数，按 $C=0.03948\sqrt{k\left(\frac{2}{k+1}\right)^{\frac{k+1}{k-1}}}$ 求取。

$C_{pl}$ ——液体定压比热容,单位为千焦每千克开 $\left[\mathrm{kJ}/(\mathrm{kg}\cdot\mathrm{K})\right]$ 。

$C_{s}$ ——亚临界流的气体特性系数，按 $C_{s}=\sqrt{\frac{k}{(k+1)}\left(\frac{p_{0}}{p_{d}}\right)^{\frac{2}{k}}\left[\frac{1-\left(\frac{p_{0}}{p_{d}}\right)^{\left(\frac{k-1}{k}\right)}}{1-\left(\frac{p_{0}}{p_{d}}\right)}\right]}$ 。

d ——管道内直径,单位为毫米(mm)。

$F$ ——系数：

地面以下用沙土覆盖时，F=0.03；

地面上时，F=1.0；

大于 $10 \, \text{L}/(\text{m}^2 \cdot \text{min})$ 喷淋装置下时，F = 0.6。

G ——质量流率,单位为千克每秒平方米 $\left[\mathrm{kg}/(\mathrm{s}\cdot\mathrm{m}^{2})\right]$ 。

H ——最大输入热量,单位为千焦每时(kJ/h)。

K ——安全泄放装置有效泄放系数。

在初步选用计算中有效泄放系数 K 时可采用：

安全阀: 气体和蒸气为 0.975; 液体为 0.62; 二相流计算中轻微过冷液体为 0.65; 二相混合物和饱和液体为 0.85。

爆破片装置: 气体 K 值与爆破片装置入口管道形状有关, 如图 U.1 所示, 当管道形状不易确定时, 取 0.62; 液体取 0.62。

爆破针阀:气体为 0.8;液体为 0.68。

安全泄放装置产品的额定泄放系数是制造商按相关标准试验的平均系数乘以 0.90 确定的，并经第三方认证，其值小于有效泄放系数。

$K_{b}, K_{w}$ ——安全阀的背压校正系数。 $K_{b}$ 用于气体、蒸气和二相混合物； $K_{w}$ 用于液体。波纹管型安全阀的 $K_{b}$ 和 $K_{w}$ 由制造商提供或参照GB/T24921.1确定。背压与设定压力的表压比小于10%的临界流动气体用或液体用普通型安全阀，以及临界流动气体用或液体用先导型安全阀， $K_{b}$ 和 $K_{w}$ 均为1.0。爆破片装置和爆破针阀， $K_{b}$ 和 $K_{w}$ 均为1.0。

$K_{c}$ ——安全阀的组合校正系数。安全阀上游安装爆破片装置或爆破针阀时 $K_{c}=0.9$ ，不安装时 $K_{c}=1.0$ 。

$K_{\mathrm{N}}$ ——修正因子：

当 $P_{f} \leqslant 10.34$ MPa 时, $K_{N} = 1$ ;

当 10.34 MPa $< P_{f} \leqslant 22.06$ MPa 时， $K_{N} = \frac{27.64p_{f} - 1000}{33.24p_{f} - 1061}$ 。

$K_{SH}$ ——蒸汽过热度修正系数。对任意压力下的饱和蒸汽， $K_{SH}=1$ ；对于过热蒸汽， $K_{SH}$ 可通过表 U.8 查询得到，压力、温度介于表 U.8 中间数值的 $K_{SH}$ 采用线性内插法插值计算。

k ——气体绝热指数。

M ——气体的摩尔质量,单位为千克每千摩尔(kg/kmol)。

$p_{c}$ ——二相混合物临界压力(绝压),单位为兆帕(MPa)。

$p_{d}$ ——安全泄放装置入口侧的最大泄放压力(绝压)，单位为兆帕(MPa)。

$p_{0}$ ——安全泄放装置出口侧压力(绝压),单位为兆帕(MPa)。

$p_{s}$ ——二相混合物的饱和蒸气压力(绝压),单位为兆帕(MPa)。

$Q_{s}$ ——二相流计算中的安全泄放量,单位为升每分(L/min)。

q ——在泄放压力下,液体汽化潜热,单位为千焦每千克(kJ/kg)。

d ——液体的相对密度。

$T_{f}$ ——安全泄放装置的泄放温度,单位为摄氏度(℃)。

$T_{w}$ ——火灾情况下容器最大金属壁温,单位为摄氏度(℃)。

t ——最大泄放压力下介质的饱和温度,单位为摄氏度(℃)。

$V_{s}$ ——液体安全泄放量,单位为立方米每时 $\left(\mathrm{m}^{3}/\mathrm{h}\right)$ 。

v ——进口管最大气体流速,单位为米每秒(m/s)。

$W_{s}$ ——安全泄放量,单位为千克每时(kg/h)。

Z ——在最大泄放压力及温度下,气体的压缩系数。

α ——液体的体积膨胀系数, $1/^{\circ}C$ ,可查表 U.1。

$\delta$ ——保温层厚度,单位为米(m)。

$\lambda$ ——常温下绝热材料的导热系数,单位为千焦每米时开 $\left[\mathrm{kJ}/(\mathrm{m}\cdot\mathrm{h}\cdot\mathrm{K})\right]$ 。

$\mu$ ——液体的动力黏度,单位为千克每米秒 $\left[\mathrm{kg}/(\mathrm{m}\cdot\mathrm{s})\right]$ 。

$\xi$ ——安全泄放装置的液体动力黏度校正系数，根据雷诺数 $Re = \frac{0.3134W_{\mathrm{s}}}{\mu\sqrt{A}}$ 由图U.2查取；当液体黏度等于或小于水的黏度时，取 $\xi = 1$ 。

$v_{0}$ ——安全泄放装置入口状态下二相混合物比容，单位为立方米每千克 $\left(\mathrm{m}^{3}/\mathrm{kg}\right)$ 。

$v_{9}$ ——安全泄放装置 90% 入口压力下二相混合物比容，单位为立方米每千克 $\left(\mathrm{m}^{3}/\mathrm{kg}\right)$ 。

$\rho_{s}$ ——安全泄放装置入口状态下气体密度,单位为千克每立方米 $(\mathrm{kg}/\mathrm{m}^{3})$ 。

$\rho_{1}$ ——安全泄放装置入口状态下液体密度,单位为千克每立方米 $(\mathrm{kg}/\mathrm{m}^{3})$ 。

$\rho_{9}$ ——对应安全泄放装置入口温度下，90%入口液体饱和蒸气压 $p_{s}$ 时的二相混合物密度，单位为千克每立方米 $(\mathrm{kg}/\mathrm{m}^{3})$ 。

$\eta_{0}$ ——背压比, $\eta_{0}=p_{o}/p_{d}$ 。

$\eta_{c}$ ——临界压力比, $\eta_{c}=p_{c}/p_{d}$ 。

$\eta_{s}$ ——饱和蒸气压力比, $\eta_{s}=p_{s}/p_{d}$ 。

$\eta_{st}$ ——转变饱和压力比,见公式(U.19)。

$\omega$ ——欧米伽参数, 见公式(U.12)。

$\omega_{s}$ ——饱和欧米伽参数, 见公式(U.18)。

![](images/dcd75052fae3762aba37e6df3b15676da576b6a6e2d8c9f8c8cc430f265e32c2.jpg)  
图U.1 爆破片装置入口管道形状与用于气体的爆破片有效泄放系数 $K$

![](images/c9337c87947423753b8195d8492bc21d1a6d21645c63afa792a0b558e818a6d2.jpg)  
图 U.2 液体动力黏度校正系数 $\xi$

表 U.1 20 ℃ 的液体体积膨胀系数

<table><tr><td>液体</td><td>体积膨胀系数/(1/°C)</td><td>液体</td><td>体积膨胀系数/(1/°C)</td></tr><tr><td>水</td><td>0.002 07</td><td>乙酸</td><td>0.001 07</td></tr><tr><td>硫酸水溶液,100%</td><td>0.000 558</td><td>乙醚</td><td>0.001 66</td></tr><tr><td>硫酸水溶液,10.9%</td><td>0.000 387</td><td>丙酮</td><td>0.001 49</td></tr><tr><td>硫酸水溶液,5.4%</td><td>0.000 311</td><td>乙二醇</td><td>0.000 638</td></tr><tr><td>硫酸水溶液,1.4%</td><td>0.000 234</td><td>丙三醇(甘油)</td><td>0.000 505</td></tr><tr><td>盐酸水溶液,33.2%</td><td>0.000 455</td><td>乙酸甲酯</td><td>0.001 43</td></tr><tr><td>盐酸水溶液,4.2%</td><td>0.000 239</td><td>乙酸乙酯</td><td>0.001 39</td></tr><tr><td>盐酸水溶液,1.0%</td><td>0.000 211</td><td>苯</td><td>0.001 24</td></tr><tr><td>氯化钠水溶液,26.0%</td><td>0.000 440</td><td>甲苯</td><td>0.001 09</td></tr><tr><td>氯化钠水溶液,20.6%</td><td>0.000 414</td><td>苯酚</td><td>0.001 09</td></tr><tr><td>硫酸钠水溶液,24%</td><td>0.000 410</td><td>苯胺</td><td>0.000 858</td></tr><tr><td>硫酸钠水溶液,1.9%</td><td>0.000 235</td><td>对二甲苯</td><td>0.001 01</td></tr><tr><td>氯化钾水溶液,24.3%</td><td>0.000 353</td><td>间二甲苯</td><td>0.000 99</td></tr><tr><td>氯化钙水溶液,40.9%</td><td>0.000 458</td><td>邻二甲苯</td><td>0.000 97</td></tr><tr><td>氯化钙水溶液,6.0%</td><td>0.000 250</td><td>油品,°API 3~35</td><td> $0.000\ 72^a$ </td></tr><tr><td>二硫化碳</td><td>0.001 22</td><td>油品,°API 35~51</td><td> $0.000\ 90^a$ </td></tr><tr><td>四氯化碳</td><td>0.001 24</td><td>油品,°API 51~64</td><td> $0.001\ 08^a$ </td></tr><tr><td>三氯甲烷(氯仿)</td><td>0.001 27</td><td>油品,°API 64~79</td><td> $0.001\ 26^a$ </td></tr><tr><td>甲醇</td><td>0.001 20</td><td>油品,°API 79~89</td><td> $0.001\ 44^a$ </td></tr><tr><td>乙醇</td><td>0.001 12</td><td>油品,°API 89~94</td><td> $0.001\ 53^a$ </td></tr><tr><td>甲酸</td><td>0.001 03</td><td>油品,°API≥94~100</td><td> $0.001\ 62^a$ </td></tr><tr><td colspan="4"> $^a$ 15.6°C的体积膨胀系数。</td></tr></table>

## U.2 独立压力系统的安全泄放量计算

## U.2.1 安全泄放量计算的确定原则

当中间无阀门关断的管道系统与相连接的几个设备(容器)一起作为一个独立的被保护压力系统,用一个或几个设置在容器上或管道上的安全泄放装置保护时,其安全泄放量采用压力容器安全泄放量的计算方法,但需将管道系统和相连接的容器都包括在内。

单纯的管道系统的超压主要发生在充满液体的封闭管道系统中，液体受热膨胀可能发生超压。若安全泄放装置设定压力大于液体蒸气压，则安全泄放量按液体热膨胀计算，反之按液体汽化计算。

## U.2.2 非火灾事故的安全泄放量计算

U.2.2.1 非火灾事故超压包括工艺操作、设备故障、公用工程供应、自动控制仪表故障等因素导致的超压。包括但不限于：出口关闭、冷却或回流中断、吸收剂中断、不凝组分累积、易挥发介质混入、超装、自控失灵、不正常的工艺热量或气体输入、止回阀泄漏或失效、化学反应、膨胀、公用工程供应中断等。

U.2.2.2 蒸气发生器等产生蒸气换热设备的系统安全泄放量按公式(U.1)计算：

$$
W _ {\mathrm{s}} = H / q
$$

……( U.1 )

U.2.2.3 对于有压力源持续输入的系统安全泄放量按公式(U.2)计算：

$$
W _ {\mathrm{s}} = 2. 8 3 \times 1 0 ^ {- 3} \rho_ {\mathrm{s}} v d ^ {2}\tag{……( U.2}
$$

U.2.2.4 充满液体的管道中液体受热膨胀或气化时的安全泄放量按下列计算：

a) 受热后,液体的温度小于泄放装置设定压力所对应的饱和温度时,按公式(U.3)计算:

$$
W _ {\mathrm{s}} = \frac {a H}{C _ {\mathrm{pl}}}\tag{……( U.3}
$$

b) 受热后,液体的温度大于等于泄放装置设定压力所对应的饱和温度时,按公式(U.1)计算。

U.2.2.5 因化学反应而导致超压者,安全泄放量按化学反应可能生成的最大气量、反应时间或者上升速率来确定。

## U.2.3 火灾事故安全泄放量计算

## U.2.3.1 液体

参照 U.2.2.4 进行。

## U.2.3.2 气体

首先按公式(U.4)计算 $F'$ :

$$
F ^ {\prime} = \frac {0 . 2 7 7 2}{C K} \left[ \frac {(T _ {\mathrm{w}} - T _ {\mathrm{f}}) ^ {1 . 2 5}}{(2 7 3 + T _ {\mathrm{f}}) ^ {0 . 6 5 0 6}} \right]\tag{……( U.4}
$$

如果 $F^{\prime} \leqslant 182$ ，安全泄放量按公式(U.5)计算：

$$
W _ {\mathrm{s}} = 5 7 5 5 C A _ {\mathrm{r}} \sqrt {\frac {M p _ {\mathrm{d}}}{(2 7 3 + T _ {\mathrm{f}})}}\tag{……( U.5}
$$

如果 $F^{\prime}>182$ ，安全泄放量按公式(U.6)计算：

$$
W _ {\mathrm{s}} = 8. 7 7 \sqrt {M p _ {\mathrm{d}}} \left[ \frac {A ^ {\prime} (T _ {\mathrm{w}} - T _ {\mathrm{f}}) ^ {1 . 2 5}}{(2 7 3 + T _ {\mathrm{f}}) ^ {1 . 1 5 0 6}} \right]\tag{……( U.6}
$$

注：公式(U.6)是以空气的物理性质和理想气体定律为基础的，并假设独立压力系统无隔热，忽略独立压力系统本身热容，系统未因壁温升高产生局部破裂。

## U.2.3.3 液化气体

无绝热保温层时,安全泄放量按公式(U.7)计算:

$$
W _ {\mathrm{s}} = \frac {2 . 5 5 \times 1 0 ^ {5} F A _ {\mathrm{r}} ^ {0 . 8 2}}{q}\tag{……( U.7}
$$

有完善的绝热保温层时,安全泄放量按公式(U.8)计算:

$$
W _ {\mathrm{s}} = \frac {2 . 6 1 (6 5 0 - t) \lambda A _ {\mathrm{r}} ^ {0 . 8 2}}{\delta q}\tag{……( U.8}
$$

注：在任何情况下，用于减少压力系统安全泄放量的绝热层需在 $650^{\circ}$ C 时仍能起到有效作用且 2 h 内不会烧坏脱落，在消防水冲击作用下不会脱落。

## U.3 所需最小泄放面积计算

## U.3.1 气体

U.3.1.1 临界流动: $\frac{p_{\mathrm{o}}}{p_{\mathrm{d}}} \leqslant \left(\frac{2}{k + 1}\right)^{\frac{k}{k - 1}}$ 时, 所需最小泄放面积按公式(U.9)计算:

$$
A = \frac {W _ {\mathrm{s}}}{1 0 0 0 C K K _ {\mathrm{b}} K _ {\mathrm{c}} p _ {\mathrm{d}}} \sqrt {\frac {Z (2 7 3 + T _ {\mathrm{f}})}{M}}\tag{……( U.9}
$$

U.3.1.2 亚临界流动: $\frac{p_{\mathrm{o}}}{p_{\mathrm{d}}} > \left(\frac{2}{k + 1}\right)^{\frac{k}{k - 1}}$ 时, 所需最小泄放面积的计算如下:

a）对于可通过调节弹簧载荷补偿附加背压的普通型安全阀和先导式安全阀以及爆破片装置，其有效泄放面积按公式(U.10)计算：

$$
A = \frac {1 . 7 9 \times 1 0 ^ {- 2} W _ {\mathrm{s}}}{C _ {\mathrm{s}} K K _ {\mathrm{c}}} \sqrt {\frac {Z (2 7 3 + T _ {\mathrm{f}})}{M \left(p _ {\mathrm{d}} - p _ {\mathrm{o}}\right) p _ {\mathrm{d}}}}\tag{……( U.10}
$$

b) 对于平衡型安全阀,其有效泄放面积按公式(U.9)计算,这时的背压修正系数 $K_{b}$ 考虑到亚临界流动的情况以及阀瓣的开启高度保持不变(亚临界流动公式仅适用于开启高度保持不变的情况),此时背压修正系数需从制造商处获取。

## U.3.2 饱和蒸气

饱和蒸气中蒸气含量不小于 98%，最大过热度为 10 ℃，所需最小泄放面积按公式(U.11)计算：

$$
A = \frac {0 . 1 9 \times W _ {\mathrm{s}}}{p _ {\mathrm{d}} K K _ {\mathrm{b}} K _ {\mathrm{c}} K _ {\mathrm{N}} K _ {\mathrm{SH}}}\tag{……( U.11}
$$

## U.3.3 液体

一般液体所需最小泄放面积按公式(U.12)计算：

$$
A = \frac {0 . 1 9 6 \times W _ {\mathrm{s}}}{K K _ {\mathrm{w}} K _ {\mathrm{c}} K _ {\mathrm{v}} \sqrt {\rho (p _ {\mathrm{d}} - p _ {\mathrm{o}})}}\tag{……( U.12}
$$

对于黏性流体的泄放面积计算程序如下：

a) 假设为非黏性流体，取 $\xi=1.0$ ，按公式(U.12)计算出初始的泄放面积与相应的直径，并向上圆整到产品系列化规格相近的公称直径及相对应的泄放面积；

b) 根据 a) 计算出的圆整后泄放面积按公式(U.12)及 $\xi=10$ 计算泄放量 W;

c) 根据 b) 计算出的 W 及 a) 计算出的圆整后泄放面积按公式 $Re = 0.313 \frac{W}{\mu \sqrt{A}}$ 计算雷诺数，由图 U.2 查得 $\xi$ 值按公式 (U.12) 重新计算泄放量 W:

若 $W \geqslant W_{s}$ ，则该直径（面积）即为所求的泄放面积；若 $W < W_{s}$ ，则采用大一档的产品公称直径相对应的泄放面积代替 a) 计算出的圆整后泄放面积，重复 b)～c) 的计算，直至 $W \geqslant W_{s}$ 。

## U.3.4 气液二相

U.3.4.1 气液二相流工况安全阀最小泄放面积计算采用本节的方法。气液二相流泄放工况可分为下述四种类型：

a）不含不凝气的饱和液相或二相流通过安全阀，阀后有闪蒸；

b) 含有不凝气或饱和气体的高度过冷液体通过安全阀, 阀后无闪蒸;

c) 含有不凝气的过冷或饱和液体通过安全阀，阀后有闪蒸；

d) 不含不凝气的过冷或饱和液体通过安全阀，阀后有闪蒸。

U.3.4.2 U.3.4.1 的 a)、b) 和 c) 类型的气液二相流的计算步骤如下。

a）计算欧米伽参数 $\omega$ ，按公式(U.13):

$$
\omega = 9 \left(\frac {v _ {9}}{v _ {0}} - 1\right)\tag{……( U.13}
$$

b) 临界压力比 $\eta_{c}$ ，按公式(U.14)计算：

$$
\eta_ {\mathrm{c}} = \left[ 1 + (1. 0 4 4 6 - 0. 0 0 9 3 4 3 1 \omega^ {0. 5}) \omega^ {- 0. 5 6 2 6 1} \right] ^ {(- 0. 7 0 3 5 6 + 0. 0 1 4 6 8 5 \ln \omega)}\tag{……( U.14}
$$

c) 确定临界压力 $p_{c}$ ，按公式(U.15)计算：

$$
p _ {\mathrm{c}} = \eta_ {\mathrm{c}} \cdot p _ {\mathrm{d}}\tag{……( U.15}
$$

d) 计算质量流率 G:

当 $p_{c} \geqslant p_{o}$ ，为临界流动时，按公式(U.16)计算：

$$
G = 1 0 0 0 \eta_ {\mathrm{c}} \sqrt {\frac {p _ {\mathrm{d}}}{\omega v _ {\mathrm{o}}}}\tag{……( U.16}
$$

当 $p_{c}<p_{o}$ ，为亚临界流动时，按公式(U.17)计算：

$$
G = \frac {1 0 0 0 \times \{- 2 [ \omega \ln \eta_ {\mathrm{o}} + (\omega - 1) (1 - \eta_ {\mathrm{o}}) ] \} ^ {0 . 5}}{\omega \left(\frac {1}{\eta_ {\mathrm{o}}} - 1\right) + 1} \sqrt {\frac {p _ {\mathrm{d}}}{v _ {\mathrm{o}}}}\tag{……( U.17}
$$

e) 计算所需最小泄放面积, 按公式(U.18):

$$
A = 2 7 7. 8 \frac {W _ {\mathrm{s}}}{K K _ {\mathrm{b}} K _ {\mathrm{c}} \xi G}\tag{……( U.18}
$$

U.3.4.3 U.3.4.1 的 d) 类型的气液二相流的计算步骤如下。

a）计算饱和欧米伽参数 $\omega_{s}$ ，按公式(U.19):

$$
\omega_ {\mathrm{s}} = 9 \left(\frac {\rho_ {1}}{\rho_ {9}} - 1\right)\tag{......( U.19}
$$

b) 确定过冷区

$p_{s} \geqslant \eta_{st} p_{d}$ ，为低过冷区（在喉管上游开始闪蒸）；

$p_{s}<\eta_{st}p_{d}$ ，为高过冷区(在喉管中开始闪蒸)。

转变的饱和压力比按公式(U.20)计算：

$$
\eta_ {\mathrm{st}} = \frac {2 \omega_ {\mathrm{s}}}{1 + 2 \omega_ {\mathrm{s}}}\tag{……( U.20}
$$

c) 对于低过冷区

饱和蒸气压力比按公式(U.21)计算：

$$
\eta_ {\mathrm{s}} = \frac {p _ {\mathrm{s}}}{p _ {\mathrm{d}}}\tag{……( U.21}
$$

若 $\eta_{s}\leqslant\eta_{st}$ ，则临界压力比 $\eta_{c}=\eta_{s}$ ;

若 $\eta_{s} > \eta_{st}$ ，则临界压力比按公式(U.22)计算：

$$
\eta_ {\mathrm{c}} = \eta_ {\mathrm{s}} \left(\frac {2 \omega}{2 \omega - 1}\right) \left[ 1 - \sqrt {1 - \frac {1}{\eta_ {\mathrm{s}}} \left(\frac {2 \omega - 1}{2 \omega}\right)} \right]\tag{……( U.22}
$$

采用公式(U.23)计算二相混合物的临界压力：

$$
p _ {\mathrm{c}} = \eta_ {\mathrm{c}} p _ {\mathrm{d}}\tag{……( U.23}
$$

当 $p_{c} \geqslant p_{o}$ ，为临界流动时，按公式(U.24)计算：

$$
G = \frac {1 0 0 0 \times \left\{2 \left(1 - \eta_ {\mathrm{s}}\right) + 2 \left[ \omega_ {\mathrm{s}} \eta_ {\mathrm{s}} \ln \left(\eta_ {\mathrm{s}} / \eta_ {\mathrm{c}}\right) - \left(\omega_ {\mathrm{s}} - 1\right) \left(\eta_ {\mathrm{s}} - \eta_ {\mathrm{c}}\right) \right] \right\} ^ {0 . 5}}{\omega \left(\eta_ {\mathrm{s}} / \eta_ {\mathrm{c}} - 1\right) + 1} \sqrt {p _ {\mathrm{o}} \rho_ {1}}\tag{U.24}
$$

当 $p_{c}<p_{o}$ ，为亚临界流动时，按公式(U.25)计算：

$$
G = \frac {1 0 0 0 \times \left\{2 \left(1 - \eta_ {\mathrm{s}}\right) + 2 \left[ \omega_ {\mathrm{s}} \eta_ {\mathrm{s}} \ln \left(\eta_ {\mathrm{s}} / \eta_ {\mathrm{c}}\right) - \left(\omega_ {\mathrm{s}} - 1\right) \left(\eta_ {\mathrm{s}} - \eta_ {\mathrm{o}}\right) \right] \right\} ^ {0 . 5}}{\omega \left(\eta_ {\mathrm{s}} / \eta_ {\mathrm{o}} - 1\right) + 1} \sqrt {p _ {\mathrm{o}} \rho_ {1}}\tag{·(U.25}
$$

d) 对于高过冷区

当 $p_{c} \geqslant p_{o}$ ，为临界流动时，按公式(U.26)计算：

$$
G = 1 4 1 4 \sqrt {\left(p _ {\mathrm{d}} - p _ {\mathrm{s}}\right) \rho_ {1}}\tag{……( U.26}
$$

当 $p_{c}<p_{o}$ ，为亚临界流动时，按公式(U.27)计算：

$$
G = 1 4 1 4 \sqrt {\left(p _ {\mathrm{d}} - p _ {\mathrm{o}}\right) \rho_ {1}}\tag{……( U.27}
$$

e) 计算所需最小泄放面积,按公式(U.28):

$$
A = 1 6. 6 7 \frac {Q _ {\mathrm{s}} \rho_ {1}}{K K _ {\mathrm{b}} K _ {\mathrm{c}} \xi G}\tag{……( U.28}
$$

## U.4 额定泄放量的验证

上述计算方法仅适用于初步选用计算。在选定产品后，制造商需提供经第三方认证的额定泄放系数和实际泄放面积。用额定泄放系数和实际泄放面积验证，额定泄放量需达到或超过安全泄放量。

# 附录 V

# (资料性)

## 安全泄放装置选用

## V.1 安全阀选用

V.1.1 用于清洁、无颗粒、无聚合物和低黏度的介质。

V.1.2 按介质的相态(气、液和气液二相流)选用阀门形式和阀门内件结构。对于二相流，在不能确定泄放量和/或二相的比例时，选用调节式先导型阀门。

V.1.3 用于变动背压工况时,需按背压选用阀门形式。

V.1.4 液化天然气等低温工况选用密封性良好的先导型阀门。

V.1.5 用于容积式压缩机出口管道的阀门选用在导压管上设置阻尼器的先导型阀门。

V.1.6 不用于失控放热反应的超压、内部爆燃、水锤或汽锤等压力急剧上升的工况。

V.1.7 安全阀不单独用于阀座与阀瓣密封面可能被介质粘连或介质可能生成结晶体的场合,但可以将爆破片装置串联在安全阀入口侧组合使用。

## V.2 爆破片装置选用

V.2.1 用于失控放热反应等压力迅速上升的工况。

V.2.2 用于含固体颗粒、易沉淀结晶、易聚合和高黏度介质。

V.2.3 用于急性毒性类别 1 和类别 2、可燃气体和液体等不允许泄漏介质。

V.2.4 用于使用哈氏合金、锆和钽等特种材料的强腐蚀性介质。

V.2.5 用于泄放量大、压力和/或温度过高或过低等不用安全阀的场合。

V.2.6 用于保护安全阀的性能而与之串联使用。

V.2.7 不用于泄放大量有害物质造成重大安全和环境后果的场合。

V.2.8 不用于系统压力和/或温度循环工况导致爆破片拉伸疲劳破坏的场合。

V.2.9 不用于有变动附加背压的场合。

V.2.10 爆破片装置形式需根据泄放介质和超压场景特征选用：

a）用于爆炸性环境时，确保爆破时不产生火花、静电；

b) 用于安全阀上游时,爆破不产生碎片;

c) 用于全液相的液体工况；

d）用于高黏度、易聚合、易结垢工况时，选用能横向冲刷表面的正拱形爆破片。

## V.3 爆破针阀选用

V.3.1 适用于爆破片装置的工况皆可用爆破针阀，且性能更稳定，精度更高。爆破针阀开启后可迅速

复位。可在外部更换爆破针，不要求定期检验和更换。

V.3.2 适用于存在变动背压的工况。

V.3.3 适用于压力和/或温度循环工况。

V.3.4 适用于高达 95% 操作比(即最大系统操作压力与爆破压力或弯折压力之比)的工况。

V.3.5 适用于单相流和多相流工况。

V.3.6 适用于火炬系统和气体回收系统调节阀或阻火器的旁路。

## V.4 爆破片装置或爆破针阀与安全阀的组合使用

V.4.1 串联使用时,爆破片装置或爆破针阀设置在安全阀入口:

a）保护安全阀不受工艺介质腐蚀、堵塞或背压影响；

b) 防止安全阀泄漏；

c) 减少爆破片破裂后泄放损失；

d) 安全阀的在线检测。

V.4.2 串联使用时，爆破片装置在安全阀出口，保护安全阀不受泄放总管中气体腐蚀。

V.4.3 爆破片装置或爆破针阀串联在安全阀入口侧时，爆破片的爆破或爆破针阀的折弯不影响安全阀的正常工作，在爆破片装置或爆破针阀动作后，并确保安全阀也能相应动作。爆破片装置或爆破针阀与安全阀之间的腔体需设置排气口、压力表或其他报警指示器。

V.4.4 爆破片装置或爆破针阀串联在安全阀出口侧时，需保证安全阀与爆破片装置或爆破针阀之间出现累积压力时安全阀仍能在整定压力下开启。同时，爆破片装置或爆破针阀与安全阀之间的腔体需设置排气口或排液口。

V.4.5 并联使用时，作为备用装置持续超压保护。分级设定几个安全泄放装置适用于泄放量大、可能有多种超压场景等场合。

# 附录 W

(资料性)

阻火器类别和选用

## W.1 阻火器类别

阻火器类别如图 W.1 所示。

![](images/bb8002f61b046913db1d581273b906fb6f23ff1f5a711193c4a925df3730cee2.jpg)  
图 W.1 阻火器的类别

## W.2 阻火器选用

W.2.1 根据可燃气体和蒸气 MESG、阻火器安装位置、燃烧过程时间、爆炸过程特征、保护端管道特征以及工艺过程要求(设计温度和压力、最大流量、允许压力降和管道布置等)确定阻火器的类别和规格。典型阻火器的选用见图 W.2 所示。

W.2.2 阻火器选用的注意事项：

a）管端型阻火器不能作为管道型阻火器使用；

b) 管道型阻火器不耐长时间燃烧；

c）管道型阻稳定爆轰阻火器的安装需避开不稳定爆轰位置；

d) 阻火器产品测试包括阻爆燃/轰性能、耐燃烧时间、流量和压力降等。

![](images/90d0ebe8f013eb407ded5841b177d33b9adc5baed423aab810ec9d2c319fac59.jpg)

标引序号说明：

1——管道阻爆轰阻火器；

2——管道阻爆燃阻火器；

3——全天候阻火呼吸阀；

图 W.2 典型阻火器的选用

4——管道阻爆燃或耐烧阻火器；

5——液体阻火器。

附录 X

(资料性)

可燃气体和蒸气的MESG和爆炸级别

X.1 典型的纯组分可燃气体和蒸气 MESG 和爆炸级别可见 IEC 60079-20-1，如表 X.1 所示。

表 X.1 典型的可燃气体和蒸气 MESG 及爆炸级别

<table><tr><td rowspan="2">序号</td><td rowspan="2">CAS NO.</td><td colspan="3">名称和分子式</td><td rowspan="2">MESG/mm</td><td rowspan="2">爆炸级别</td></tr><tr><td>中文名</td><td>英文名</td><td>分子式</td></tr><tr><td>1</td><td>67-56-1</td><td>甲醇</td><td>Methanol</td><td> $CH_4O$ </td><td>0.92</td><td>II A</td></tr><tr><td>2</td><td>64-17-5</td><td>乙醇</td><td>Ethanol</td><td> $C_2H_6O$ </td><td>0.89</td><td>II B3</td></tr><tr><td>3</td><td>71-36-3</td><td>正丁醇</td><td>n-butyl alcohol</td><td> $CH_3(CH_2)_3OH$ </td><td>0.87</td><td>II B1</td></tr><tr><td>4</td><td>71-36-3</td><td>异丁醇</td><td>Iso-butyl alcohol</td><td> $CH_3(CH_2)_3OH$ </td><td>0.87</td><td>II B1</td></tr><tr><td>5</td><td>71-41-0</td><td>正戊醇</td><td>n-amyl alcohol</td><td> $C_5H_{12}O$ </td><td>0.99</td><td>II A</td></tr><tr><td>6</td><td>107-18-6</td><td>烯丙醇</td><td>Allyl alcohol</td><td> $CHCH_2OH$ </td><td>0.84</td><td>II B2</td></tr><tr><td>7</td><td>75-07-0</td><td>乙醛</td><td>Acetaldehyde</td><td> $CH_3CHO$ </td><td>0.92</td><td>II A</td></tr><tr><td>8</td><td>123-72-8</td><td>正丁醛</td><td>n-butyraldehyde</td><td> $CH_3(CH_2)_2CHO$ </td><td>0.92</td><td>II A</td></tr><tr><td>9</td><td>107-02-8</td><td>丙烯醛</td><td>Acrolein</td><td> $C_3H_4O$ </td><td>0.72</td><td>II B3</td></tr><tr><td>10</td><td>4170-30-3</td><td>巴豆醛</td><td>Crotonaldehyde</td><td> $C_4H_6O$ </td><td>0.81</td><td>II B1</td></tr><tr><td>11</td><td>74-82-8</td><td>甲烷</td><td>Methane</td><td> $CH_4$ </td><td>1.14</td><td>II A1</td></tr><tr><td>12</td><td>74-84-0</td><td>乙烷</td><td>Ethane</td><td> $C_2H_6$ </td><td>0.91</td><td>II A</td></tr><tr><td>13</td><td>74-98-6</td><td>丙烷</td><td>Propane</td><td> $C_3H_8$ </td><td>0.92</td><td>II A</td></tr><tr><td>14</td><td>106-97-8</td><td>丁烷</td><td>Butane</td><td> $C_4H_{10}$ </td><td>0.98</td><td>II A</td></tr><tr><td>15</td><td>109-66-0</td><td>正戊烷</td><td>n-pentane</td><td> $C_5H_{12}$ </td><td>0.93</td><td>II A</td></tr><tr><td>16</td><td>110-54-3</td><td>正己烷</td><td>n-hexane</td><td> $C_6H_{14}$ </td><td>0.93</td><td>II A</td></tr><tr><td>17</td><td>142-82-5</td><td>正庚烷</td><td>n-heptane</td><td> $C_7H_{16}$ </td><td>0.91</td><td>II A</td></tr><tr><td>18</td><td>111-65-9</td><td>辛烷</td><td>Octanes</td><td> $C_8H_{18}$ </td><td>0.94</td><td>II A</td></tr><tr><td>19</td><td>110-82-7</td><td>环己烷</td><td>Cyclohexane</td><td> $C_6H_{12}$ </td><td>0.94</td><td>II A</td></tr><tr><td>20</td><td>109-89-7</td><td>二乙胺</td><td>Diethylamine</td><td> $C_4H_{11}N$ </td><td>1.15</td><td>II A1</td></tr><tr><td>21</td><td>75-50-3</td><td>三甲胺</td><td>Trimethylamine</td><td> $C_3H_9N$ </td><td>1.05</td><td>II A</td></tr><tr><td>22</td><td>107-15-3</td><td>乙二胺</td><td>Ethylenediamine</td><td> $C_2H_8N_2$ </td><td>1.25</td><td>II A1</td></tr><tr><td>23</td><td>71-43-2</td><td>苯</td><td>Benzene</td><td> $C_6H_6$ </td><td>0.99</td><td>II A</td></tr><tr><td>24</td><td>106-42-3</td><td>对二甲苯</td><td>p-xylene</td><td> $C_8H_{10}$ </td><td>1.09</td><td>II A</td></tr><tr><td>25</td><td>79-20-9</td><td>醋酸甲酯</td><td>Methyl acetate</td><td> $C_3H_6O_2$ </td><td>0.97</td><td>II A</td></tr><tr><td>26</td><td>141-78-6</td><td>乙酸乙酯</td><td>Ethyl acetate</td><td> $C_4H_8O_2$ </td><td>0.95</td><td>II A</td></tr><tr><td>27</td><td>109-60-4</td><td>醋酸正丙酯</td><td>n-propyl acetate</td><td> $C_5H_{10}O_2$ </td><td>1.04</td><td>II A</td></tr><tr><td>28</td><td>123-86-4</td><td>醋酸正丁酯</td><td>n-butyl acetate</td><td> $C_6H_{12}O_2$ </td><td>1.02</td><td>II A</td></tr><tr><td>29</td><td>108-05-4</td><td>醋酸乙烯酯</td><td>Vinyl acetate</td><td> $C_4H_6O_2$ </td><td>0.93</td><td>II A</td></tr><tr><td>30</td><td>140-88-5</td><td>丙烯酸乙酯</td><td>Ethyl acrylate</td><td> $C_5H_8O_2$ </td><td>0.86</td><td>II B1</td></tr><tr><td>31</td><td>60-29-7</td><td>二乙醚</td><td>Diethyl ether</td><td> $C_4H_{10}O$ </td><td>0.87</td><td>II B1</td></tr><tr><td>32</td><td>108-20-3</td><td>二异丙基醚</td><td>di-isopropyl ether</td><td> $C_6H_{14}O$ </td><td>0.94</td><td>II A</td></tr><tr><td>33</td><td>75-21-8</td><td>环氧乙烷</td><td>Ethylene oxide</td><td> $C_2H_4O$ </td><td>0.59</td><td>II B</td></tr><tr><td>34</td><td>75-56-9</td><td>环氧丙烷</td><td>Propylene oxide</td><td> $C_3H_6O$ </td><td>0.7</td><td>II B</td></tr><tr><td>35</td><td>109-99-9</td><td>四氢呋喃</td><td>Tetrahydrofuran</td><td> $C_4H_8O$ </td><td>0.87</td><td>II B1</td></tr><tr><td>36</td><td>110-91-8</td><td>吗啉</td><td>Morpholine</td><td> $C_4H_9NO$ </td><td>0.92</td><td>II A</td></tr><tr><td>37</td><td>106-89-8</td><td>环氧氯丙烷</td><td>Epichlorohydrin</td><td> $C_3H_5ClO$ </td><td>0.74</td><td>II B3</td></tr><tr><td>38</td><td>75-01-4</td><td>氯乙烯</td><td>Vinyl chloride</td><td> $C_2H_3Cl$ </td><td>0.96</td><td>II A</td></tr><tr><td>39</td><td>67-64-1</td><td>丙酮</td><td>Acetone</td><td> $CH_3COCH_3$ </td><td>1.04</td><td>II A</td></tr><tr><td>40</td><td>78-93-3</td><td>丁酮</td><td>Methyl ethyl ketone</td><td> $CH_3COCH_2CH_3$ </td><td>0.85</td><td>II B1</td></tr><tr><td>41</td><td>141-79-7</td><td>亚异丙基丙酮</td><td>Mesityl oxide</td><td> $C_6H_{10}O$ </td><td>0.93</td><td>II A</td></tr><tr><td>42</td><td>107-13-1</td><td>丙烯腈</td><td>Acrylonitrile</td><td> $C_3H_3N$ </td><td>0.87</td><td>II B1</td></tr><tr><td>43</td><td>74-85-1</td><td>乙烯</td><td>Ethylene</td><td> $C_2H_4$ </td><td>0.65</td><td>II B3</td></tr><tr><td>44</td><td>115-07-1</td><td>丙烯</td><td>Propylene</td><td> $C_3H_6$ </td><td>0.95</td><td>II A</td></tr><tr><td>45</td><td>106-99-0</td><td>1,3-丁二烯</td><td>1,3-butadiene</td><td> $C_4H_6$ </td><td>0.79</td><td>II B3</td></tr><tr><td>46</td><td>78-79-5</td><td>异戊二烯</td><td>Isoprene</td><td> $C_5H_8$ </td><td>0.81</td><td>II B2</td></tr><tr><td>47</td><td>74-86-2</td><td>乙炔</td><td>Acetylene</td><td> $C_2H_2$ </td><td>0.37</td><td>II C</td></tr><tr><td>48</td><td>7664-41-7</td><td>氨</td><td>Ammonia</td><td> $NH_3$ </td><td>3.18</td><td>II A1</td></tr><tr><td>49</td><td>75-15-0</td><td>二硫化碳</td><td>Carbon disulfide</td><td> $CS_2$ </td><td>0.34</td><td>II C</td></tr><tr><td>50</td><td>630-08-0</td><td>一氧化碳</td><td>Carbon monoxide</td><td>CO</td><td>0.94</td><td>II A</td></tr><tr><td>51</td><td>1333-74-0</td><td>氢</td><td>Hydrogen</td><td> $H_2$ </td><td>0.29</td><td>II C</td></tr><tr><td>52</td><td>7783-06-4</td><td>硫化氢</td><td>Hydrogen sulfide</td><td> $H_2S$ </td><td>0.83</td><td>II B2</td></tr><tr><td>53</td><td>50-00-0</td><td>甲醛</td><td>Formaldehyde</td><td>HCHO</td><td>0.57</td><td>II B</td></tr><tr><td>54</td><td>57-14-7</td><td>偏二甲肼</td><td>Dimethylhydrazine</td><td> $C_2H_8N_2$ </td><td>0.85</td><td>II B1</td></tr><tr><td>55</td><td>71-23-8</td><td>正丙醇</td><td>n-propanol</td><td> $CH_3CH_2CH_2OH$ </td><td>0.89</td><td>II B1</td></tr><tr><td>56</td><td>74-90-8</td><td>氰化氢</td><td>Hydrogen cyanide</td><td>HCN</td><td>0.8</td><td>II B2</td></tr><tr><td>57</td><td>79-09-4</td><td>丙酸</td><td>Propionic acid</td><td> $CH_3CH_2COOH$ </td><td>1.1</td><td>II A</td></tr><tr><td>58</td><td>79-10-7</td><td>丙烯酸</td><td>Acrylic acid</td><td> $C_3H_4O_2$ </td><td>0.86</td><td>II B1</td></tr><tr><td>59</td><td>79-24-3</td><td>硝基乙烷</td><td>Nitroethane</td><td> $C_2H_5NO_2$ </td><td>0.87</td><td>II B1</td></tr><tr><td>60</td><td>96-33-3</td><td>丙烯酸甲酯</td><td>Methyl acrylate</td><td> $C_4H_6O_2$ </td><td>0.85</td><td>II B1</td></tr><tr><td>61</td><td>98-00-0</td><td>糠醇</td><td>Furfuryl alcohol</td><td> $C_5H_6O_2$ </td><td>0.8</td><td>II B2</td></tr><tr><td>62</td><td>98-83-9</td><td>α-甲基苯乙烯</td><td>Alpha-Methylstyrene</td><td> $C_9H_{10}$ </td><td>0.88</td><td>II B1</td></tr><tr><td>63</td><td>103-09-3</td><td>2-乙基己醇乙酸酯</td><td>2-Ethylhexyl acetate</td><td> $C_{10}H_{20}O_2$ </td><td>0.88</td><td>II B1</td></tr><tr><td>64</td><td>105-45-3</td><td>乙酰乙酸甲酯</td><td>Methyl acetoacetate</td><td> $C_5H_8O_3$ </td><td>0.85</td><td>II B1</td></tr><tr><td>65</td><td>105-58-8</td><td>碳酸二乙酯</td><td>Diethyl carbonate</td><td> $C_5H_{10}O_3$ </td><td>0.83</td><td>II B2</td></tr><tr><td>66</td><td>106-89-8</td><td>环氧氯丙烷</td><td>Epichlorohydrin</td><td> $C_3H_5ClO$ </td><td>0.74</td><td>II B3</td></tr><tr><td>67</td><td>106-92-3</td><td>烯丙基缩水甘油醚</td><td>Allyl glycidyl ether</td><td> $C_6H_{10}O_2$ </td><td>0.7</td><td>II B3</td></tr><tr><td>68</td><td>107-00-6</td><td>丁炔</td><td>1-butyne</td><td> $C_4H_6$ </td><td>0.71</td><td>II B3</td></tr><tr><td>69</td><td>107-19-7</td><td>炔丙醇</td><td>Propargyl alcohol</td><td> $C_3H_4O$ </td><td>0.58</td><td>II B</td></tr><tr><td>70</td><td>108-03-2</td><td>1-硝基丙烷</td><td>1-nitropropane</td><td> $CH_3CH_2CH_2NO_2$ </td><td>0.84</td><td>II B2</td></tr><tr><td>71</td><td>109-86-4</td><td>乙二醇甲醚</td><td>2-methoxyethanol</td><td> $HOCH_2CH_2OCH_3$ </td><td>0.85</td><td>II B1</td></tr><tr><td>72</td><td>109-87-5</td><td>二甲氧基甲烷</td><td>Dimethoxymethane</td><td> $C_3H_8O_2$ </td><td>0.86</td><td>II B1</td></tr><tr><td>73</td><td>110-00-9</td><td>呋喃</td><td>Oxole</td><td>CH=CHCH=CHO</td><td>0.68</td><td>II B3</td></tr><tr><td>74</td><td>110-05-4</td><td>过氧化二叔丁基</td><td>Di-tert-butyl peroxide</td><td> $C_8H_{18}O_2$ </td><td>0.84</td><td>II B2</td></tr></table>

X.2 多组分可燃气体和蒸气 MESG 的确定。

a）采用标准方法进行测试，或咨询有关部门。

b) 采用最小 MESG 作为混合气体的 MESG。

c) 采用加和法, 按公式(X.1)计算混合物 MESG:

$$
\mathrm{MESG} _ {\min} = \frac {1}{\sum_ {i} \left(\frac {X _ {i}}{\mathrm{MESG} _ {i}}\right)}
$$

……(X.1)

式中：

$MESG_{min}$ ——混合物最大试验安全间隙,单位为毫米(mm);

$MESG_{i}$ ——混合物中 i 组分的最大试验安全间隙, 单位为毫米(mm);

其中可燃组分从表X.1查得。对于氮气等惰性组分，当其最大体积分数小于0.05时，MESG值取无穷大；当其最大体积分数大于或等于0.05时，取2。

$X_{i}$ ——混合物中组分 i 的体积分数。

d) 含有催化作用组分的混合气体危险性可能比 MESG 最小组分更大。

X.3 温度升高或压力增加,都会使 MESG 减小。

## 参考文献

[1] GB/T 3077 合金结构钢

[2] GB/T 3840 制定地方大气污染物排放标准的技术方法

[3] GB/T 19672 管线阀门 技术条件

[4] GB/T 20173 石油天然气工业 管道输送系统 管道阀门

[5] GB/T 20972.1 石油天然气工业 油气开采中用于含硫化氢环境的材料 第1部分:选择抗裂纹材料的一般原则

[6] GB/T 20972.2 石油天然气工业 油气开采中用于含硫化氢环境的材料 第2部分:抗开裂碳钢、低合金钢和铸铁

[7] GB/T 20972.3 石油天然气工业 油气开采中用于含硫化氢环境的材料 第3部分:抗开裂耐蚀合金和其他合金

[8] GB/T 21385 金属密封球阀

[9] GB/T 21387 轴流式止回阀

[10] GB/T 22130 钢制旋塞阀

[11] GB/T 24921.1 石化工业用压力释放阀的尺寸确定、选型和安装 第1部分:尺寸的确定和选型

[12] GB/T 24924 供水系统用弹性密封闸阀

[13] GB/T 24925 低温阀门 技术条件

[14] GB/T 26144 法兰和对夹连接钢制衬氟塑料蝶阀

[15] GB/T 26146 偏心半球阀

[16] GB/T 26479 弹性密封部分回转阀门 耐火试验

[17] GB/T 26482 止回阀 耐火试验

[18] GB/T 28776 石油和天然气工业用钢制闸阀、截止阀和止回阀( $\leqslant$ DN100)

[19] GB 31570 石油炼制工业污染物排放标准

[20] GB 31571 石油化学工业污染物排放标准

[21] JB/T 6902 阀门液体渗透检查方法

[22] JB/T 7746 紧凑型锻钢阀门

[23] JB/T 8691 无阀盖刀形闸阀

[24] JB/T 10673 撑开式金属密封阀门

[25] JB/T 11152 金属密封提升式旋塞阀

[26] SH 3009—2013 石油化工可燃性气体排放系统设计规范

[27] SH/T 3554—2013 石油化工钢制管道焊接热处理规范

[28] SY/T 6746 倒密封阀耐火试验规范

[29] TSG D0001 压力管道安全技术监察规程——工业管道

[30] ISO 898-1 Mechanical properties of fasteners made of carbon steel and alloy steel—Part 1: Bolts, screws and studs with specified property classes—Coarse thread and fine pitch thread

[31] ISO 3506-4 Fasteners—Mechanical properties of corrosion-resistant stainless steel fasteners—Part 4: Tapping screws with specified grades and hardness classes

[32] ISO 5208 Industrial valves—Pressure testing of metallic valves

[33] ISO 10497 Testing of valves—Fire type-testing requirements

[34] ISO 15590-2 Petroleum and natural gas industries—Factory bends, fittings and flanges

for pipeline transportation systems—Part 2: Fittings

[35] ISO 15590-3 Petroleum and natural gas industries—Factory bends, fittings and flanges for pipeline transportation systems—Part 3: Flanges

[36] ISO 15848-2 Industrial valves—Measurement, test and qualification procedures for fugitive emissions —Part 2: Production acceptance test of valves

[37] ISO 17945/NACE MR0103—2015 Petroleum, petrochemical and natural gas industries—metallic materials resistant to sulfide stress cracking in corrosive petroleum refining environments

[38] IEC 60079-20-1 Explosive atmospheres—Part 20-1: Material characteristics for gas and vapour classification-test methods and data

[39] API 5L Specification for Line Pipe

[40] API 6D Specification for Valves

[41] API 6FA Standard for Fire Test of Valves

[42] API 6FB Standard for Fire Test for End Connectors

[43] API 6FC Specification for Fire Test for Valves with Automatic Backseats

[44] API 6FD Specification for Fire Test for Check Valves

[45] API 579-1/ASME FFS-1—2007 Fitness For Service

[46] API 593 Ductile Iron Plug Valves, Flanged Ends

[47] API 594 Check Valves: Flanged, Lug, Wafer and Butt-welding

[48] API 598 Valve Inspection and Testing

[49] API 599 Metal Plug Valves-Flanged and Welding Ends

[50] API 600 Steel Gate Valves-Flanged and Butt-welding Ends, Bolted Bonnets

[51] API 602 Gate, Globe, and Check Valves for Sizes DN 100 (NPS4) and Smaller for the Petroleum and Natural Gas Industries

[52] API 603 Corrosion-resistant, Bolted Bonnet Gate Valves-Flanged and Butt-welding Ends

[53] API 607 Fire Test for Quarter-turn Valves and Valves Equipped with Nonmetallic Seats

[54] API 608 Metal Ball Valves-Flanged and Butt-Welding Ends

[55] API 609 Butterfly Valves: Double-flanged, Lug-and Wafer-Type

[56] API 622 Type Testing of Process Valve Packing for Fugitive Emissions

[57] API 624 Type Testing of Rising Stem Valves Equipped with Graphite Packing for Fugitive Emissions

[58] API 641 Type Testing of Quarter-turn Valves for Fugitive Emissions

[59] API STD 593 ductile iron plug valves, flanged ends

[60] API STD 599 Metal Plug Valves—Flanged, Threaded, and Welding Ends

[61] API RP 941—2016 Steels for Hydrogen Service at Elevated Temperatures and Pressures in Petroleum Refineries and Petrochemical Plants

[62] API STD 520-1 Sizing, selection and installation of pressure-relieving devices—Part 1: Sizing and selection

[63] API STD 530—2015 Calculation method of wall thickness of heating pipe in oil refinery

[64] ASME B16.34 Valves-Flange connection, threaded connection and welded ends

[65] ASME B16.104 Control Valve Seat Leakage

[66] ASME B31.3 Process Piping

[67] ASME B31.12 Hydrogen Piping and Pipelines

[68] ASME II-D Materials Part D Properties

[69] ASME III-1 NH Rules for Construction of Nuclear Facility Components Division 1-Subsection NH

[70] ASME VIII-2—2023 Rules for Construction of Pressure Vessels-Division 2: Alternative Rules 2023

[71] ASTM A47 Standard Specification for Ferritic Malleable Iron Castings

[72] ASTM A48 Standard Specification for Gray Iron Castings

[73] ASTM A53 Standard Specification for Pipe, Steel, Black and Hot-Dipped, Zinc-Coated, Welded and Seamless

[74] ASTM A105 Standard Specification for Carbon Steel Forgings for Piping Applications

[75] ASTM A106 Standard Specification for Seamless Carbon Steel Pipe for High-Temperature Service

[76] ASTM A134 Standard Specification for Pipe, Steel, Electric-Fusion (Arc)-Welded (Sizes NPS 16 and Over)

[77] ASTM A181 Standard Specification for Carbon Steel Forgings, for General-Purpose Pip-
ing

[78] ASTM A193 Standard Specification for Alloy-Steel and Stainless Steel Bolting for High Temperature or High Pressure Service and Other Special Purpose Applications

[79] ASTM A216 Standard Specification for Steel Castings, Carbon, Suitable for Fusion Welding, for High-Temperature Service

[80] ASTM A217 Standard Specification for Steel Castings, Martensitic Stainless and Alloy, for Pressure-Containing Parts, Suitable for High-Temperature Service

[81] ASTM A234 Standard Specification for Piping Fittings of Wrought Carbon Steel and Alloy Steel for Moderate and High Temperature Service

[82] ASTM A262—2015(2021) Standard Practices for Detecting Susceptibility to Intergranular Attack in Austenitic Stainless Steels

[83] ASTM A312 Standard Specification for Seamless, Welded, and Heavily Cold Worked Austenitic Stainless Steel Pipes

[84] ASTM A320 Standard Specification for Alloy-Steel and Stainless Steel Bolting for Low-Temperature Service

[85] ASTM A333 Standard Specification for Seamless and Welded Steel Pipe for Low-Temperature Service and Other Applications with Required Notch Toughness

[86] ASTM A335 Standard Specification for Seamless Ferritic Alloy-Steel Pipe for High-Temperature Service

[87] ASTM A350 Standard Specification for Carbon and Low-Alloy Steel Forgings, Requiring Notch Toughness Testing for Piping Components

[88] ASTM A351 Standard Specification for Castings, Austenitic, for Pressure-Containing Parts

[89] ASTM A352 Standard Specification for Steel Castings, Ferritic and Martensitic, for Pressure-Containing Parts, Suitable for Low-Temperature Service

[90] ASTM A358 Standard Specification for Electric-Fusion-Welded Austenitic Chromium-Nickel Stainless Steel Pipe for High-Temperature Service and General Applications

[91] ASTM A369 Standard Specification for Carbon and Ferritic Alloy Steel Forged and Bored Pipe for High-Temperature Service

[92] ASTM A388 Standard Practice for Ultrasonic Examination of Steel Forgings

[93] ASTM A395 Standard Specification for Ferritic Ductile Iron Pressure-Retaining Castings

for Use at Elevated Temperatures

[94] ASTM A403 Standard Specification for Wrought Austenitic Stainless Steel Piping Fittings

[95] ASTM A420 Standard Specification for Piping Fittings of Wrought Carbon Steel and Alloy Steel for Low-Temperature Service

[96] ASTM A453 Standard Specification for High-Temperature Bolting, with Expansion Coefficients Comparable to Austenitic Stainless Steels

[97] ASTM A609 Standard Practice for Castings, Carbon, Low-Alloy, and Martensitic Stainless Steel, Ultrasonic Examination Thereof

[98] ASTM A671 Standard Specification for Electric-Fusion-Welded Steel Pipe for Atmospheric and Lower Temperatures

[99] ASTM A672 Standard Specification for Electric-Fusion-Welded Steel Pipe for High-Pressure Service at Moderate Temperatures

[100] ASTM A691 Standard Specification for Carbon and Alloy Steel Pipe, Electric-Fusion-Welded for High-Pressure Service at High Temperatures

[101] ASTM A694 Standard Specification for Carbon and Alloy Steel Forgings for Pipe Flanges, Fittings, Valves, and Parts for High-Pressure Transmission Service

[102] ASTM A790 Standard Specification for Seamless and Welded Ferritic/Austenitic Stainless Steel Pipe

[103] ASTM A815 Standard Specification for Wrought Ferritic, Ferritic/Austenitic, and Martensitic Stainless Steel Piping Fittings

[104] ASTM A923 Standard Test Methods for Detecting Detrimental Intermetallic Phase in Duplex Austenitic/Ferritic Stainless Steels

[105] ASTM B161 Standard Specification for Nickel Seamless Pipe and Tube

[106] ASTM B165 Standard Specification for Nickel-Copper Alloy Seamless Pipe and Tube

[107] ASTM B167 Standard Specification for Nickel-Chromium-Aluminum Alloys, Nickel-Chromium-Iron Alloys, Nickel-Chromium-Cobalt-Molybdenum Alloy, Nickel-Iron-Chromium-Tungsten Alloy, and Nickel-Chromium-Molybdenum-Copper Alloy Seamless Pipe and Tube

[108] ASTM B210 Standard Specification for Aluminum and Aluminum-Alloy Drawn Seamless Tubes

[109] ASTM B247 Standard Specification for Aluminum and Aluminum-Alloy Die Forgings, Hand Forgings, and Rolled Ring Forgings

[110] ASTM B361 Standard Specification for Factory-Made Wrought Aluminum and Aluminum-Alloy Welding Fittings

[111] ASTM B363 Standard Specification for Seamless and Welded Unalloyed Titanium and Titanium Alloy Welding Fittings

[112] ASTM B366 Standard Specification for Factory-Made Wrought Nickel and Nickel Alloy Fittings

[113] ASTM B367 Standard Specification for Titanium and Titanium Alloy Castings

[114] ASTM B381 Standard Specification for Titanium and Titanium Alloy Forgings

[115] ASTM B407 Standard Specification for Nickel-Iron-Chromium Alloy Seamless Pipe and Tube

[116] ASTM B444 Standard Specification for Nickel-Chromium-Molybdenum-Niobium Alloys and Nickel-Chromium-Molybdenum-Silicon Alloy Pipe and Tube

[117] ASTM B564 Standard Specification for Nickel Alloy Forgings

[118] ASTM B622 Standard Specification for Seamless Nickel and Nickel-Cobalt Alloy Pipe and Tube

[119] ASTM B705 Standard Specification for Nickel-Chromium-Molybdenum-Niobium Alloy, Nickel-Chromium-Molybdenum-Silicon Alloy, and Nickel-Iron-Chromium-Molybdenum-Copper Alloy Welded Pipe

[120] ASTM B861 Standard Specification for Titanium and Titanium Alloy Seamless Pipe

[121] ASTM B862 Standard Specification for Titanium and Titanium Alloy Welded Pipe

[122] ASTM E165 Standard Practice for Liquid Penetrant Testing for General Industry

[123] ASTM E709 Standard Guide for Magnetic Particle Testing

[124] ASTM G48 Standard Test Methods for Pitting and Crevice Corrosion Resistance of Stainless Steels and Related Alloys by Use of Ferric Chloride Solution

[125] AWS A5.4 Specification for Stainless Steel Electrodes for Shielded Metal Arc Welding

[126] AWWA C209 Tape Coatings for Steel Water Pipe and Fittings

[127] AWWA C504 Rubber-Seated Butterfly Valves

[128] BS 1868 Specification for Steel check valves (flanged and butt-welding ends) for the petroleum, petrochemical and allied industries

[129] BS 1873 Specification for Steel Globe and Globe Stop and Check Valves (Flanged and Butt-Welding Ends) for the Petroleum, Petrochemical and Allied Industries

[130] BS 5351 Specification for Steel Ball Valves for the Petroleum, Petrochemical and Allied Industries

[131] BS 6364 Specification for Valves for Cryogenic Service

[132] EN 13480.3 Metallic industrial piping—Part 3: Design and calculation

[133] MSS SP54 Quality Standard for Steel Castings for Valves, Flanges and Fittings and Other Piping Components—Radiographic Examination Method

[134] MSS SP55 Quality Standard for Steel Castings for Valves, Flanges and Fittings and Other Piping Components—Visual Method for Evaluation of Surface Irregularities

[135] MSS SP75 High-Strength, Wrought, Butt-Welding Fittings

[136] NACE MR0175 Petroleum and natural gas industries-Materials for use in H2S-containing environments in oil and gas production-Parts 1,2,and 3

[137] 危险化学品目录(2022 调整版)[S]. 北京: 中华人民共和国工业和信息化部, 2022.

[138] 关于危险货物运输的建议书 试验和标准手册[S]. 纽约: 联合国, 2023.

[139] 美国化工过程安全中心.保护层分析:简化的过程风险评估[M].白永忠,党文义,于安峰,译.北京:中国石化出版社,2010.

[140] [英]布赖恩·内斯比特(Brian Nesbitt). 阀门和驱动装置技术手册[M]. 张双清, 尹玉杰, 李树勋, 等译. 北京: 化学工业出版社, 2010, 197-216.

[141] Michael Beyer(Germany, PTB). 防爆非电气设备的点燃危险评估方法 [C]//2003 国际工业防爆技术论坛, 中国上海: 2003.