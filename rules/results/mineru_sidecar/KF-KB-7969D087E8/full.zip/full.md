# 中华人民共和国国家标准

GB/T 5117—2012

代替 GB/T 5117—1995

# 非合金钢及细晶粒钢焊条

# Covered electrodes for manual metal arc welding of non-alloy and fine grain steels

# (ISO 2560:2009, Welding consumables—Covered electrodes for manual metal arc welding of non-alloy and fine grain steels—Classification, MOD)

2012-11-05 发布

2013-03-01 实施

## 目次

前言 …… I
1 范围 …… 1
2 规范性引用文件 …… 1
3 型号 …… 1
4 技术要求 …… 4
5 试验方法 …… 15
6 检验规则 …… 17
7 包装、标志和质量证明 …… 18
附录 A（资料性附录） 焊条药皮类型 …… 19
附录 B（资料性附录） 焊条型号对照 …… 22
附录 C（资料性附录） 扩散氢相关说明 …… 26

## 前言

本标准按照 GB/T 1.1—2009 给出的规则起草。

本标准是对 GB/T 5117—1995《碳钢焊条》的修订。与 GB/T 5117—1995 相比，主要修改内容如下：

——标准名称修改为“非合金钢及细晶粒钢焊条”；

——增加了耐候钢焊条的技术要求，与原碳钢焊条一起统列入非合金钢类焊条；

——按本标准抗拉强度范围，增加了 GB/T 5118—1995《低合金钢焊条》中的所有碳钼钢、镍钢、镍钼钢焊条型号，以及锰钼钢焊条型号中的 E5515-D3、E5516-D3、E5518-D3，其他低合金焊条型号中的 E5018W、E5518W 等焊条的技术要求。这些型号按 ISO 2560:2009 重新进行了编制；

——删除了 E4322、E4323、E5018M、E5023 四个焊条型号,其余焊条的型号分类按 ISO 2560:2009 要求;

——型号编制采用国际标准编制方法，将 GB/T 5117—1995 中 E4300 修改为 E4340, E4301 修改为 E4319, E5001 修改为 E5019；

——删除了药皮含水量的技术要求；

——对于抗拉强度代号“43”的焊条型号,其熔敷金属抗拉强度最小值按 ISO 2560:2009 由 420MPa 提高到 430MPa;

——焊条的技术要求按 ISO 2560:2009, 对熔敷金属化学成分进行了相应调整, 对熔敷金属断后伸长率要求进行了适当的降低。

本标准使用重新起草法修改采用国际标准 ISO 2560:2009《焊接材料 非合金钢和细晶粒钢焊条电弧焊用药皮焊条 分类》(英文版)。

本标准与 ISO 2560:2009 的主要技术性差异及其原因如下：

——删除了规范性引用文件中引用的国际标准,直接引用我国已相应转化的国内相应标准,便于执行;

—将熔敷金属抗拉强度代号“49”修改为“50”。热处理状态代号中，焊态代号由“A”修改为“无标记”，以适用我国技术条件；

——保留了 E4315 和 E4328 两个焊条型号，引入了 GB/T 5118—1995 中 E5003-A1（型号编制为 E5003-1M3）、E5515-C1（型号编制为 E5515-N5）、E5515-C3（型号编制为 E5515-N2）、E5515-D3（型号编制为 E5515-3M3）四个焊条型号，这些型号焊条的技术要求按 ISO 2560:2009 进行了相应调整，以适用我国技术条件；

——增加了 E5015-N1、E5515-N1、E5015-N2、E5015-N3、E5515-N3、E5515-N7、E5515-N13 等 7 个焊条型号, 技术要求与其相对应的 EXX16-XX 型焊条技术要求相同, 以适应我国的药皮类型使用习惯;

对于 E4303、E4310、E4311、E4312、E4313、E4315、E4316、E4319、E4320、E4324、E4327、E4328、E4340、E5003 等 14 个焊条型号的熔敷金属化学成分 P 和 S 含量要求为: $P \leqslant 0.040$ , $S \leqslant 0.035$ , 以适用我国技术条件;

——对于 E5012 和 E5013 两个焊条型号的熔敷金属化学成分 P 和 S 含量的要求按其他焊条型号要求, 规定为 $P \leqslant 0.035, S \leqslant 0.035$ , 以适用我国技术条件;

——对于 E5016 焊条型号的熔敷金属化学成分 Mn 含量要求，由“Mn≤1.25”修改为“Mn≤1.60”，以适用我国技术条件；

对于力学性能试件制备,保留了“长度大于 450 mm 的焊条,试板长度不小于 500 mm。”的技术要求,以便于实际操作;

-保留了熔敷金属拉伸试样的去氢处理要求，以满足实际应用需求；

保留了 GB/T 5117—1995 中焊缝金属的射线探伤要求，以适用我国技术条件；

——保留了 GB/T 5117—1995 中焊条偏心度的技术要求，便于操作。

为便于使用,本标准还做了如下编辑性修改:

——标准结构方面，按型号、技术要求、试验方法、检验规则、包装、标志和质量证明进行编写。

本标准由全国焊接标准化技术委员会(SAC/TC 55)提出并归口。

本标准起草单位:哈尔滨焊接研究所、天津大桥焊材集团有限公司、天津市金桥焊材集团有限公司、建德市新安江电焊条有限公司、四川大西洋焊接材料股份有限公司、武汉铁锚焊接材料股份有限公司、淄博齐鲁焊业有限公司。

本标准起草人:储继君、李春范、高盛平、侯来昌、邵海建、蒋勇、王大梁、宋成、李勇。

本标准代替了 GB/T 5117—1995。

GB/T 5117—1995 的历次版本发布情况为：

—GB/T 5117—1967、GB/T 5117—1976、GB/T 5117—1985。

# 非合金钢及细晶粒钢焊条

## 1 范围

本标准规定了非合金钢及细晶粒钢焊条的型号、技术要求、试验方法、检验规则、包装、标志和质量证明。

本标准适用于抗拉强度低于 570 MPa 的非合金钢及细晶粒钢焊条。

## 2 规范性引用文件

下列文件对于本文件的应用是必不可少的。凡是注日期的引用文件，仅注日期的版本适用于本文件。凡是不注日期的引用文件，其最新版本(包括所有的修改单)适用于本文件。

GB/T 700 碳素结构钢（GB/T 700—2006, ISO 630:1995, NEQ）

GB/T 1591 低合金高强度结构钢

GB/T 2650 焊接接头冲击试验方法 (GB/T 2650—2008, ISO 9016:2001, IDT)

GB/T 2652 焊缝及熔敷金属拉伸试验方法 (GB/T 2652—2008, ISO 5178:2001, IDT)

GB/T 3323 金属熔化焊焊接接头射线照相

GB/T 3965 熔敷金属中扩散氢测定方法(GB/T 3965—2012, ISO 3690:2000, MOD)

GB/T 16672 焊缝 工作位置 倾角和转角的定义(GB/T 16672—1996, idt ISO 6947:1990)

GB/T 25774.1 焊接材料的检验 第1部分:钢、镍及镍合金熔敷金属力学性能试样的制备及检验(GB/T 25774.1—2010,ISO 15792-1:2000,MOD)

GB/T 25774.3 焊接材料的检验 第3部分:T型接头角焊缝试样的制备及检验(GB/T 25774.3—2010,ISO 15792-3:2000,IDT)

GB/T 25775 焊接材料供货技术条件 产品类型、尺寸、公差和标志(GB/T 25775—2010, ISO 544:2003, MOD)

GB/T 25777 焊接材料熔敷金属化学分析试样制备方法(GB/T 25777—2010, ISO 6847:2000, IDT)

GB/T 25778 焊接材料采购指南(GB/T 25778—2010, ISO 14344:2002, MOD)

## 3 型号

## 3.1 型号划分

焊条型号按熔敷金属力学性能、药皮类型、焊接位置、电流类型、熔敷金属化学成分和焊后状态等进行划分。药皮类型的简要说明参见附录 A，不同标准之间的型号对照参见附录 B。

## 3.2 型号编制方法

焊条型号由五部分组成：

a）第一部分用字母“E”表示焊条；

b) 第二部分为字母“E”后面的紧邻两位数字, 表示熔敷金属的最小抗拉强度代号, 见表1;

c) 第三部分为字母“E”后面的第三和第四两位数字, 表示药皮类型、焊接位置和电流类型, 见表 2;

d) 第四部分为熔敷金属的化学成分分类代号, 可为“无标记”或短划“一”后的字母、数字或字母和数字的组合, 见表 3;

e) 第五部分为熔敷金属的化学成分代号之后的焊后状态代号,其中“无标记”表示焊态,“P”表示热处理状态,“AP”表示焊态和焊后热处理两种状态均可。

除以上强制分类代号外，根据供需双方协商，可在型号后依次附加可选代号：

a) 字母“U”，表示在规定试验温度下，冲击吸收能量可以达到47J以上，见4.5.3；

b) 扩散氢代号“HX”，其中 X 代表 15、10 或 5，分别表示每 100 g 熔敷金属中扩散氢含量的最大值(mL)，见 4.7。

## 3.3 型号示例

示例 1:

![](images/2752e45dd46ef81ad29c7bc4f26912e1e0eb24237ba74f7821f3d7f4e745cedb.jpg)

示例 2:

![](images/d4f916dd35eb540c4bf24e8d60455194befc81dbd8776fee2ae7393e9c90da5d.jpg)

表 1 熔敷金属抗拉强度代号

<table><tr><td>抗拉强度代号</td><td>最小抗拉强度值MPa</td></tr><tr><td>43</td><td>430</td></tr><tr><td>50</td><td>490</td></tr><tr><td>55</td><td>550</td></tr><tr><td>57</td><td>570</td></tr></table>

表 2 药皮类型代号

<table><tr><td>代号</td><td>药皮类型</td><td>焊接位置a</td><td>电流类型</td></tr><tr><td>03</td><td>钛型</td><td>全位置b</td><td>交流和直流正、反接</td></tr><tr><td>10</td><td>纤维素</td><td>全位置</td><td>直流反接</td></tr><tr><td>11</td><td>纤维素</td><td>全位置</td><td>交流和直流反接</td></tr><tr><td>12代号</td><td>金红石药皮类型</td><td>全位置b $焊接位置^a$ </td><td>交流和直流正接电流类型</td></tr><tr><td>13</td><td>金红石</td><td> $全位置^b$ </td><td>交流和直流正、反接</td></tr><tr><td>14</td><td>金红石+铁粉</td><td> $全位置^b$ </td><td>交流和直流正、反接</td></tr><tr><td>15</td><td>碱性</td><td> $全位置^b$ </td><td>直流反接</td></tr><tr><td>16</td><td>碱性</td><td> $全位置^b$ </td><td>交流和直流反接</td></tr><tr><td>18</td><td>碱性+铁粉</td><td> $全位置^b$ </td><td>交流和直流反接</td></tr><tr><td>19</td><td>钛铁矿</td><td> $全位置^b$ </td><td>交流和直流正、反接</td></tr><tr><td>20</td><td>氧化铁</td><td>PA、PB</td><td>交流和直流正接</td></tr><tr><td>24</td><td>金红石+铁粉</td><td>PA、PB</td><td>交流和直流正、反接</td></tr><tr><td>27</td><td>氧化铁+铁粉</td><td>PA、PB</td><td>交流和直流正、反接</td></tr><tr><td>28</td><td>碱性+铁粉</td><td>PA、PB、PC</td><td>交流和直流反接</td></tr><tr><td>40</td><td>不做规定</td><td colspan="2">由制造商确定</td></tr><tr><td>45</td><td>碱性</td><td>全位置</td><td>直流反接</td></tr><tr><td>48</td><td>碱性</td><td>全位置</td><td>交流和直流反接</td></tr><tr><td colspan="4"> $^a$ 焊接位置见GB/T 16672,其中PA=平焊、PB=平角焊、PC=横焊、PG=向下立焊; $^b$ 此处“全位置”并不一定包含向下立焊,由制造商确定。</td></tr></table>

表 3 熔敷金属化学成分分类代号

<table><tr><td rowspan="2">分类代号</td><td colspan="5">主要化学成分的名义含量(质量分数)%</td></tr><tr><td>Mn</td><td>Ni</td><td>Cr</td><td>Mo</td><td>Cu</td></tr><tr><td>无标记、-1、-P1、-P2</td><td>1.0</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-1M3</td><td>—</td><td>—</td><td>—</td><td>0.5</td><td>—</td></tr><tr><td>-3M2</td><td>1.5</td><td>—</td><td>—</td><td>0.4</td><td>—</td></tr><tr><td>-3M3</td><td>1.5</td><td>—</td><td>—</td><td>0.5</td><td>—</td></tr><tr><td>-N1</td><td>—</td><td>0.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N2</td><td>—</td><td>1.0</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N3</td><td>—</td><td>1.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-3N3</td><td>1.5</td><td>1.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N5</td><td>—</td><td>2.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N7</td><td>—</td><td>3.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N13</td><td>—</td><td>6.5</td><td>—</td><td>—</td><td>—</td></tr><tr><td>-N2M3</td><td>—</td><td>1.0</td><td>—</td><td>0.5</td><td>—</td></tr><tr><td>-NC</td><td>—</td><td>0.5</td><td>—</td><td>—</td><td>0.4</td></tr><tr><td>-CC</td><td>—</td><td>—</td><td>0.5</td><td>—</td><td>0.4</td></tr><tr><td>-NCC</td><td>—</td><td>0.2</td><td>0.6</td><td>—</td><td>0.5</td></tr><tr><td>-NCC1</td><td>—</td><td>0.6</td><td>0.6</td><td>—</td><td>0.5</td></tr><tr><td>-NCC2</td><td>—</td><td>0.3</td><td>0.2</td><td>—</td><td>0.5</td></tr><tr><td>-G</td><td colspan="5">其他成分</td></tr></table>

## 4 技术要求

## 4.1 尺寸

焊条尺寸应符合 GB/T 25775 规定。

## 4.2 药皮

4.2.1 焊条药皮应均匀、紧密地包覆在焊芯周围，焊条药皮上不应有影响焊接质量的裂纹、气泡、杂质及脱落等缺陷。

4.2.2 焊条引弧端药皮应倒角，焊芯端面应露出。焊条沿圆周的露芯应不大于圆周的1/2。碱性药皮类型焊条长度方向上露芯长度应不大于焊芯直径的1/2或1.6 mm两者的较小值。其他药皮类型焊条长度方向上露芯长度应不大于焊芯直径的2/3或2.4 mm两者的较小值。

4.2.3 焊条偏心度应符合如下规定：

a）直径不大于2.5 mm的焊条，偏心度应不大于7%；

b) 直径为 3.2 mm 和 4.0 mm 的焊条, 偏心度应不大于 5%;

c) 直径不小于 5.0 mm 的焊条，偏心度应不大于 4%。

偏心度计算方法见公式(1)及图1。

$$
P = \frac {T _ {1} - T _ {2}}{(T _ {1} + T _ {2}) / 2} \times 100 \%\tag{……(1}
$$

式中：

P ——焊条偏心度；

$T_{1}$ ——焊条断面药皮最大厚度+焊芯直径；

$T_{2}$ ——焊条同一断面药皮最小厚度＋焊芯直径。

![](images/64aab28605e154e84dce9ed34d98e7bf26c8ac1aa898f291bef64fb55795ff47.jpg)  
图 1 焊条偏心度测量示意图

## 4.3 T型接头角焊缝

4.3.1 角焊缝的试件检查按 GB/T 25774.3 规定。

4.3.2 角焊缝的试验要求应符合表 4 规定。两焊脚长度差及凸度要求应符合表 5 规定。

表 4 角焊缝试验要求  
单位为毫米

<table><tr><td>药皮类型</td><td>电流类型</td><td>焊条尺寸a</td><td>焊接位置b</td><td>试板厚度t</td><td>试板宽度w</td><td>试板长度l</td><td>焊脚尺寸</td></tr><tr><td rowspan="2">03</td><td rowspan="2">交流和直流反接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤10.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">10</td><td rowspan="2">直流反接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥6.0</td></tr><tr><td rowspan="2">11</td><td rowspan="2">交流和直流反接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥6.0</td></tr><tr><td rowspan="2">12</td><td rowspan="2">交流和直流正接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤10.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">13</td><td rowspan="2">交流和直流正、反接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤10.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">14</td><td rowspan="2">交流和直流正、反接</td><td>4.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">15</td><td rowspan="2">直流反接</td><td>4.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">16</td><td rowspan="2">交流和直流反接</td><td>4.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">18</td><td rowspan="2">交流和直流反接</td><td>4.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td rowspan="2">19</td><td rowspan="2">交流和直流反接</td><td>5.0</td><td>PF、PD</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤10.0</td></tr><tr><td>6.0</td><td>PB</td><td>≥400</td><td>≥8.0</td></tr><tr><td>20</td><td>交流和直流正接</td><td>6.0</td><td>PB</td><td>10或12</td><td>≥75</td><td>≥400</td><td>≥8.0</td></tr><tr><td>24</td><td>交流和直流正、反接</td><td>6.0</td><td>PB</td><td>10或12</td><td>≥75</td><td>≥400或≥650°</td><td>≥8.0</td></tr><tr><td>27</td><td>交流和直流正接</td><td>6.0</td><td>PB</td><td>10或12</td><td>≥75</td><td>≥400或≥650°</td><td>≥8.0</td></tr><tr><td>28</td><td>交流和直流反接</td><td>6.0</td><td>PB</td><td>10或12</td><td>≥75</td><td>≥400或≥650°</td><td>≥8.0</td></tr><tr><td>40</td><td colspan="3">供需双方协商</td><td>10或12</td><td>≥75</td><td colspan="2">供需双方协商</td></tr><tr><td rowspan="2">45</td><td rowspan="2">直流反接</td><td>4.0</td><td>PE、PG</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td rowspan="2">≥300</td><td>≤8.0</td></tr><tr><td>4.5</td><td>PE、PG</td><td>≥6.0</td></tr><tr><td rowspan="2">48</td><td rowspan="2">交流和直流反接</td><td>4.0</td><td>PD、PG</td><td rowspan="2">10或12</td><td rowspan="2">≥75</td><td>≥300</td><td>≤8.0</td></tr><tr><td>5.0</td><td>PB、PG</td><td>≥300或≥400d</td><td>≥6.5</td></tr><tr><td colspan="8">a当焊条尺寸小于规定尺寸时,应采用最大尺寸的焊条,并按比例调整要求。除非该焊条尺寸不要求试验;b焊接位置见GB/T 16672,其中PB=平角焊、PD=仰角焊、PE=仰焊、PF=向上立焊、PG=向下立焊;c对于450mm长的焊条,试板长度l不小于400mm;对于700mm长的焊条,试板长度l不小于650mm;d对于350mm长的焊条,试板长度l不小于300mm;对于450mm或460mm长的焊条,试板长度l不小于400mm。</td></tr></table>

表 5 两焊脚长度差及凸度要求

<table><tr><td>实测焊脚尺寸</td><td>两焊脚长度差</td><td>凸度</td></tr><tr><td>≤4.0</td><td>≤1.0</td><td>≤2.0</td></tr><tr><td>4.5</td><td>≤1.5</td><td>≤2.0</td></tr><tr><td>5.0、5.5</td><td>≤2.0</td><td>≤2.0</td></tr><tr><td>6.0、6.5</td><td>≤2.5</td><td>≤2.0</td></tr><tr><td>7.0、7.5、8.0</td><td>≤3.0</td><td>≤2.5</td></tr><tr><td>8.5</td><td>≤3.5</td><td>≤2.5</td></tr><tr><td>≥9.0</td><td>≤4.0</td><td>≤2.5</td></tr></table>

## 4.4 熔敷金属化学成分

焊条的熔敷金属化学成分应符合表 6 规定。

## 4.5 力学性能

4.5.1 熔敷金属拉伸试验结果应符合表 7 规定。

4.5.2 焊缝金属夏比 V 型缺口冲击试验温度按表 7 要求, 测定五个冲击试样的冲击吸收能量。在计算五个冲击吸收能量的平均值时, 应去掉一个最大值和一个最小值。余下的三个值中有两个应不小于 27 J, 另一个允许小于 27 J, 但应不小于 20 J, 三个值的平均值应不小于 27 J。

4.5.3 如果焊条型号中附加了可选择的代号“U”，焊缝金属夏比 V 型缺口冲击要求则按表 7 规定的温度，测定三个冲击试样的冲击吸收能量。三个值中仅有一个值允许小于 47 J，但应不小于 32 J，三个值的平均值应不小于 47 J。

## 4.6 焊缝射线探伤

药皮类型 12 焊条不要求焊缝射线探伤试验, 药皮类型 15、16、18、19、20、45 和 48 焊条的焊缝射线探伤应符合 GB/T 3323 中的 I 级规定, 其他药皮类型焊条的焊缝射线探伤应符合 GB/T 3323 中的 II 级规定。

## 4.7 熔敷金属扩散氢含量

熔敷金属扩散氢含量要求可由供需双方协商确定，扩散氢代号如表8所示。

表 6 熔敷金属化学成分

<table><tr><td rowspan="2">焊条型号</td><td colspan="10">化学成分(质量分数)%</td></tr><tr><td>C</td><td>Mn</td><td>Si</td><td>P</td><td>S</td><td>Ni</td><td>Cr</td><td>Mo</td><td>V</td><td>其他</td></tr><tr><td>E4303</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4310</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4311</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4312</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4313</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4315</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4316</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4318</td><td>0.03</td><td>0.60</td><td>0.40</td><td>0.025</td><td>0.015</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4319</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4320</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4324</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4327</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4328</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E4340</td><td>—</td><td>—</td><td>—</td><td>0.040</td><td>0.035</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E5003</td><td>0.15</td><td>1.25</td><td>0.90</td><td>0.040</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5010</td><td>0.20</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5011</td><td>0.20</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5012</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5013</td><td>0.20</td><td>1.20</td><td>1.00</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5014</td><td>0.15</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5015</td><td>0.15</td><td>1.60</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5016</td><td>0.15</td><td>1.60</td><td>0.75</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5016-1</td><td>0.15</td><td>1.60</td><td>0.75</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5018</td><td>0.15</td><td>1.60</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5018-1</td><td>0.15</td><td>1.60</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5019</td><td>0.15</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5024</td><td>0.15</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5024-1</td><td>0.15</td><td>1.25</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5027</td><td>0.15</td><td>1.60</td><td>0.75</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5028</td><td>0.15</td><td>1.60</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5048</td><td>0.15</td><td>1.60</td><td>0.90</td><td>0.035</td><td>0.035</td><td>0.30</td><td>0.20</td><td>0.30</td><td>0.08</td><td>—</td></tr><tr><td>E5716</td><td>0.12</td><td>1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.30</td><td>0.35</td><td>—</td><td>—</td></tr><tr><td>E5728</td><td>0.12</td><td>1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.30</td><td>0.35</td><td>—</td><td>—</td></tr><tr><td>E5010-P1</td><td>0.20</td><td>1.20</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.30</td><td>0.50</td><td>0.10</td><td>—</td></tr><tr><td>E5510-P1</td><td>0.20</td><td>1.20</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.30</td><td>0.50</td><td>0.10</td><td>—</td></tr><tr><td>E5518-P2</td><td>0.12</td><td>0.90~1.70</td><td>0.80</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.20</td><td>0.50</td><td>0.05</td><td>—</td></tr><tr><td>E5545-P2</td><td>0.12</td><td>0.90~1.70</td><td>0.80</td><td>0.03</td><td>0.03</td><td>1.00</td><td>0.20</td><td>0.50</td><td>0.05</td><td>—</td></tr><tr><td>E5003-1M3</td><td>0.12</td><td>0.60</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5010-1M3</td><td>0.12</td><td>0.60</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5011-1M3</td><td>0.12</td><td>0.60</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5015-1M3</td><td>0.12</td><td>0.90</td><td>0.60</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5016-1M3</td><td>0.12</td><td>0.90</td><td>0.60</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5018-1M3</td><td>0.12</td><td>0.90</td><td>0.80</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5019-1M3</td><td>0.12</td><td>0.90</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5020-1M3</td><td>0.12</td><td>0.60</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5027-1M3</td><td>0.12</td><td>1.00</td><td>0.40</td><td>0.03</td><td>0.03</td><td>—</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5518-3M2</td><td>0.12</td><td>1.00~1.75</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.90</td><td>—</td><td>0.25~0.45</td><td>—</td><td>—</td></tr><tr><td>E5515-3M3</td><td>0.12</td><td>1.00~1.80</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.90</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5516-3M3</td><td>0.12</td><td>1.00~1.80</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.90</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5518-3M3</td><td>0.12</td><td>1.00~1.80</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.90</td><td>—</td><td>0.40~0.65</td><td>—</td><td>—</td></tr><tr><td>E5015-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>—</td><td>0.35</td><td>0.05</td><td>—</td></tr><tr><td>E5016-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>—</td><td>0.35</td><td>0.05</td><td>—</td></tr><tr><td>E5028-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>—</td><td>0.35</td><td>0.05</td><td>—</td></tr><tr><td>E5515-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>—</td><td>0.35</td><td>0.05</td><td>—</td></tr><tr><td>E5516-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>—</td><td>0.35</td><td>0.05</td><td>—</td></tr><tr><td>E5528-N1</td><td>0.12</td><td>0.60~1.60</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.30~1.00</td><td>-</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5015-N2</td><td>0.08</td><td>0.40~1.40</td><td>0.50</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5016-N2</td><td>0.08</td><td>0.40~1.40</td><td>0.50</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5018-N2</td><td>0.08</td><td>0.40~1.40</td><td>0.50</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5515-N2</td><td>0.12</td><td>0.40~1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5516-N2</td><td>0.12</td><td>0.40~1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5518-N2</td><td>0.12</td><td>0.40~1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>-</td></tr><tr><td>E5015-N3</td><td>0.10</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>E5016-N3</td><td>0.10</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>E5515-N3</td><td>0.10</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>E5516-N3</td><td>0.10</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>E5516-3N3</td><td>0.10</td><td>1.60</td><td>0.60</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5518-N3</td><td>0.10</td><td>1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>1.10~2.00</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5015-N5</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5016-N5</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5018-N5</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5028-N5</td><td>0.10</td><td>1.00</td><td>0.80</td><td>0.025</td><td>0.020</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5515-N5</td><td>0.12</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5516-N5</td><td>0.12</td><td>1.25</td><td>0.60</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5518-N5</td><td>0.12</td><td>1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5015-N7</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5016-N7</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5018-N7</td><td>0.05</td><td>1.25</td><td>0.50</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5515-N7</td><td>0.12</td><td>1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5516-N7</td><td>0.12</td><td>1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5518-N7</td><td>0.12</td><td>1.25</td><td>0.80</td><td>0.03</td><td>0.03</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5515-N13</td><td>0.06</td><td>1.00</td><td>0.60</td><td>0.025</td><td>0.020</td><td>6.00~7.00</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5516-N13</td><td>0.06</td><td>1.00</td><td>0.60</td><td>0.025</td><td>0.020</td><td>6.00~7.00</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5518-N2M3</td><td>0.10</td><td>0.80~1.25</td><td>0.60</td><td>0.02</td><td>0.02</td><td>0.80~1.10</td><td>0.10</td><td>0.40~0.65</td><td>0.02</td><td>Cu:0.10Al:0.05</td></tr><tr><td>E5003-NC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.25~0.70</td><td>0.30</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5016-NC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.25~0.70</td><td>0.30</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5028-NC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.25~0.70</td><td>0.30</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5716-NC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.25~0.70</td><td>0.30</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5728-NC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.25~0.70</td><td>0.30</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5003-CC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>-</td><td>0.30~0.70</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5016-CC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>-</td><td>0.30~0.70</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5028-CC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>-</td><td>0.30~0.70</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5716-CC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>-</td><td>0.30~0.70</td><td>-</td><td>-</td><td>Cu:0.20~0.60</td></tr><tr><td>E5728-CC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>—</td><td>0.30~0.70</td><td>—</td><td>—</td><td>Cu:0.20~0.60</td></tr><tr><td>E5003-NCC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.05~0.45</td><td>0.45~0.75</td><td>—</td><td>—</td><td>Cu:0.30~0.70</td></tr><tr><td>E5016-NCC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.05~0.45</td><td>0.45~0.75</td><td>—</td><td>—</td><td>Cu:0.30~0.70</td></tr><tr><td>E5028-NCC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.05~0.45</td><td>0.45~0.75</td><td>—</td><td>—</td><td>Cu:0.30~0.70</td></tr><tr><td>E5716-NCC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.05~0.45</td><td>0.45~0.75</td><td>—</td><td>—</td><td>Cu:0.30~0.70</td></tr><tr><td>E5728-NCC</td><td>0.12</td><td>0.30~1.40</td><td>0.90</td><td>0.03</td><td>0.03</td><td>0.05~0.45</td><td>0.45~0.75</td><td>—</td><td>—</td><td>Cu:0.30~0.70</td></tr><tr><td>E5003-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.35~0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5016-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.35~0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5028-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5516-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.35~0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5518-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.35~0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5716-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.35~0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5728-NCC1</td><td>0.12</td><td>0.50~1.30</td><td>0.80</td><td>0.03</td><td>0.03</td><td>0.40~0.80</td><td>0.45~0.70</td><td>—</td><td>—</td><td>Cu:0.30~0.75</td></tr><tr><td>E5016-NCC2</td><td>0.12</td><td>0.40~0.70</td><td>0.40~0.70</td><td>0.025</td><td>0.025</td><td>0.20~0.40</td><td>0.15~0.30</td><td>—</td><td>0.08</td><td>Cu:0.30~0.60</td></tr><tr><td>E5018-NCC2</td><td>0.12</td><td>0.40~0.70</td><td>0.40~0.70</td><td>0.025</td><td>0.025</td><td>0.20~0.40</td><td>0.15~0.30</td><td>—</td><td>0.08</td><td>Cu:0.30~0.60</td></tr><tr><td>E50XX-Ga</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E55XX-Ga</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E57XX-Ga</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td colspan="11">注:表中单值均为最大值。</td></tr><tr><td colspan="11">*焊条型号中“XX”代表焊条的药皮类型,见表2。</td></tr></table>

表 7 力学性能

<table><tr><td>焊条型号</td><td>抗拉强度 $R_m$ MPa</td><td>屈服强度 $^a R_{eL}$ MPa</td><td>断后伸长率A%</td><td>冲击试验温度°C</td></tr><tr><td>E4303</td><td>≥430</td><td>≥330</td><td>≥20</td><td>0</td></tr><tr><td>E4310</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4311</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4312</td><td>≥430</td><td>≥330</td><td>≥16</td><td>—</td></tr><tr><td>E4313</td><td>≥430</td><td>≥330</td><td>≥16</td><td>—</td></tr><tr><td>E4315</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4316</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4318</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4319</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-20</td></tr><tr><td>E4320</td><td>≥430</td><td>≥330</td><td>≥20</td><td>—</td></tr><tr><td>E4324</td><td>≥430</td><td>≥330</td><td>≥16</td><td>—</td></tr><tr><td>E4327</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-30</td></tr><tr><td>E4328</td><td>≥430</td><td>≥330</td><td>≥20</td><td>-20</td></tr><tr><td>E4340</td><td>≥430</td><td>≥330</td><td>≥20</td><td>0</td></tr><tr><td>E5003</td><td>≥490</td><td>≥400</td><td>≥20</td><td>0</td></tr><tr><td>E5010</td><td>490~650</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5011</td><td>490~650</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5012</td><td>≥490</td><td>≥400</td><td>≥16</td><td>—</td></tr><tr><td>E5013</td><td>≥490</td><td>≥400</td><td>≥16</td><td>—</td></tr><tr><td>E5014</td><td>≥490</td><td>≥400</td><td>≥16</td><td>—</td></tr><tr><td>E5015</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5016</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5016-1</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-45</td></tr><tr><td>E5018</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5018-1</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-45</td></tr><tr><td>E5019</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-20</td></tr><tr><td>E5024</td><td>≥490</td><td>≥400</td><td>≥16</td><td>—</td></tr><tr><td>E5024-1</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-20</td></tr><tr><td>E5027</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5028</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-20</td></tr><tr><td>E5048</td><td>≥490</td><td>≥400</td><td>≥20</td><td>-30</td></tr><tr><td>E5716</td><td>≥570</td><td>≥490</td><td>≥16</td><td>-30</td></tr><tr><td>E5728</td><td>≥570</td><td>≥490</td><td>≥16</td><td>-20</td></tr><tr><td>E5010-P1</td><td>≥490</td><td>≥420</td><td>≥20</td><td>-30</td></tr><tr><td>E5510-P1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-30</td></tr><tr><td>E5518-P2</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-30</td></tr><tr><td>E5545-P2</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-30</td></tr><tr><td>E5003-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5010-1M3</td><td>≥490</td><td>≥420</td><td>≥20</td><td>—</td></tr><tr><td>E5011-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5015-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5016-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5018-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5019-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5020-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5027-1M3</td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E5518-3M2</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5515-3M3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5516-3M3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5518-3M3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5015-N1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5016-N1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5028-N1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5515-N1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-40</td></tr><tr><td>E5516-N1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-40</td></tr><tr><td>E5528-N1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-40</td></tr><tr><td>E5015-N2</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5016-N2</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5018-N2</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-50</td></tr><tr><td>E5515-N2</td><td>≥550</td><td>470~550</td><td>≥20</td><td>-40</td></tr><tr><td>E5516-N2</td><td>≥550</td><td>470~550</td><td>≥20</td><td>-40</td></tr><tr><td>E5518-N2</td><td>≥550</td><td>470~550</td><td>≥20</td><td>-40</td></tr><tr><td>E5015-N3</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5016-N3</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-40</td></tr><tr><td>E5515-N3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5516-N3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5516-3N3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>焊条型号</td><td>抗拉强度 $R_m$ MPa</td><td>屈服强度 $^*R_{eL}$ MPa</td><td>断后伸长率A%</td><td>冲击试验温度°C</td></tr><tr><td>E5518-N3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-50</td></tr><tr><td>E5015-N5</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-75</td></tr><tr><td>E5016-N5</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-75</td></tr><tr><td>E5018-N5</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-75</td></tr><tr><td>E5028-N5</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-60</td></tr><tr><td>E5515-N5</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-60</td></tr><tr><td>E5516-N5</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-60</td></tr><tr><td>E5518-N5</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-60</td></tr><tr><td>E5015-N7</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-100</td></tr><tr><td>E5016-N7</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-100</td></tr><tr><td>E5018-N7</td><td>≥490</td><td>≥390</td><td>≥20</td><td>-100</td></tr><tr><td>E5515-N7</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-75</td></tr><tr><td>E5516-N7</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-75</td></tr><tr><td>E5518-N7</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-75</td></tr><tr><td>E5515-N13</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-100</td></tr><tr><td>E5516-N13</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-100</td></tr><tr><td>E5518-N2M3</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-40</td></tr><tr><td>E5003-NC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5016-NC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5028-NC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5716-NC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5728-NC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5003-CC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5016-CC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5028-CC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5716-CC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5728-CC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5003-NCC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5016-NCC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5028-NCC</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5716-NCC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5728-NCC</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5003-NCC1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5016-NCC1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>焊条型号</td><td>抗拉强度  $R_{m}$ MPa</td><td>屈服强度 $^{a}R_{eL}$ MPa</td><td>断后伸长率 A%</td><td>冲击试验温度°C</td></tr><tr><td>E5028-NCC1</td><td>≥490</td><td>≥390</td><td>≥20</td><td>0</td></tr><tr><td>E5516-NCC1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-20</td></tr><tr><td>E5518-NCC1</td><td>≥550</td><td>≥460</td><td>≥17</td><td>-20</td></tr><tr><td>E5716-NCC1</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5728-NCC1</td><td>≥570</td><td>≥490</td><td>≥16</td><td>0</td></tr><tr><td>E5016-NCC2</td><td>≥490</td><td>≥420</td><td>≥20</td><td>-20</td></tr><tr><td>E5018-NCC2</td><td>≥490</td><td>≥420</td><td>≥20</td><td>-20</td></tr><tr><td>E50XX-G $^b$ </td><td>≥490</td><td>≥400</td><td>≥20</td><td>—</td></tr><tr><td>E55XX-G $^b$ </td><td>≥550</td><td>≥460</td><td>≥17</td><td>—</td></tr><tr><td>E57X-G $^b$ </td><td>≥570</td><td>≥490</td><td>≥16</td><td>—</td></tr><tr><td colspan="5"> $^a$ 当屈服发生不明显时,应测定规定塑性延伸强度  $R_{p0.2}$ ; $^b$ 焊条型号中“XX”代表焊条的药皮类型,见表 2。</td></tr></table>

表 8 熔敷金属扩散氢含量

<table><tr><td>扩散氢代号</td><td>扩散氢含量mL/100 g</td></tr><tr><td>H15</td><td>≤15</td></tr><tr><td>H10</td><td>≤10</td></tr><tr><td>H5</td><td>≤5</td></tr></table>

## 5 试验方法

## 5.1 力学性能试验

## 5.1.1 试验用母材

力学性能试验用母材采用表 9 规定的试板。若采用其他母材，应采用试验焊条在坡口面和垫板面至少焊接三层隔离层，隔离层的厚度加工后不小于 3 mm。

表 9 试验用母材

<table><tr><td>熔敷金属化学成分代号</td><td>试验用母材</td></tr><tr><td>无标记、-1、-P1、-P2</td><td>符合GB/T 700或GB/T 1591中强度级别相当的Q235 A级/B级、Q345 A级/B级碳钢或低合金钢钢板。</td></tr><tr><td>-G</td><td>由供需双方协商。</td></tr><tr><td>其他</td><td>与熔敷金属成分相当的钢板。</td></tr></table>

## 5.1.2 试件制备

5.1.2.1 力学性能试验采用 $\Phi4.0\ mm$ 的焊条，电流采用制造商推荐的最大电流值的 70%\~90% 进行焊接，对于交直流两用的焊条，试验时应采用交流。

5.1.2.2 力学性能试件按 GB/T 25774.1 进行制备,采用试件类型 1.3。

5.1.2.3 长度大于 450 mm 的焊条,试板长度不小于 500 mm。

5.1.2.4 对于碱性药皮类型焊条，试验前应进行 $260^{\circ}C \sim 430^{\circ}C$ 烘焙 1 h 以上或按制造商推荐的烘焙规范烘干。其他药皮类型焊条可在供货状态下试验或按制造商推荐的烘焙规范烘干。

5.1.2.5 试板定位焊后，启焊时试板温度应加热到表10规定的预热温度，并在焊接过程中保持道间温度，试板温度超过时，应在静态大气中冷却。用表面温度计、测温笔或热电偶测量道间温度。

表 10 预热温度和道间温度

<table><tr><td>熔敷金属化学成分代号</td><td>预热温度和道间温度°C</td></tr><tr><td>无标记、-1</td><td>100~150</td></tr><tr><td>其他</td><td>90~110</td></tr></table>

5.1.2.6 试件制备由7\~9层完成，每层由两道焊道完成，最后两层允许分别由三道焊道完成，同一焊道的焊接方向不允许改变。 $\Phi4.0\ mm$ 以外的其他尺寸焊条，焊层及焊道数按制造商推荐进行。

5.1.2.7 每一焊道除两端的起弧点和熄弧点外，在射线探伤区域内至少有一个起弧点和熄弧点。

## 5.1.3 焊后热处理

5.1.3.1 试件要求焊后热处理时，应在加工拉伸试样和冲击试样之前进行，热处理条件按表11规定。

5.1.3.2 试件放入炉内时，炉温不得高于 $300^{\circ}\mathrm{C}$ ，以 $85^{\circ}\mathrm{C/h} \sim 275^{\circ}\mathrm{C/h}$ 的速率加热到规定温度。达到保温时间后，以不大于 $200^{\circ}\mathrm{C/h}$ 的速率随炉冷却至 $300^{\circ}\mathrm{C}$ 以下。试件冷却至 $300^{\circ}\mathrm{C}$ 以下的任意温度时，允许从炉中取出，在静态大气中冷却至室温。

## 5.1.4 熔敷金属拉伸试验

5.1.4.1 熔敷金属拉伸试样尺寸及取样位置按 GB/T 25774.1 规定。

5.1.4.2 碱性药皮类型焊条的熔敷金属拉伸试样不允许去氢处理,其他药皮类型焊条的熔敷金属拉伸试样允许进行 $100\;^{\circ}C \pm 5\;^{\circ}C$ 保温 $46\;h \sim 48\;h$ 或者 $250\;^{\circ}C$ 保温 $6\;h \sim 8\;h$ 的去氢处理。

5.1.4.3 熔敷金属拉伸试验应按 GB/T 2652 进行。

表 11 热处理条件

<table><tr><td>熔敷金属化学成分代号</td><td>热处理温度°C</td><td>保温时间min</td></tr><tr><td>-N5、-N7</td><td>605±15</td><td> $60^{+15}_{0}$ </td></tr><tr><td>-N13</td><td>600±15</td><td> $60^{+15}_{0}$ </td></tr><tr><td>其他</td><td>620±15</td><td> $60^{+15}_{0}$ </td></tr></table>

## 5.1.5 焊缝金属 V 型缺口冲击试验

5.1.5.1 焊缝金属冲击试样尺寸及取样位置按 GB/T 25774.1 规定。每组冲击试样中至少应有一个试样测量 V 型缺口的形状尺寸，测量应在至少放大 50 倍的投影仪或金相显微镜上进行。

5.1.5.2 焊缝金属 V 型缺口冲击试验应按 GB/T 2650 进行。

## 5.2 射线探伤试验

5.2.1 焊缝射线探伤试验应在截取拉伸试样和冲击试样之前的试件上进行，射线探伤前应去掉垫板。

5.2.2 焊缝射线探伤试验按 GB/T 3323 进行。

5.2.3 在评定焊缝射线探伤底片时，试件两端 25 mm 应不予考虑。

## 5.3 熔敷金属化学分析试验

5.3.1 熔敷金属化学分析试样允许在力学性能试件上或拉断后的拉棒上制取，仲裁试验时，按GB/T 25777规定进行。

5.3.2 试样的化学分析可采用任何适宜的化学分析方法,仲裁试验时,按供需双方确认的化学分析方法进行。

## 5.4 T型接头角焊缝试验

5.4.1 T型接头角焊缝试验的试件制备按GB/T25774.3进行。

5.4.2 试板采用含碳量不大于 $0.30\%$ 的非合金钢。每种药皮类型焊条要求的电流类型、焊条尺寸、焊接位置及试板尺寸按表4规定进行。

## 5.5 熔敷金属扩散氢试验

熔敷金属扩散氢含量的测定按 GB/T 3965 进行,有关扩散氢相关说明参见附录 C。

## 6 检验规则

成品焊条由制造厂质量检验部门按批检验。

## 6.1 批量划分

每批焊条的批量划分按 GB/T 25778 规定进行。

## 6.2 取样方法

每批焊条检验时,按照需要数量至少在三个部位取有代表性的样品。

## 6.3 验收

每批焊条按 GB/T 25778 进行验收。

## 6.4 复验

任何一项检验不合格时,该项检验应加倍复验。对于化学分析,仅复验那些不满足要求的元素。当复验拉伸试验时,抗拉强度、屈服强度及断后伸长率同时作为复验项目。其试样可在原试件上截取,也可在新焊制的试件上截取。加倍复验结果均应符合该项检验的规定。

## 7 包装、标志和质量证明

## 7.1 包装

7.1.1 焊条按批号每 1 kg、2 kg、2.5 kg、5 kg 净质量或按相应根数进行包装。包装应封口，保证焊条在正常的贮存条件下不致变质损坏。

7.1.2 若干包焊条应装箱，以保证在正常运输、搬运和贮存过程中不致破损。

## 7.2 标志和质量证明

焊条的标志和质量证明按 GB/T 25775 规定。

# 附录A

# (资料性附录)

# 焊条药皮类型

## A.1 概述

药皮焊条的性能(如焊接特性和焊缝金属的力学性能)主要受药皮影响。药皮中的组成物可以概括为如下6类：

a) 造渣剂；

b) 脱氧剂；

c) 造气剂；

d) 稳弧剂；

e) 粘接剂；

f) 合金化元素(如需要)。

此外，加入铁粉可以提高焊条熔敷效率，但对焊接位置有影响。

交直流两用的焊条，可根据制造商按照特定市场需求设定的极性进行选择。

## A.2 药皮类型03

此药皮类型包含二氧化钛和碳酸钙的混合物,所以同时具有金红石焊条和碱性焊条的某些性能。见 A.6 和 A.9。

## A.3 药皮类型10

此药皮类型内含有大量的可燃有机物，尤其是纤维素，由于其强电弧特性特别适用于向下立焊。由于钠影响电弧的稳定性，因而焊条主要适用于直流焊接，通常使用直流反接。

## A.4 药皮类型11

此药皮类型内含有大量的可燃有机物，尤其是纤维素，由于其强电弧特性特别适用于向下立焊。由于钾增强电弧的稳定性，因而适用于交直流两用焊接，直流焊接时使用直流反接。

## A.5 药皮类型 12

此药皮类型内含有大量的二氧化钛(金红石)。其柔软电弧特性适合用于在简单装配条件下对大的根部间隙进行焊接。

## A.6 药皮类型 13

此药皮类型内含有大量的二氧化钛(金红石)和增强电弧稳定性的钾。与药皮类型12相比能在低电流条件下产生稳定电弧，特别适于金属薄板的焊接。

## A.7 药皮类型 14

此药皮类型与药皮类型 12 和 13 类似,但是添加了少量铁粉。加入铁粉可以提高电流承载能力和熔敷效率,适于全位置焊接。

## A.8 药皮类型 15

此药皮类型碱度较高,含有大量的氧化钙和萤石。由于钠影响电弧的稳定性,只适用于直流反接。此药皮类型的焊条可以得到低氢含量、高冶金性能的焊缝。

## A.9 药皮类型 16

此药皮类型碱度较高，含有大量的氧化钙和萤石。由于钾增强电弧的稳定性，适用于交流焊接。此药皮类型的焊条可以得到低氢含量、高冶金性能的焊缝。

## A. 10 药皮类型 18

此药皮类型除了药皮略厚和含有大量铁粉外,其他与药皮类型16类似。与药皮类型16相比,药皮类型18中的铁粉可以提高电流承载能力和熔敷效率。

## A.11 药皮类型 19

此药皮类型包含钛和铁的氧化物,通常在钛铁矿获取。虽然它们不属于碱性药皮类型焊条,但是可以制造出高韧性的焊缝金属。

## A.12 药皮类型20

此药皮类型包含大量的铁氧化物。熔渣流动性好，所以通常只在平焊和横焊中使用。主要用于角焊缝和搭接焊缝。

## A.13 药皮类型24

此药皮类型除了药皮略厚和含有大量铁粉外,其他与药皮类型14类似。通常只在平焊和横焊中使用。主要用于角焊缝和搭接焊缝。

## A.14 药皮类型27

此药皮类型除了药皮略厚和含有大量铁粉外,其他与药皮类型20类似,增加了药皮类型20中的铁氧化物。主要用于高速角焊缝和搭接焊缝的焊接。

## A. 15 药皮类型 28

此药皮类型除了药皮略厚和含有大量铁粉外,其他与药皮类型18类似。通常只在平焊和横焊中使用。能得到低氢含量、高冶金性能的焊缝。

## A. 16 药皮类型 40

此药皮类型不属于上述任何焊条类型。其制造是为了达到购买商的特定使用要求。焊接位置由供应商和购买商之间协议确定。如要求在圆孔内部焊接(“塞焊”)或者在槽内进行的特殊焊接。由于药皮类型40并无具体指定，此药皮类型可按照具体要求有所不同。

## A.17 药皮类型45

除了主要用于向下立焊外，此药皮类型与药皮类型15类似。

## A. 18 药皮类型 48

除了主要用于向下立焊外，此药皮类型与药皮类型18类似。

附录B

(资料性附录)

焊条型号对照

为便于应用,提供了本标准焊条型号与其他相关标准的焊条型号之间的对应关系,见表 B.1。

表 B.1 焊条型号对照表

<table><tr><td>本标准</td><td>AWS A 5.1M:2004</td><td>AWS A5.5M:2006</td><td>ISO 2560:2009</td><td>GB/T 5117—1995</td><td>GB/T 5118—1995</td></tr><tr><td colspan="6">碳钢</td></tr><tr><td>E4303</td><td>—</td><td>—</td><td>E4303</td><td>E4303</td><td>—</td></tr><tr><td>E4310</td><td>E4310</td><td>—</td><td>E4310</td><td>E4310</td><td>—</td></tr><tr><td>E4311</td><td>E4311</td><td>—</td><td>E4311</td><td>E4311</td><td>—</td></tr><tr><td>E4312</td><td>E4312</td><td>—</td><td>E4312</td><td>E4312</td><td>—</td></tr><tr><td>E4313</td><td>E4313</td><td>—</td><td>E4313</td><td>E4313</td><td>—</td></tr><tr><td>E4315</td><td>—</td><td>—</td><td>—</td><td>E4315</td><td>—</td></tr><tr><td>E4316</td><td>—</td><td>—</td><td>E4316</td><td>E4316</td><td>—</td></tr><tr><td>E4318</td><td>E4318</td><td>—</td><td>E4318</td><td>—</td><td>—</td></tr><tr><td>E4319</td><td>E4319</td><td>—</td><td>E4319</td><td>E4301</td><td>—</td></tr><tr><td>E4320</td><td>E4320</td><td>—</td><td>E4320</td><td>E4320</td><td>—</td></tr><tr><td>E4324</td><td>—</td><td>—</td><td>E4324</td><td>E4324</td><td>—</td></tr><tr><td>E4327</td><td>E4327</td><td>—</td><td>E4327</td><td>E4327</td><td>—</td></tr><tr><td>E4328</td><td>—</td><td>—</td><td>—</td><td>E4328</td><td>—</td></tr><tr><td>E4340</td><td>—</td><td>—</td><td>E4340</td><td>E4300</td><td>—</td></tr><tr><td>E5003</td><td>—</td><td>—</td><td>E4903</td><td>E5003</td><td>—</td></tr><tr><td>E5010</td><td>—</td><td>—</td><td>E4910</td><td>E5010</td><td>—</td></tr><tr><td>E5011</td><td>—</td><td>—</td><td>E4911</td><td>E5011</td><td>—</td></tr><tr><td>E5012</td><td>—</td><td>—</td><td>E4912</td><td>—</td><td>—</td></tr><tr><td>E5013</td><td>—</td><td>—</td><td>E4913</td><td>—</td><td>—</td></tr><tr><td>E5014</td><td>E4914</td><td>—</td><td>E4914</td><td>E5014</td><td>—</td></tr><tr><td>E5015</td><td>E4915</td><td>—</td><td>E4915</td><td>E5015</td><td>—</td></tr><tr><td>E5016</td><td>E4916</td><td>—</td><td>E4916</td><td>E5016</td><td>—</td></tr><tr><td>E5016-1</td><td>—</td><td>—</td><td>E4916-1</td><td>—</td><td>—</td></tr><tr><td>E5018</td><td>E4918</td><td>—</td><td>E4918</td><td>E5018</td><td>—</td></tr><tr><td>E5018-1</td><td>—</td><td>—</td><td>E4918-1</td><td>—</td><td>—</td></tr><tr><td>E5019</td><td>—</td><td>—</td><td>E4919</td><td>E5001</td><td>—</td></tr><tr><td>E5024</td><td>E4924</td><td>—</td><td>E4924</td><td>E5024</td><td>—</td></tr><tr><td>E5024-1</td><td>—</td><td>—</td><td>E4924-1</td><td>—</td><td>—</td></tr><tr><td>E5027</td><td>E4927</td><td>-</td><td>E4927</td><td>E5027</td><td>-</td></tr><tr><td>E5028</td><td>E4928</td><td>-</td><td>E4928</td><td>E5028</td><td>-</td></tr><tr><td>E5048</td><td>E4948</td><td>-</td><td>E4948</td><td>E5048</td><td>-</td></tr><tr><td>E5716</td><td>-</td><td>-</td><td>E5716</td><td>-</td><td>-</td></tr><tr><td>E5728</td><td>-</td><td>-</td><td>E5728</td><td>-</td><td>-</td></tr><tr><td colspan="6">管线钢</td></tr><tr><td>E5010-P1</td><td>-</td><td>E4910-P1</td><td>E4910-P1</td><td>-</td><td>-</td></tr><tr><td>E5510-P1</td><td>-</td><td>E5510-P1</td><td>E5510-P1</td><td>-</td><td>-</td></tr><tr><td>E5518-P2</td><td>-</td><td>E5518-P2</td><td>E5518-P2</td><td>-</td><td>-</td></tr><tr><td>E5545-P2</td><td>-</td><td>E5545-P2</td><td>E5545-P2</td><td>-</td><td>-</td></tr><tr><td colspan="6">碳钼钢</td></tr><tr><td>E5003-1M3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>E5003-A1</td></tr><tr><td>E5010-1M3</td><td>-</td><td>E4910-A1</td><td>E4910-1M3</td><td>-</td><td>E5010-A1</td></tr><tr><td>E5011-1M3</td><td>-</td><td>E4911-A1</td><td>E4911-1M3</td><td>-</td><td>E5011-A1</td></tr><tr><td>E5015-1M3</td><td>-</td><td>E4915-A1</td><td>E4915-1M3</td><td>-</td><td>E5015-A1</td></tr><tr><td>E5016-1M3</td><td>-</td><td>E4916-A1</td><td>E4916-1M3</td><td>-</td><td>E5016-A1</td></tr><tr><td>E5018-1M3</td><td>-</td><td>E4918-A1</td><td>E4918-1M3</td><td>-</td><td>E5018-A1</td></tr><tr><td>E5019-1M3</td><td>-</td><td>-</td><td>E4919-1M3</td><td>-</td><td>-</td></tr><tr><td>E5020-1M3</td><td>-</td><td>E4920-A1</td><td>E4920-1M3</td><td>-</td><td>E5020-A1</td></tr><tr><td>E5027-1M3</td><td>-</td><td>E4927-A1</td><td>E4927-1M3</td><td>-</td><td>E5027-A1</td></tr><tr><td colspan="6">锰钼钢</td></tr><tr><td>E5518-3M2</td><td>-</td><td>E5518-D1</td><td>E5518-3M2</td><td>-</td><td>-</td></tr><tr><td>E5515-3M3</td><td>-</td><td>-</td><td>-</td><td>-</td><td>E5515-D3</td></tr><tr><td>E5516-3M3</td><td>-</td><td>E5516-D3</td><td>E5516-3M3</td><td>-</td><td>E5516-D3</td></tr><tr><td>E5518-3M3</td><td>-</td><td>E5518-D3</td><td>E5518-3M3</td><td>-</td><td>E5518-D3</td></tr><tr><td colspan="6">镍钢</td></tr><tr><td>E5015-N1</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5016-N1</td><td>-</td><td>-</td><td>E4916-N1</td><td>-</td><td>-</td></tr><tr><td>E5028-N1</td><td>-</td><td>-</td><td>E4928-N1</td><td>-</td><td>-</td></tr><tr><td>E5515-N1</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>E5516-N1</td><td>-</td><td>-</td><td>E5516-N1</td><td>-</td><td>-</td></tr><tr><td>E5528-N1</td><td>-</td><td>-</td><td>E5528-N1</td><td>-</td><td>-</td></tr><tr><td>E5015-N2</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td colspan="6">镍钢</td></tr><tr><td>E5016-N2</td><td>—</td><td>—</td><td>E4916-N2</td><td>—</td><td>—</td></tr><tr><td>E5018-N2</td><td>—</td><td>E4918-C3L</td><td>E4918-N2</td><td>—</td><td>—</td></tr><tr><td>E5515-N2</td><td>—</td><td>—</td><td>—</td><td>—</td><td>E5515-C3</td></tr><tr><td>E5516-N2</td><td>—</td><td>E5516-C3</td><td>E5516-N2</td><td>—</td><td>E5516-C3</td></tr><tr><td>E5518-N2</td><td>—</td><td>E5518-C3</td><td>E5518-N2</td><td>—</td><td>E5518-C3</td></tr><tr><td>E5015-N3</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E5016-N3</td><td>—</td><td>—</td><td>E4916-N3</td><td>—</td><td>—</td></tr><tr><td>E5515-N3</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E5516-N3</td><td>—</td><td>E5516-C4</td><td>E5516-N3</td><td>—</td><td>—</td></tr><tr><td>E5516-3N3</td><td>—</td><td>—</td><td>E5516-3N3</td><td>—</td><td>—</td></tr><tr><td>E5518-N3</td><td>—</td><td>E5518-C4</td><td>E5518-N3</td><td>—</td><td>—</td></tr><tr><td>E5015-N5</td><td>—</td><td>E4915-C1L</td><td>E4915-N5</td><td>—</td><td>E5015-C1L</td></tr><tr><td>E5016-N5</td><td>—</td><td>E4916-C1L</td><td>E4916-N5</td><td>—</td><td>E5016-C1L</td></tr><tr><td>E5018-N5</td><td>—</td><td>E4918-C1L</td><td>E4918-N5</td><td>—</td><td>E5018-C1L</td></tr><tr><td>E5028-N5</td><td>—</td><td>—</td><td>E4928-N5</td><td>—</td><td>—</td></tr><tr><td>E5515-N5</td><td>—</td><td>—</td><td>—</td><td>—</td><td>E5515-C1</td></tr><tr><td>E5516-N5</td><td>—</td><td>E5516-C1</td><td>E5516-N5</td><td>—</td><td>E5516-C1</td></tr><tr><td>E5518-N5</td><td>—</td><td>E5518-C1</td><td>E5518-N5</td><td>—</td><td>E5518-C1</td></tr><tr><td>E5015-N7</td><td>—</td><td>E4915-C2L</td><td>E4915-N7</td><td>—</td><td>E5015-C2L</td></tr><tr><td>E5016-N7</td><td>—</td><td>E4916-C2L</td><td>E4916-N7</td><td>—</td><td>E5016-C2L</td></tr><tr><td>E5018-N7</td><td>—</td><td>E4918-C2L</td><td>E4918-N7</td><td>—</td><td>E5018-C2L</td></tr><tr><td>E5515-N7</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E5516-N7</td><td>—</td><td>E5516-C2</td><td>E5516-N7</td><td>—</td><td>E5516-C2</td></tr><tr><td>E5518-N7</td><td>—</td><td>E5518-C2</td><td>E5518-N7</td><td>—</td><td>E5518-C2</td></tr><tr><td>E5515-N13</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>E5516-N13</td><td>—</td><td>—</td><td>E5516-N13</td><td>—</td><td>—</td></tr><tr><td colspan="6">镍钼钢</td></tr><tr><td>E5518-N2M3</td><td>—</td><td>E5518-NM1</td><td>E5518-N2M3</td><td>—</td><td>E5518-NM</td></tr><tr><td colspan="6">耐候钢</td></tr><tr><td>E5003-NC</td><td>—</td><td>—</td><td>E4903-NC</td><td>—</td><td>—</td></tr><tr><td>E5016-NC</td><td>—</td><td>—</td><td>E4916-NC</td><td>—</td><td>—</td></tr><tr><td>E5028-NC</td><td>—</td><td>—</td><td>E4928-NC</td><td>—</td><td>—</td></tr><tr><td>E5716-NC</td><td>—</td><td>—</td><td>E5716-NC</td><td>—</td><td>—</td></tr><tr><td colspan="6">耐候钢</td></tr><tr><td>E5728-NC</td><td>—</td><td>—</td><td>E5728-NC</td><td>—</td><td>—</td></tr><tr><td>E5003-CC</td><td>—</td><td>—</td><td>E4903-CC</td><td>—</td><td>—</td></tr><tr><td>E5016-CC</td><td>—</td><td>—</td><td>E4916-CC</td><td>—</td><td>—</td></tr><tr><td>E5028-CC</td><td>—</td><td>—</td><td>E4928-CC</td><td>—</td><td>—</td></tr><tr><td>E5716-CC</td><td>—</td><td>—</td><td>E5716-CC</td><td>—</td><td>—</td></tr><tr><td>E5728-CC</td><td>—</td><td>—</td><td>E5728-CC</td><td>—</td><td>—</td></tr><tr><td>E5003-NCC</td><td>—</td><td>—</td><td>E4903-NCC</td><td>—</td><td>—</td></tr><tr><td>E5016-NCC</td><td>—</td><td>—</td><td>E4916-NCC</td><td>—</td><td>—</td></tr><tr><td>E5028-NCC</td><td>—</td><td>—</td><td>E4928-NCC</td><td>—</td><td>—</td></tr><tr><td>E5716-NCC</td><td>—</td><td>—</td><td>E5716-NCC</td><td>—</td><td>—</td></tr><tr><td>E5728-NCC</td><td>—</td><td>—</td><td>E5728-NCC</td><td>—</td><td>—</td></tr><tr><td>E5003-NCC1</td><td>—</td><td>—</td><td>E4903-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5016-NCC1</td><td>—</td><td>—</td><td>E4916-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5028-NCC1</td><td>—</td><td>—</td><td>E4928-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5516-NCC1</td><td>—</td><td>—</td><td>E5516-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5518-NCC1</td><td>—</td><td>E5518-W2</td><td>E5518-NCC1</td><td>—</td><td>E5518-W</td></tr><tr><td>E5716-NCC1</td><td>—</td><td>—</td><td>E5716-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5728-NCC1</td><td>—</td><td>—</td><td>E5728-NCC1</td><td>—</td><td>—</td></tr><tr><td>E5016-NCC2</td><td>—</td><td>—</td><td>E4916-NCC2</td><td>—</td><td>—</td></tr><tr><td>E5018-NCC2</td><td>—</td><td>E4918-W1</td><td>E4918-NCC2</td><td>—</td><td>E5018-W</td></tr><tr><td colspan="6">其他</td></tr><tr><td>E50XX-G</td><td>—</td><td>—</td><td>E49XX-G</td><td>—</td><td>E50XX-G</td></tr><tr><td>E55XX-G</td><td>—</td><td>—</td><td>E55XX-G</td><td>—</td><td>E55XX-G</td></tr><tr><td>E57XX-G</td><td>—</td><td>—</td><td>E57XX-G</td><td>—</td><td>—</td></tr></table>

# 附录 C

(资料性附录)

扩散氢相关说明

C.1 不同的扩散氢收集和测量的方法都可以用于批量试验,这些方法应按照 GB/T 3965 进行校准,使其具备同样的再现性。扩散氢含量受电流类型的影响。

C.2 焊接接头的裂纹很大程度上受扩散氢的影响,合金含量和强度级别的增加可能导致氢致裂纹,这种裂纹通常在接头冷却后产生,所以又叫做冷裂纹。对于 C-Mn 钢,裂纹最容易产生在热影响区,裂纹一般近似平行于熔合线。合金含量和强度级别的增加会增加氢致裂纹的风险,增加合金含量,裂纹将扩展至焊缝金属,裂纹通常垂直于焊接方向和母材的表面。

C.3 假设外部条件是满意的(焊接区域清洁和干燥),焊缝金属的扩散氢主要来源于材料中氢化物和环境大气条件。碱性焊条药皮中水分是焊缝金属中氢的主要来源,药皮中的水分在电弧中被电离并产生能被焊缝金属吸收的氢原子。在给定的材料和强度条件下,降低焊缝金属的氢含量可以减少冷裂纹的产生。

C.4 假设采取适当的预防措施使得进入焊缝金属的扩散氢保持在一个合理的最低限度,可以通过预热焊接接头到一个适当的温度,并在整个焊接过程中保持在这个温度以上,通常能避免裂纹的产生。实际上扩散氢含量很大程度上取决于应用过程,为了满足要求,应该遵循焊条制造商所推荐的相应操作、贮藏和烘干条件。

中华人民共和国

国家标准

非合金钢及细晶粒钢焊条

GB/T 5117—2012

\*

中国标准出版社出版发行
北京市朝阳区和平里西街甲2号(100013)
北京市西城区三里河北街16号(100045)

网址 www.spc.net.cn

总编室:(010)64275323 发行中心:(010)51780235
读者服务部:(010)68523946

中国标准出版社秦皇岛印刷厂印刷
各地新华书店经销

开本 880×1230 1/16 印张 2 字数 55 千字
2013 年 3 月第一版 2013 年 3 月第一次印刷

书号：155066·1-45983

如有印装差错 由本社发行中心调换

版权专有 侵权必究

举报电话:(010)68510107