# 中华人民共和国国家标准

GB/T 8110—2020

代替GB/T8110—2008

# 熔化极气体保护电弧焊用 非合金钢及细晶粒钢实心焊丝

# Wire electrodes and weld deposits for gas shielded metal arc welding of non alloy and fine grain steels

(ISO 14341:2010, Welding consumables—Wire electrodes and weld deposits for gas shielded metal arc welding of non alloy and fine grain steels—Classification, MOD)

2020-11-19 发布

2021-06-01 实施

## 目次

前言 …… I
1 范围 …… 1
2 规范性引用文件 …… 1
3 型号 …… 1
4 技术要求 …… 3
5 试验方法 …… 8
6 复验 …… 10
7 供货技术条件 …… 10
附录 A（资料性附录） 本标准与 ISO 14341:2010 相比的结构变化情况 …… 11
附录 B（资料性附录） 本标准与 ISO 14341:2010 的技术性差异及其原因 …… 12
附录 C（资料性附录） 焊丝型号对照 …… 13

## 前言

本标准按照 GB/T 1.1—2009 给出的规则起草。

本标准代替 GB/T 8110—2008《气体保护电弧焊用碳钢、低合金钢焊丝》。与 GB/T 8110—2008 相比，主要技术变化如下：

——保留了 2008 年版中 13 个焊丝型号, 按照 ISO 14341:2010 编制了化学成分分类;

——根据国内使用需求,增加了6个化学成分分类;

——按照 ISO 14341:2010, 增加了 27 个化学成分分类;

——删除了熔敷金属扩散氢含量相关要求。

本标准使用重新起草法修改采用 ISO 14341:2010《焊接材料 非合金钢和细晶粒钢气体保护电弧焊焊丝及熔敷金属 分类》。

本标准与 ISO 14341:2010 相比，在结构上有较多调整，附录 A 列出了本标准与 ISO 14341:2010 章条编号变化对照一览表。

本标准与 ISO 14341:2010 相比存在技术性差异,附录 B 给出了相应技术性差异及其原因的一览表。

本标准还做了下列编辑性修改：

——将标准名称修改为《熔化极气体保护电弧焊用非合金钢及细晶粒钢实心焊丝》；

\- 增加了附录 C(资料性附录)焊丝型号对照。

本标准由全国焊接标准化技术委员会(SAC/TC 55)提出并归口。

本标准起草单位:哈尔滨焊接研究院有限公司、天津市金桥焊材集团股份有限公司、上海大西洋焊接材料有限责任公司、天津大桥焊材集团有限公司、上海焊接器材有限公司、山东索力得焊材股份有限公司、江苏中江焊丝有限公司、武汉铁锚焊接材料股份有限公司、昆山京群焊材科技有限公司、哈焊所华通(常州)焊业股份有限公司、宝鸡石油钢管有限责任公司(国家石油天然气管材工程技术研究中心)。

本标准起草人:宋北、储继君、侯杰昌、宋波、李典钊、王大梁、关常勇、张伟杰、宋昌宝、童天旺、李振华、杨子佳、苏金花、齐万利、李苏珊、杨忠文、杨昊泉、牛爱军。

本标准所代替标准的历次版本发布情况为：

—GB/T 8110—1987、GB/T 8110—1995、GB/T 8110—2008。

# 熔化极气体保护电弧焊用 非合金钢及细晶粒钢实心焊丝

## 1 范围

本标准规定了熔化极气体保护电弧焊用非合金钢及细晶粒钢实心焊丝的型号、技术要求、试验方法、复验和供货技术条件等内容。

本标准适用于熔敷金属最小抗拉强度要求值不大于 570 MPa 的熔化极气体保护电弧焊用非合金钢及细晶粒钢实心焊丝(以下简称“焊丝”)。

## 2 规范性引用文件

下列文件对于本文件的应用是必不可少的。凡是注日期的引用文件，仅注日期的版本适用于本文件。凡是不注日期的引用文件，其最新版本(包括所有的修改单)适用于本文件。

GB/T 2650 焊接接头冲击试验方法(GB/T 2650—2008, ISO 9016:2001, IDT)

$$
\mathrm{GB/T} 2 6 5 2 \quad \text {焊缝及熔敷金属拉伸试验方法(GB / T} 2 6 5 2 - 2 0 0 8, \mathrm{ISO} 5 1 7 8: 2 0 0 1, \mathrm{IDT})
$$

GB/T 3323.1 焊缝无损检测 射线检测 第1部分:X和伽玛射线的胶片技术(GB/T 3323.1—2019,ISO 17636-1:2013,MOD)

GB/T 18591 焊接 预热温度、道间温度及预热维持温度的测量指南(GB/T 18591—2001, ISO 13916:1996, IDT)

GB/T 25774.1 焊接材料的检验 第1部分:钢、镍及镍合金熔敷金属力学性能试样的制备及检验(GB/T 25774.1—2010,ISO 15792-1:2000,MOD)

GB/T 25775 焊接材料供货技术条件 产品类型、尺寸、公差和标志(GB/T 25775—2010, ISO 544:2003, MOD)

GB/T 25778 焊接材料采购指南(GB/T 25778—2010, ISO 14344:2010, MOD)

GB/T 37910.1—2019 焊缝无损检测 射线检测验收等级 第1部分:钢、镍、钛及其合金(ISO 10675-1:2016, MOD)

GB/T 39255—2020 焊接与切割用保护气体(ISO 14175:2008, MOD)

## 3 型号

## 3.1 型号划分

焊丝型号按熔敷金属力学性能、焊后状态、保护气体类型和焊丝化学成分等进行划分。本标准与其他相关标准的实心焊丝型号对照参见附录 C。

## 3.2 型号编制方法

焊丝型号由五部分组成：

1）第一部分：用字母“G”表示熔化极气体保护电弧焊用实心焊丝；

2）第二部分：表示在焊态、焊后热处理条件下，熔敷金属的抗拉强度代号，见表1；

3）第三部分：表示冲击吸收能量 $(KV_{2})$ 不小于 $27\mathrm{J}$ 时的试验温度代号，见表2；

4）第四部分：表示保护气体类型代号，保护气体类型代号按GB/T39255的规定；

5）第五部分：表示焊丝化学成分分类，见4.3。

除以上强制代号外,可在型号中附加可选代号:

a) 字母“U”，附加在第三部分之后，表示在规定的试验温度下，冲击吸收能量 $(KV_{2})$ 应不小于47 J；

b) 无镀铜代号“N”，附加在第五部分之后，表示无镀铜焊丝。

本标准中焊丝型号示例如下：

示例 1:

![](images/20f206997b3f54222cb902468783cd9fded19ecb08062b86964f2890cbe34f19.jpg)

示例 2:

G 49A 0 U C1 S11
表示焊丝化学成分分类
表示保护气体类型，“C1”表示气体组成为 $100\% \mathrm{CO}_{2}$ 可选附加代号，表示冲击吸收能量（ $KV_{2}$ ）不小于47 J
表示冲击试验温度，“0”表示0 ℃
表示熔敷金属抗拉强度，“49A”表示焊态条件下最小要求值为490 MPa
表示熔化极气体保护电弧焊用实心焊丝

示例 3:

![](images/8ce553e4c14dd17f8c5663ce81e5b523ff13f8cb7e2596021fb57e38a2a2724f.jpg)

表 1 熔敷金属抗拉强度代号

<table><tr><td>抗拉强度代号 $^{\mathrm{a}}$ </td><td>抗拉强度  ${R}_{\mathrm{m}}$  MPa</td><td>屈服强度 $^{\mathrm{b}}{R}_{\mathrm{{eL}}}$  MPa</td><td>断后伸长率  $A$  %</td></tr><tr><td>43×</td><td>430~600</td><td>≥330</td><td>≥20</td></tr><tr><td>49×</td><td>490~670</td><td>≥390</td><td>≥18</td></tr><tr><td>55×</td><td>550~740</td><td>≥460</td><td>≥17</td></tr><tr><td>57×</td><td>570~770</td><td>≥490</td><td>≥17</td></tr><tr><td colspan="4"> $^{\mathrm{a}} \times$ 代表“A”“P”或者“AP”,“A”表示在焊态条件下试验;“P”表示在焊后热处理条件下试验。“AP”表示在焊态和焊后热处理条件下试验均可。 $^{\mathrm{b}}$  当屈服发生不明显时,应测定规定塑性延伸强度  ${R}_{\mathrm{p}{0.2}}$  。</td></tr></table>

表 2 冲击试验温度代号

<table><tr><td>冲击试验温度代号</td><td>冲击吸收能量(KV2)不小于27J时的试验温度°C</td></tr><tr><td>Z</td><td>无要求</td></tr><tr><td>Y</td><td>+20</td></tr><tr><td>0</td><td>0</td></tr><tr><td>2</td><td>-20</td></tr><tr><td>3</td><td>-30</td></tr><tr><td>4</td><td>-40</td></tr><tr><td>4H</td><td>-45</td></tr><tr><td>5</td><td>-50</td></tr><tr><td>6</td><td>-60</td></tr><tr><td>7</td><td>-70</td></tr><tr><td>7H</td><td>-75</td></tr><tr><td>8</td><td>-80</td></tr><tr><td>9</td><td>-90</td></tr><tr><td>10</td><td>-100</td></tr></table>

## 4 技术要求

## 4.1 焊丝尺寸及表面质量

焊丝尺寸及表面质量应符合 GB/T 25775 的规定。

## 4.2 焊丝松弛直径和翘距

焊丝的松弛直径和翘距应符合表3的规定。

表 3 焊丝松弛直径和翘距

<table><tr><td>包装形式</td><td>焊丝直径mm</td><td>松弛直径mm</td><td>翘距mm</td></tr><tr><td>外径100mm焊丝盘</td><td>所有</td><td>≥100</td><td>≤13</td></tr><tr><td rowspan="2">其他盘(卷)状包装形式</td><td>≤0.8</td><td>≥300</td><td rowspan="2">≤25</td></tr><tr><td>≥0.9</td><td>≥380</td></tr><tr><td colspan="4">注:对于某些大容量包装的焊丝可能经特殊处理以提供直丝输送,其松弛直径和翘距由供需双方协商确定。</td></tr></table>

## 4.3 化学成分

焊丝化学成分应符合表 4 的规定。

表 4 焊丝化学成分

<table><tr><td rowspan="2">序号</td><td rowspan="2">化学成分分类</td><td rowspan="2">焊丝成分代号</td><td colspan="12">化学成分(质量分数) $^a$ %</td></tr><tr><td>C</td><td>Mn</td><td>Si</td><td>P</td><td>S</td><td>Ni</td><td>Cr</td><td>Mo</td><td>V</td><td> $Cu^b$ </td><td>Al</td><td>Ti+Zr</td></tr><tr><td>1</td><td>S2</td><td>ER50-2</td><td>0.07</td><td>0.90~1.40</td><td>0.40~0.70</td><td>0.025</td><td>0.025</td><td>0.15</td><td>0.15</td><td>0.15</td><td>0.03</td><td>0.50</td><td>0.05~0.15</td><td>Ti:0.05~0.15Zr:0.02~0.12</td></tr><tr><td>2</td><td>S3</td><td>ER50-3</td><td>0.06~0.15</td><td>0.90~1.40</td><td>0.45~0.75</td><td>0.025</td><td>0.025</td><td>0.15</td><td>0.15</td><td>0.15</td><td>0.03</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>3</td><td>S4</td><td>ER50-4</td><td>0.06~0.15</td><td>1.00~1.50</td><td>0.65~0.85</td><td>0.025</td><td>0.025</td><td>0.15</td><td>0.15</td><td>0.15</td><td>0.03</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>4</td><td>S6</td><td>ER50-6</td><td>0.06~0.15</td><td>1.40~1.85</td><td>0.80~1.15</td><td>0.025</td><td>0.025</td><td>0.15</td><td>0.15</td><td>0.15</td><td>0.03</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>5</td><td>S7</td><td>ER50-7</td><td>0.07~0.15</td><td>1.50~2.00</td><td>0.50~0.80</td><td>0.025</td><td>0.025</td><td>0.15</td><td>0.15</td><td>0.15</td><td>0.03</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>6</td><td>S10</td><td>ER49-1</td><td>0.11</td><td>1.80~2.10</td><td>0.65~0.95</td><td>0.025</td><td>0.025</td><td>0.30</td><td>0.20</td><td>—</td><td>—</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>7</td><td>S11</td><td>—</td><td>0.02~0.15</td><td>1.40~1.90</td><td>0.55~1.10</td><td>0.030</td><td>0.030</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.50</td><td>—</td><td>0.02~0.30</td></tr><tr><td>8</td><td>S12</td><td>—</td><td>0.02~0.15</td><td>1.25~1.90</td><td>0.55~1.00</td><td>0.030</td><td>0.030</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.50</td><td>—</td><td>—</td></tr><tr><td>9</td><td>S13</td><td>—</td><td>0.02~0.15</td><td>1.35~1.90</td><td>0.55~1.10</td><td>0.030</td><td>0.030</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.50</td><td>0.10~0.50</td><td>0.02~0.30</td></tr><tr><td>10</td><td>S14</td><td>—</td><td>0.02~0.15</td><td>1.30~1.60</td><td>1.00~1.35</td><td>0.030</td><td>0.030</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.50</td><td>—</td><td>—</td></tr></table>

## 表 4 (续)

<table><tr><td rowspan="2">序号</td><td rowspan="2">化学成分分类</td><td rowspan="2">焊丝成分代号</td><td colspan="12">化学成分(质量分数) $^a$ %</td></tr><tr><td>C</td><td>Mn</td><td>Si</td><td>P</td><td>S</td><td>Ni</td><td>Cr</td><td>Mo</td><td>V</td><td> $Cu^b$ </td><td>Al</td><td>Ti+Zr</td></tr><tr><td>11</td><td>S15</td><td>-</td><td>0.02~0.15</td><td>1.00~1.60</td><td>0.40~1.00</td><td>0.030</td><td>0.030</td><td>-</td><td>-</td><td>-</td><td>-</td><td>0.50</td><td>-</td><td>0.02~0.15</td></tr><tr><td>12</td><td>S16</td><td>-</td><td>0.02~0.15</td><td>0.90~1.60</td><td>0.40~1.00</td><td>0.030</td><td>0.030</td><td>-</td><td>-</td><td>-</td><td>-</td><td>0.50</td><td>-</td><td>-</td></tr><tr><td>13</td><td>S17</td><td>-</td><td>0.02~0.15</td><td>1.50~2.10</td><td>0.20~0.55</td><td>0.030</td><td>0.030</td><td>-</td><td>-</td><td>-</td><td>-</td><td>0.50</td><td>-</td><td>0.02~0.30</td></tr><tr><td>14</td><td>S18</td><td>-</td><td>0.02~0.15</td><td>1.60~2.40</td><td>0.50~1.10</td><td>0.030</td><td>0.030</td><td>-</td><td>-</td><td>-</td><td>-</td><td>0.50</td><td>-</td><td>0.02~0.30</td></tr><tr><td>15</td><td>S1M3</td><td>ER49-A1</td><td>0.12</td><td>1.30</td><td>0.30~0.70</td><td>0.025</td><td>0.025</td><td>0.20</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>16</td><td>S2M3</td><td>-</td><td>0.12</td><td>0.60~1.40</td><td>0.30~0.70</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.50</td><td>-</td><td>-</td></tr><tr><td>17</td><td>S2M31</td><td>-</td><td>0.12</td><td>0.80~1.50</td><td>0.30~0.90</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.50</td><td>-</td><td>-</td></tr><tr><td>18</td><td>S3M3T</td><td>-</td><td>0.12</td><td>1.00~1.80</td><td>0.40~1.00</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>19</td><td>S3M1</td><td>-</td><td>0.05~0.15</td><td>1.40~2.10</td><td>0.40~1.00</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.10~0.45</td><td>-</td><td>0.50</td><td>-</td><td>-</td></tr><tr><td>20</td><td>S3M1T</td><td>-</td><td>0.12</td><td>1.40~2.10</td><td>0.40~1.00</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.10~0.45</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>21</td><td>S4M31</td><td>ER55-D2</td><td>0.07~0.12</td><td>1.60~2.10</td><td>0.50~0.80</td><td>0.025</td><td>0.025</td><td>0.15</td><td>-</td><td>0.40~0.60</td><td>-</td><td>0.50</td><td>-</td><td>-</td></tr><tr><td>22</td><td>S4M31T</td><td>ER55-D2-Ti</td><td>0.12</td><td>1.20~1.90</td><td>0.40~0.80</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.05~0.20</td></tr><tr><td>23</td><td>S4M3T</td><td>-</td><td>0.12</td><td>1.60~2.20</td><td>0.50~0.80</td><td>0.025</td><td>0.025</td><td>-</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>24</td><td>SN1</td><td>-</td><td>0.12</td><td>1.25</td><td>0.20~0.50</td><td>0.025</td><td>0.025</td><td>0.60~1.00</td><td>-</td><td>0.35</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>25</td><td>SN2</td><td>ER55-Ni1</td><td>0.12</td><td>1.25</td><td>0.40~0.80</td><td>0.025</td><td>0.025</td><td>0.80~1.10</td><td>0.15</td><td>0.35</td><td>0.05</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>26</td><td>SN3</td><td>-</td><td>0.12</td><td>1.20~1.60</td><td>0.30~0.80</td><td>0.025</td><td>0.025</td><td>1.50~1.90</td><td>-</td><td>0.35</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>27</td><td>SN5</td><td>ER55-Ni2</td><td>0.12</td><td>1.25</td><td>0.40~0.80</td><td>0.025</td><td>0.025</td><td>2.00~2.75</td><td>-</td><td>-</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>28</td><td>SN7</td><td>-</td><td>0.12</td><td>1.25</td><td>0.20~0.50</td><td>0.025</td><td>0.025</td><td>3.00~3.75</td><td>-</td><td>0.35</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>29</td><td>SN71</td><td>ER55-Ni3</td><td>0.12</td><td>1.25</td><td>0.40~0.80</td><td>0.025</td><td>0.025</td><td>3.00~3.75</td><td>-</td><td>-</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>30</td><td>SN9</td><td>-</td><td>0.10</td><td>1.40</td><td>0.50</td><td>0.025</td><td>0.025</td><td>4.00~4.75</td><td>-</td><td>0.35</td><td>-</td><td>0.35</td><td>-</td><td>-</td></tr><tr><td>31</td><td>SNCC</td><td>-</td><td>0.12</td><td>1.00~1.65</td><td>0.60~0.90</td><td>0.030</td><td>0.030</td><td>0.10~0.30</td><td>0.50~0.80</td><td>-</td><td>-</td><td>0.20~0.60</td><td>-</td><td>-</td></tr><tr><td>32</td><td>SNCC1</td><td>ER55-1</td><td>0.10</td><td>1.20~1.60</td><td>0.60</td><td>0.025</td><td>0.020</td><td>0.20~0.60</td><td>0.30~0.90</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>33</td><td>SNCC2</td><td>-</td><td>0.10</td><td>0.60~1.20</td><td>0.60</td><td>0.025</td><td>0.020</td><td>0.20~0.60</td><td>0.30~0.90</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>34</td><td>SNCC21</td><td>-</td><td>0.10</td><td>0.90~1.30</td><td>0.35~0.65</td><td>0.025</td><td>0.025</td><td>0.40~0.60</td><td>0.10</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>35</td><td>SNCC3</td><td>-</td><td>0.10</td><td>0.90~1.30</td><td>0.35~0.65</td><td>0.025</td><td>0.025</td><td>0.20~0.50</td><td>0.20~0.50</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>36</td><td>SNCC31</td><td>-</td><td>0.10</td><td>0.90~1.30</td><td>0.35~0.65</td><td>0.025</td><td>0.025</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>37</td><td>SNCCT</td><td>-</td><td>0.12</td><td>1.10~1.65</td><td>0.60~0.90</td><td>0.030</td><td>0.030</td><td>0.10~0.30</td><td>0.50~0.80</td><td>-</td><td>-</td><td>0.20~0.60</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>38</td><td>SNCCT1</td><td>-</td><td>0.12</td><td>1.20~1.80</td><td>0.50~0.80</td><td>0.030</td><td>0.030</td><td>0.10~0.40</td><td>0.50~0.80</td><td>0.02~0.30</td><td>-</td><td>0.20~0.60</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>39</td><td>SNCCT2</td><td>-</td><td>0.12</td><td>1.10~1.70</td><td>0.50~0.90</td><td>0.030</td><td>0.030</td><td>0.40~0.80</td><td>0.50~0.80</td><td>-</td><td>-</td><td>0.20~0.60</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>40</td><td>SN1M2T</td><td>-</td><td>0.12</td><td>1.70~2.30</td><td>0.60~1.00</td><td>0.025</td><td>0.025</td><td>0.40~0.80</td><td>-</td><td>0.20~0.60</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>41</td><td>SN2M1T</td><td>-</td><td>0.12</td><td>1.10~1.90</td><td>0.30~0.80</td><td>0.025</td><td>0.025</td><td>0.80~1.60</td><td>-</td><td>0.10~0.45</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>42</td><td>SN2M2T</td><td>-</td><td>0.05~0.15</td><td>1.00~1.80</td><td>0.30~0.90</td><td>0.025</td><td>0.025</td><td>0.70~1.20</td><td>-</td><td>0.20~0.60</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td rowspan="2">序号</td><td rowspan="2">化学成分分类</td><td rowspan="2">焊丝成分代号</td><td colspan="12">化学成分(质量分数)a%</td></tr><tr><td>C</td><td>Mn</td><td>Si</td><td>P</td><td>S</td><td>Ni</td><td>Cr</td><td>Mo</td><td>V</td><td> $Cu^b$ </td><td>Al</td><td>Ti+Zr</td></tr><tr><td>43</td><td>SN2M3T</td><td>-</td><td>0.05~0.15</td><td>1.40~2.10</td><td>0.30~0.90</td><td>0.025</td><td>0.025</td><td>0.70~1.20</td><td>-</td><td>0.40~0.65</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>44</td><td>SN2M4T</td><td>-</td><td>0.12</td><td>1.70~2.30</td><td>0.50~1.00</td><td>0.025</td><td>0.025</td><td>0.80~1.30</td><td>-</td><td>0.55~0.85</td><td>-</td><td>0.50</td><td>-</td><td>Ti:0.02~0.30</td></tr><tr><td>45</td><td>SN2MC</td><td>-</td><td>0.10</td><td>1.60</td><td>0.65</td><td>0.020</td><td>0.010</td><td>1.00~2.00</td><td>-</td><td>0.15~0.50</td><td>-</td><td>0.20~0.50</td><td>-</td><td>-</td></tr><tr><td>46</td><td>SN3MC</td><td>-</td><td>0.10</td><td>1.60</td><td>0.65</td><td>0.020</td><td>0.010</td><td>2.80~3.80</td><td>-</td><td>0.05~0.50</td><td>-</td><td>0.20~0.70</td><td>-</td><td>-</td></tr><tr><td>47</td><td> $Z\times^c$ </td><td>-</td><td colspan="12">其他协定成分</td></tr><tr><td colspan="15">注1:表中单值均为最大值。注2:表中列出的“焊丝成分代号”是为便于实际使用对照。</td></tr><tr><td colspan="15"> $^a$  化学分析应按表中规定的元素进行分析。如在分析过程中发现其他元素,这些元素的总量(除铁外)不应超过0.50%。 $^b$  Cu含量包括镀铜层中的含量。 $^c$  表中未列出的分类可用相类似的分类表示,词头加字母“Z”。化学成分范围不进行规定,两种分类之间不可替换。</td></tr></table>

## 4.4 力学性能

## 4.4.1 拉伸试验

熔敷金属拉伸试验结果应符合表1的规定。

## 4.4.2 冲击试验

4.4.2.1 夏比 V 型缺口冲击试验温度按表 2 要求, 测定 5 个冲击试样的冲击吸收能量 $(KV_{2})$ 。在计算 5 个冲击吸收能量 $(KV_{2})$ 的平均值时, 应去掉一个最大值和一个最小值, 余下的 3 个值中有 2 个应不小于 27 J, 另一个可小于 27 J, 但不应小于 20 J, 3 个值的平均值不应小于 27 J。

4.4.2.2 如果型号中附加了可选代号“U”，夏比 V 型缺口冲击试验温度按表 2 要求，测定 3 个冲击试样的冲击吸收能量 $(KV_{2})$ 。3 个值中有一个值可小于 47 J，但不应小于 32 J，3 个值的平均值不应小于 47 J。

## 4.5 焊丝送丝性能

缠绕的焊丝应适合连续送丝。焊丝接头处应适当处理，以保证能均匀连续送丝。

## 4.6 焊缝X射线检测

焊缝 X 射线检测验收等级应符合 GB/T 37910.1—2019 中表 1 规定的 2 级。

## 5 试验方法

## 5.1 焊丝尺寸及表面质量

## 5.1.1 尺寸

焊丝直径检验用精度为 0.01 mm 的量具，在同一位置互相垂直方向测量，测量部位不少于两处。

## 5.1.2 表面质量

焊丝表面质量按 GB/T 25775 的规定,对焊丝任意部位进行目测检验。

## 5.2 焊丝松弛直径和翘距

测量缠绕在焊丝盘(卷)上焊丝的松弛直径和翘距时,按表3的要求,从焊丝盘上截取足够长度的焊丝,不受拘束地放在平面上,测量所形成圆或圆弧的直径即为松弛直径;焊丝翘起的最高点到平面的距离即为翘距。

## 5.3 化学分析

焊丝的化学成分分析应在焊丝成品上取样。化学成分分析可采用任何适宜的分析方法，仲裁试验时，按供需双方确认的分析方法进行。

## 5.4 力学性能试验

## 5.4.1 试验用母材

熔敷金属力学性能试验用母材应采用与其熔敷金属化学成分或力学性能相当的钢板。若采用其他母材，应使用试验焊材或其他相当的焊材在坡口面和垫板面焊接隔离层，其厚度加工后不小于3 mm。

## 5.4.2 试件制备

5.4.2.1 熔敷金属力学性能试件按 GB/T 25774.1 进行制备，采用试件类型 1.3，试板宽度不小于 125 mm。焊接时采用 $\phi1.2\ mm$ 或 $\phi1.6\ mm$ 焊丝按表 5 规定的规范进行焊接。焊接道数和层数的控制要求按表 5 的规定。当采用其他尺寸焊丝时，按制造商推荐的规范进行焊接。

5.4.2.2 试板定位焊后，启焊时试板温度应达到规定的预热温度，并在焊接过程中保持道间温度，见表6。试板温度超过时，应自然冷却。按照GB/T18591用表面温度计、测温笔或热电偶测量预热温度和道间温度。

5.4.2.3 试件要求焊后热处理时，应在拉伸试样和冲击试样加工之前进行。试件放入炉内时，炉温不得高于 $315^{\circ}\mathrm{C}$ ，自 $315^{\circ}\mathrm{C}$ 始，以不大于 $220^{\circ}\mathrm{C} / \mathrm{h}$ 的速率加热到 $620^{\circ}\mathrm{C} \pm 15^{\circ}\mathrm{C}$ ，保温 $60\mathrm{min} \sim 75\mathrm{min}$ 。达到保温时间后，以不大于 $195^{\circ}\mathrm{C} / \mathrm{h}$ 的速率随炉冷却至 $315^{\circ}\mathrm{C}$ 以下时，允许从炉中取出，自然冷却至室温。也可根据供需双方协定，采用其他热处理规范。

表 5 参考焊接规范

<table><tr><td>焊丝直径mm</td><td>焊接电流A</td><td>电弧电压V</td><td>干伸长mm</td><td>焊接速度mm/min</td><td>每层道数</td><td>层数</td><td>保护气体</td></tr><tr><td>1.2</td><td>290±30</td><td>a</td><td>20±3</td><td>330±60</td><td>2或3</td><td>6~10</td><td>b</td></tr><tr><td>1.6</td><td>360±30</td><td>a</td><td>20±3</td><td>330±60</td><td>2或3</td><td>5~10</td><td>b</td></tr><tr><td colspan="8">a电弧电压由保护气体类型而定。b通常情况下,如采用GB/T 39255-2020表2中规定的M12、M20和M21时,气体组分中不准许用氦气代替氩气。</td></tr></table>

表 6 预热温度和道间温度

<table><tr><td>化学成分分类</td><td>预热温度°C</td><td>道间温度°C</td></tr><tr><td>S2,S3,S4,S6,S7,S10,S11,S12,S13,S14,S15,S16,S17,S18,SN2MC,SN3MC</td><td>室温</td><td rowspan="5">150±15</td></tr><tr><td>S1M3,S2M3,S2M31,S3M3T,S3M1,S3M1T,S4M31,S4M31T,S4M3T</td><td rowspan="4">≥100</td></tr><tr><td>SN1,SN2,SN3,SN5,SN7,SN71,SN9</td></tr><tr><td>SNCC,SNCC1,SNCC2,SNCC21,SNCC3,SNCC31,SNCCT,SNCCT1,SNCCT2</td></tr><tr><td>SN1M2T,SN2M1T,SN2M2T,SN2M3T,SN2M4T</td></tr><tr><td>Z×</td><td colspan="2">供需双方协定</td></tr></table>

## 5.4.3 拉伸试验

熔敷金属拉伸试样尺寸及取样位置按GB/T25774.1的规定。拉伸试验按GB/T2652进行。

## 5.4.4 冲击试验

5.4.4.1 冲击试样尺寸及取样位置按GB/T25774.1的规定。

5.4.4.2 每组冲击试样中至少应测量一个试样V型缺口的形状尺寸，测量应在至少放大50倍的投影仪或金相显微镜上进行。

5.4.4.3 V型缺口冲击试验应按GB/T2650进行。

## 5.5 焊缝X射线检测

5.5.1 焊缝X射线检测应在截取力学试样之前进行，检测前应去掉垫板。

5.5.2 焊缝X射线检测按GB/T3323.1进行。

5.5.3 在评定焊缝X射线底片时，试件两端 $25\mathrm{mm}$ 应不予考虑。

## 6 复验

当任何一项检验不合格时，该项应加倍复验。对于化学分析，仅复验那些不满足要求的元素。当复验拉伸试验时，抗拉强度、屈服强度及断后伸长率同时作为复验项目。其试样可在原试件上截取，也可在新焊制的试件上截取。加倍复验结果均应符合该项检验的规定。

在试验过程中或试验完成后,如果能够确认试验没有按照规定进行,则试验无效,需按规定重新进行。在此种情况下,不要求加倍复验。

## 7 供货技术条件

供货技术条件按 GB/T 25775 和 GB/T 25778 的规定。

附录 A

(资料性附录)

本标准与ISO14341:2010相比的结构变化情况

本标准与ISO14341:2010相比，章条编号发生了变化，具体对照情况见表A.1。

表 A.1 本标准与 ISO 14341:2010 的章条编号对照情况

<table><tr><td>本标准章条编号</td><td>对应 ISO 标准章条编号</td></tr><tr><td>3</td><td>3B,4.1,4.2B,4.3B,4.4,4.5,10B</td></tr><tr><td>4.1</td><td>—</td></tr><tr><td>4.2</td><td>—</td></tr><tr><td>4.3</td><td>4.5</td></tr><tr><td>4.4</td><td>4.2B,4.3B</td></tr><tr><td>4.5</td><td>—</td></tr><tr><td>4.6</td><td>—</td></tr><tr><td>5.1</td><td>—</td></tr><tr><td>5.2</td><td>—</td></tr><tr><td>5.3</td><td>6</td></tr><tr><td>5.4</td><td>5B,5.1B,5.2B,5.3B</td></tr><tr><td>5.5</td><td>—</td></tr><tr><td>6</td><td>8</td></tr><tr><td>7</td><td>9</td></tr><tr><td>附录 A</td><td>—</td></tr><tr><td>附录 B</td><td>—</td></tr><tr><td>附录 C</td><td>—</td></tr></table>

附录 B

(资料性附录)

本标准与ISO14341:2010的技术性差异及其原因

本标准与 ISO 14341:2010 的技术性差异及其原因参见表 B.1。

## 表 B.1 本标准与 ISO 14341:2010 的技术性差异及其原因

<table><tr><td>本标准的章条编号</td><td>技术性差异</td><td>原因</td></tr><tr><td>2</td><td>关于规范性引用文件,本标准做了具有技术性差异的调整,以适应我国的技术条件,调整的情况集中反映在第2章“规范性引用文件”中,具体调整如下:用等同采用国际标准的GB/T 18591代替ISO 13916(见5.4.2.2);用修改采用国际标准的GB/T 25774.1代替ISO 15792-1(见5.4.2.1,5.4.3,5.4.4.1);用修改采用国际标准的GB/T 25775代替ISO 544(见4.1,5.1.2,第7章);用修改采用国际标准的GB/T 25778代替ISO 14344(见第7章);用修改采用国际标准的GB/T 39255-2020代替ISO 14175(见3.2);增加引用了GB/T 2650(见5.4.4.3);增加引用了GB/T 2652(见5.4.3);增加引用了GB/T 3323.1(见5.5.2);增加引用了GB/T 37910.1-2019(见4.6);删除了ISO 80000-1:2009</td><td>适用我国技术要求</td></tr><tr><td>3.2</td><td>增加了4H、7H两个冲击试验温度代号;增加了附加可选代号,无镀铜代号N;增加了AP表示在焊态和焊后热处理条件下试验均可</td><td>适用我国技术要求</td></tr><tr><td>4.3</td><td>增加了“焊丝成分代号”;化学成分分类S2、S3、S4、S6、S7的焊丝化学成分,S由“0.030%”、“0.035%”调整为“0.025%”;增加了S10、S4M31T、SNCC1、SNCC2、SNCC21、SNCC3、SNCC31、SN2MC、SN3MC九个化学成分分类;化学成分分类“G”改为“Z”</td><td>我国实际生产情况</td></tr><tr><td>4.15.1</td><td>增加了焊丝尺寸及表面质量的技术要求</td><td>适用我国技术要求</td></tr><tr><td>4.25.2</td><td>增加了焊丝松弛直径和翘距的技术要求</td><td>适用我国技术要求</td></tr><tr><td>4.5</td><td>增加了焊丝送丝性能的技术要求</td><td>适用我国技术要求</td></tr><tr><td>4.65.5</td><td>增加了焊缝X射线检测的技术要求</td><td>适用我国技术要求</td></tr><tr><td>5.4.2</td><td>增加了ø1.2mm焊丝的参考焊接速度和ø1.6mm焊丝的参考焊接规范</td><td>适用我国技术要求</td></tr></table>

## 附录 C

## (资料性附录)

## 焊丝型号对照

为便于应用,提供了本标准常用实心焊丝型号与其他相关标准焊丝型号之间的对应关系,参见表 C.1。在实际应用中并不限制采用其他保护气体类型,当采用其他保护气体类型时,其力学性能可能会发生变化。

表 C. 1 焊丝型号对照表

<table><tr><td>序号</td><td>本标准</td><td>ISO 14341:2010(B系列)</td><td>ANSI/AWS A5.18M:2017ANSI/AWS A5.28M:2005(R2015)</td><td>GB/T 8110-2008</td></tr><tr><td>1</td><td>G49A3C1S2</td><td>G49A3C1S2</td><td>ER49S-2</td><td>ER50-2</td></tr><tr><td>2</td><td>G49A2C1S3</td><td>G49A2C1S3</td><td>ER49S-3</td><td>ER50-3</td></tr><tr><td>3</td><td>G49AZC1S4</td><td>G49AZC1S4</td><td>ER49S-4</td><td>ER50-4</td></tr><tr><td>4</td><td>G49A3C1S6</td><td>G49A3C1S6</td><td rowspan="2">ER49S-6</td><td rowspan="2">ER50-6</td></tr><tr><td>5</td><td>G49A4M21S6</td><td>G49A4M21S6</td></tr><tr><td>6</td><td>G49A3C1S7</td><td>G49A3C1S7</td><td>ER49S-7</td><td>ER50-7</td></tr><tr><td>7</td><td>G49AYUC1S10</td><td>—</td><td>—</td><td>ER49-1</td></tr><tr><td>8</td><td>G×××S11</td><td>G×××S11</td><td>ER49S-8</td><td>—</td></tr><tr><td>9</td><td>G×××S12</td><td>G×××S12</td><td>—</td><td>—</td></tr><tr><td>10</td><td>G×××S13</td><td>G×××S13</td><td>—</td><td>—</td></tr><tr><td>11</td><td>G×××S14</td><td>G×××S14</td><td>—</td><td>—</td></tr><tr><td>12</td><td>G×××S15</td><td>G×××S15</td><td>—</td><td>—</td></tr><tr><td>13</td><td>G×××S16</td><td>G×××S16</td><td>—</td><td>—</td></tr><tr><td>14</td><td>G×××S17</td><td>G×××S17</td><td>—</td><td>—</td></tr><tr><td>15</td><td>G×××S18</td><td>G×××S18</td><td>—</td><td>—</td></tr><tr><td>16</td><td>G49PZ×S1M3</td><td>G49PZ×S1M3</td><td>ER49S-A1</td><td>ER49-A1</td></tr><tr><td>17</td><td>G×××S2M3</td><td>G×××S2M3</td><td>—</td><td>—</td></tr><tr><td>18</td><td>G×××S2M31</td><td>G×××S2M31</td><td>—</td><td>—</td></tr><tr><td>19</td><td>G×××S3M3T</td><td>G×××S3M3T</td><td>—</td><td>—</td></tr><tr><td>20</td><td>G×××S3M1</td><td>G×××S3M1</td><td>—</td><td>—</td></tr><tr><td>21</td><td>G×××S3M1T</td><td>G×××S3M1T</td><td>—</td><td>—</td></tr><tr><td>22</td><td>G55A3C1S4M31</td><td>G55A3C1S4M31</td><td>ER55S-D2</td><td>ER55-D2</td></tr><tr><td>23</td><td>G55A3C1S4M31T</td><td>—</td><td>—</td><td>ER55-D2-Ti</td></tr><tr><td>24</td><td>G×××S4M3T</td><td>G×××S4M3T</td><td>—</td><td>—</td></tr><tr><td>25</td><td>G×××SN1</td><td>G×××SN1</td><td>—</td><td>—</td></tr><tr><td>26</td><td>G55A4H×SN2</td><td>G55A××SN2</td><td>ER55S-Ni1</td><td>ER55-Ni1</td></tr><tr><td>27</td><td>G×××SN3</td><td>G×××SN3</td><td>—</td><td>—</td></tr><tr><td>28</td><td>G55P6×SN5</td><td>G55P6×SN5</td><td>ER55S-Ni2</td><td>ER55-Ni2</td></tr><tr><td>29</td><td>G×××SN7</td><td>G×××SN7</td><td>—</td><td>—</td></tr><tr><td>30</td><td>G55P7H×SN71</td><td>G55P××SN71</td><td>ER55S-Ni3</td><td>ER55-Ni3</td></tr><tr><td>31</td><td>G×××SN9</td><td>G×××SN9</td><td>—</td><td>—</td></tr><tr><td>32</td><td>G×××SNCC</td><td>G×××SNCC</td><td>—</td><td>—</td></tr><tr><td>33</td><td>G55A4UM21SNCC1</td><td>—</td><td>—</td><td>ER55-1</td></tr><tr><td>34</td><td>G×××SNCC2</td><td>—</td><td>—</td><td>—</td></tr><tr><td>35</td><td>G×××SNCC21</td><td>—</td><td>—</td><td>—</td></tr><tr><td>36</td><td>G×××SNCC3</td><td>—</td><td>—</td><td>—</td></tr><tr><td>37</td><td>G×××SNCC31</td><td>—</td><td>—</td><td>—</td></tr><tr><td>38</td><td>G×××SNCCT</td><td>G×××SNCCT</td><td>—</td><td>—</td></tr><tr><td>39</td><td>G×××SNCCT1</td><td>G×××SNCCT1</td><td>—</td><td>—</td></tr><tr><td>40</td><td>G×××SNCCT2</td><td>G×××SNCCT2</td><td>—</td><td>—</td></tr><tr><td>41</td><td>G×××SN1M2T</td><td>G×××SN1M2T</td><td>—</td><td>—</td></tr><tr><td>42</td><td>G×××SN2M1T</td><td>G×××SN2M1T</td><td>—</td><td>—</td></tr><tr><td>43</td><td>G×××SN2M2T</td><td>G×××SN2M2T</td><td>—</td><td>—</td></tr><tr><td>44</td><td>G×××SN2M3T</td><td>G×××SN2M3T</td><td>—</td><td>—</td></tr><tr><td>45</td><td>G×××SN2M4T</td><td>G×××SN2M4T</td><td>—</td><td>—</td></tr><tr><td>46</td><td>G×××SN2MC</td><td>—</td><td>—</td><td>—</td></tr><tr><td>47</td><td>G×××SN3MC</td><td>—</td><td>—</td><td>—</td></tr></table>

中华人民共和国

国家标准

# 熔化极气体保护电弧焊用 非合金钢及细晶粒钢实心焊丝

GB/T 8110—2020

中国标准出版社出版发行  
北京市朝阳区和平里西街甲2号(100029)  
北京市西城区三里河北街16号(100045)

网址: www.spc.org.cn

服务热线:400-168-0010

2020年11月第一版

\*

书号：155066·1-65826

版权专有 侵权必究